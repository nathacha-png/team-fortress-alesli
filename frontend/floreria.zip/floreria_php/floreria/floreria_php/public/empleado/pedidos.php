<?php
session_start();
if (empty($_SESSION["id"]) || empty($_SESSION["rol"]) || $_SESSION["tipo"] !== "empleado") {
    $root = preg_replace('/\/public\/empleado\/[^\/]+$/', '', $_SERVER['SCRIPT_NAME']);
    header("Location: " . $root . "/public/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap"/>
  <link rel="stylesheet" href="../assets/css/styles-empleado.css"/>
  <title>Pedidos — Florería Alesli</title>
  
  
  
</head>
<body>
<script src="../assets/js/api.js"></script>
<script>
  API.requireAuth('login.php');
  document.addEventListener('DOMContentLoaded', () => API.injectUserInfo());
</script>

<!-- Overlay mobile sidebar -->
<div id="sidebar-overlay"
     style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.3); z-index:99;"
     onclick="closeSidebar()">
</div>

<div class="app-layout">

  <!-- ══════════════════ SIDEBAR ══════════════════ -->
  <aside class="sidebar">

    <a class="sidebar-logo" href="dashboard.php">
      <div class="sidebar-logo-icon">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
      </div>
      <div>
        <div class="sidebar-logo-text">Florería <span>Alesli</span></div>
        <span class="sidebar-logo-badge">Empleado</span>
      </div>
    </a>

    <nav class="sidebar-nav">

      <p class="sidebar-section-label">Principal</p>

      <a class="nav-item" href="dashboard.php">
        <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        Dashboard
      </a>

      <a class="nav-item active" href="pedidos.php">
        <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        Pedidos
        <span class="nav-badge" id="badge-pedidos">—</span>
      </a>

      <a class="nav-item" href="catalogo.php">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
        Catálogo / Stock
        <span class="nav-badge warning" id="badge-stock">—</span>
      </a>

      <a class="nav-item" href="clientes.php">
        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
        Clientes
      </a>

      <p class="sidebar-section-label">Ventas</p>

      <a class="nav-item" href="ventas.php">
        <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        Caja / Ventas
      </a>

      <a class="nav-item" href="entregas.php">
        <svg viewBox="0 0 24 24"><rect x="1" y="3" width="15" height="13" rx="1"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
        Entregas
      </a>

      <p class="sidebar-section-label">Otros</p>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        Notificaciones
        <span class="nav-badge" id="badge-notif">—</span>
      </a>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 4.93l1.41 1.41M12 2v2M12 20v2M20 12h2M2 12h2M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41"/></svg>
        Configuración
      </a>

    </nav>

    <div class="sidebar-footer">
      <div class="user-card">
        <div class="user-avatar" id="user-avatar">—</div>
        <div class="user-info">
          <div class="user-name" id="user-name">—</div>
          <div class="user-role" id="user-role">—</div>
        </div>
        <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      </div>
    </div>

  </aside>

  <!-- ══════════════════ TOPBAR ══════════════════ -->
  <header class="topbar">
    <button id="menu-btn"
            style="display:none; background:none; border:none; cursor:pointer; padding:4px;"
            aria-label="Menú"
            onclick="toggleSidebar()">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6b3a4a" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/>
        <line x1="3" y1="12" x2="21" y2="12"/>
        <line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>

    <h1 class="topbar-title">Gestión de <span>Pedidos</span> 🌷</h1>

    <div class="topbar-search">
      <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5l4 4"/></svg>
      <input type="text" id="search-input" placeholder="Buscar pedido, cliente, producto..." oninput="filterTable()"/>
    </div>

    <div class="topbar-actions">
      <div class="topbar-btn" title="Notificaciones">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        <span class="topbar-notif-dot"></span>
      </div>
      <div class="topbar-btn" title="Exportar" onclick="alert('Exportando pedidos...')">
        <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      </div>
    </div>

    <div class="topbar-date">
      <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      <span id="live-date">Cargando...</span>
    </div>
  </header>

  <!-- ══════════════════ CONTENIDO ══════════════════ -->
  <main class="main-content">

    <!-- STATS STRIP -->
    <div class="stats-strip">
      <div class="stat-card">
        <div class="stat-icon pink">
          <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-total">—</div>
          <div class="stat-label">Total de hoy</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon amber">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-pendientes">—</div>
          <div class="stat-label">Pendientes</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon blue">
          <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-preparando">—</div>
          <div class="stat-label">Preparando</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green">
          <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-listos">—</div>
          <div class="stat-label">Listos / Entregados</div>
        </div>
      </div>
    </div>

    <!-- TOOLBAR -->
    <div class="toolbar">
      <div class="filter-tabs">
        <button class="filter-tab active" data-status="todos"      onclick="setFilter(this)">Todos</button>
        <button class="filter-tab"        data-status="pendiente"  onclick="setFilter(this)">Pendientes</button>
        <button class="filter-tab"        data-status="preparando" onclick="setFilter(this)">Preparando</button>
        <button class="filter-tab"        data-status="listo"      onclick="setFilter(this)">Listos</button>
        <button class="filter-tab"        data-status="entregado"  onclick="setFilter(this)">Entregados</button>
      </div>
      <div class="toolbar-right">
        <button class="btn-outline" onclick="alert('Filtros avanzados')">
          <svg viewBox="0 0 24 24"><line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="11" y1="18" x2="13" y2="18"/></svg>
          Filtrar
        </button>
        <button class="btn-primary" onclick="openModal()">
          <svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Nuevo pedido
        </button>
      </div>
    </div>

    <!-- TABLE CARD -->
    <div class="table-card">
      <div class="table-wrap">
        <table id="pedidos-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Cliente</th>
              <th>Producto</th>
              <th>Total</th>
              <th>Fecha entrega</th>
              <th>Prioridad</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody id="table-body">
            <!-- Filas generadas por pedidos.js -->
          </tbody>
        </table>
      </div>
      <div class="pagination">
        <span id="pagination-info">Cargando...</span>
        <div class="page-btns">
          <button class="page-btn">
            <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <button class="page-btn active">1</button>
          <button class="page-btn">2</button>
          <button class="page-btn">
            <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
      </div>
    </div>

  </main>
</div>

<!-- ══════════════════ MODAL NUEVO PEDIDO ══════════════════ -->
<div class="modal-overlay" id="modal-new" onclick="if(event.target===this)closeModal()">
  <div class="modal">
    <div class="modal-header">
      <div>
        <div class="modal-title">Nuevo Pedido</div>
        <div class="modal-subtitle">Complete los datos del pedido</div>
      </div>
      <button class="modal-close" onclick="closeModal()">
        <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Cliente</label>
          <input type="text" id="f-cliente" class="form-input" placeholder="Nombre del cliente"/>
        </div>
        <div class="form-group">
          <label class="form-label">Teléfono</label>
          <input type="text" id="f-telefono" class="form-input" placeholder="Ej. 77712345"/>
        </div>
      </div>
      <div class="form-row single">
        <div class="form-group">
          <label class="form-label">Producto / Arreglo</label>
          <select id="f-producto" class="form-select">
            <option value="">Seleccionar producto...</option>
            <!-- Opciones dinámicas desde la BD -->
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Fecha de entrega</label>
          <input type="date" id="f-fecha" class="form-input"/>
        </div>
        <div class="form-group">
          <label class="form-label">Prioridad</label>
          <select id="f-prioridad" class="form-select">
            <option value="baja">Baja</option>
            <option value="media" selected>Media</option>
            <option value="alta">Alta</option>
          </select>
        </div>
      </div>
      <div class="form-row single">
        <div class="form-group">
          <label class="form-label">Dirección de entrega</label>
          <input type="text" id="f-direccion" class="form-input" placeholder="Calle, número, barrio..."/>
        </div>
      </div>
      <div class="form-row single">
        <div class="form-group">
          <label class="form-label">Notas adicionales</label>
          <input type="text" id="f-notas" class="form-input" placeholder="Dedicatoria, instrucciones especiales..."/>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-outline" onclick="closeModal()">Cancelar</button>
      <button class="btn-primary" onclick="saveOrder()">
        <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
        Guardar pedido
      </button>
    </div>
  </div>
</div>

<!-- ══════════════════ PANEL DETALLE ══════════════════ -->
<div class="detail-overlay" id="detail-overlay">
  <div class="detail-backdrop" onclick="closeDetail()"></div>
  <div class="detail-panel">
    <div class="detail-header">
      <div>
        <div class="detail-order-id" id="d-id">#—</div>
        <div class="detail-date" id="d-date"></div>
      </div>
      <button class="modal-close" onclick="closeDetail()">
        <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="detail-body">

      <div>
        <div class="detail-section-title">Información del cliente</div>
        <div class="detail-info-grid">
          <div class="detail-info-item">
            <div class="di-label">Nombre</div>
            <div class="di-value" id="d-name">—</div>
          </div>
          <div class="detail-info-item">
            <div class="di-label">Teléfono</div>
            <div class="di-value" id="d-phone">—</div>
          </div>
          <div class="detail-info-item">
            <div class="di-label">Prioridad</div>
            <div class="di-value" id="d-priority">—</div>
          </div>
          <div class="detail-info-item">
            <div class="di-label">Entrega</div>
            <div class="di-value" id="d-delivery">—</div>
          </div>
        </div>
      </div>

      <div>
        <div class="detail-section-title">Producto</div>
        <div class="detail-product">
          <div class="detail-product-icon">
            <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
          </div>
          <div>
            <div class="detail-product-name" id="d-product">—</div>
            <div class="detail-product-qty">Cantidad: 1</div>
          </div>
          <div class="detail-product-price" id="d-price">—</div>
        </div>
        <div class="detail-total" style="margin-top:10px;">
          <span>Total</span>
          <span id="d-total">—</span>
        </div>
      </div>

      <div>
        <div class="detail-section-title">Estado del pedido</div>
        <div class="status-timeline">
          <div class="timeline-step done" id="ts-recibido">
            <div style="position:relative; flex-shrink:0;">
              <div class="timeline-dot done">
                <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
              <div class="timeline-line"></div>
            </div>
            <div>
              <div class="timeline-label">Pedido recibido</div>
              <div class="timeline-time" id="t-recibido">—</div>
            </div>
          </div>
          <div class="timeline-step" id="ts-preparando">
            <div style="position:relative; flex-shrink:0;">
              <div class="timeline-dot" id="dot-preparando"></div>
              <div class="timeline-line"></div>
            </div>
            <div>
              <div class="timeline-label">En preparación</div>
              <div class="timeline-time" id="t-preparando">Pendiente</div>
            </div>
          </div>
          <div class="timeline-step" id="ts-listo">
            <div style="position:relative; flex-shrink:0;">
              <div class="timeline-dot" id="dot-listo"></div>
              <div class="timeline-line"></div>
            </div>
            <div>
              <div class="timeline-label">Listo para entrega</div>
              <div class="timeline-time" id="t-listo">Pendiente</div>
            </div>
          </div>
          <div class="timeline-step" id="ts-entregado">
            <div style="position:relative; flex-shrink:0;">
              <div class="timeline-dot" id="dot-entregado"></div>
            </div>
            <div>
              <div class="timeline-label">Entregado</div>
              <div class="timeline-time" id="t-entregado">Pendiente</div>
            </div>
          </div>
        </div>
      </div>

    </div>
    <div class="detail-footer">
      <button class="btn-outline" onclick="closeDetail()">Cerrar</button>
      <button class="btn-primary" id="d-advance-btn" onclick="advanceStatus()">
        <svg viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 014-4h14"/></svg>
        Avanzar estado
      </button>
    </div>
  </div>
</div>

<script src="../assets/js/main.js"></script>
<script src="../assets/js/pedidos.js"></script>
<script>
  // Carga de datos con API.js — sin condición de carrera
  API.cargar(API.pedidos.bind(API), function(data) {
    window.PEDIDOS = data;
    if (typeof applyFilters === 'function') applyFilters();
  }, 'PEDIDOS');
</script>
<script src="../assets/js/petalos-global.js"></script>
</body>
</html>