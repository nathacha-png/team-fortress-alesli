<?php
// Este login fue eliminado. El acceso es desde la página principal.
$root = preg_replace('/\/public\/empleado\/login\.php$/', '', $_SERVER['SCRIPT_NAME']);
header('Location: ' . $root . '/public/index.php');
exit;
