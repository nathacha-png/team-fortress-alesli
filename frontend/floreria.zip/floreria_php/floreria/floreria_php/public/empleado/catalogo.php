<?php
session_start();
if (empty($_SESSION["id"]) || empty($_SESSION["rol"]) || $_SESSION["tipo"] !== "empleado") {
    $root = preg_replace('/\/public\/empleado\/[^\/]+$/', '', $_SERVER['SCRIPT_NAME']);
    header("Location: " . $root . "/public/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap"/>
  <link rel="stylesheet" href="../assets/css/styles-empleado.css"/>
  <title>Catálogo — Florería Alesli</title>
  
  
  
</head>
<body>
<script src="../assets/js/api.js"></script>
<script>
  API.requireAuth('login.php');
  document.addEventListener('DOMContentLoaded', () => API.injectUserInfo());
</script>

<!-- Overlay mobile sidebar -->
<div id="sidebar-overlay"
     style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.3); z-index:99;"
     onclick="closeSidebar()">
</div>

<div class="app-layout">

  <!-- ══════════════════ SIDEBAR ══════════════════ -->
  <aside class="sidebar">

    <a class="sidebar-logo" href="dashboard.php">
      <div class="sidebar-logo-icon">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
      </div>
      <div>
        <div class="sidebar-logo-text">Florería <span>Alesli</span></div>
        <span class="sidebar-logo-badge">Empleado</span>
      </div>
    </a>

    <nav class="sidebar-nav">

      <p class="sidebar-section-label">Principal</p>

      <a class="nav-item" href="dashboard.php">
        <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        Dashboard
      </a>

      <a class="nav-item" href="pedidos.php">
        <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        Pedidos
        <span class="nav-badge" id="badge-pedidos">—</span>
      </a>

      <a class="nav-item active" href="catalogo.php">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
        Catálogo / Stock
        <span class="nav-badge warning" id="badge-stock">—</span>
      </a>

      <a class="nav-item" href="clientes.php">
        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
        Clientes
      </a>

      <p class="sidebar-section-label">Ventas</p>

      <a class="nav-item" href="ventas.php">
        <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        Caja / Ventas
      </a>

      <a class="nav-item" href="entregas.php">
        <svg viewBox="0 0 24 24"><rect x="1" y="3" width="15" height="13" rx="1"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
        Entregas
      </a>

      <p class="sidebar-section-label">Otros</p>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        Notificaciones
        <span class="nav-badge" id="badge-notif">—</span>
      </a>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 4.93l1.41 1.41M12 2v2M12 20v2M20 12h2M2 12h2M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41"/></svg>
        Configuración
      </a>

    </nav>

    <div class="sidebar-footer">
      <div class="user-card">
        <div class="user-avatar" id="user-avatar">—</div>
        <div class="user-info">
          <div class="user-name" id="user-name">—</div>
          <div class="user-role" id="user-role">—</div>
        </div>
        <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      </div>
    </div>

  </aside>

  <!-- ══════════════════ TOPBAR ══════════════════ -->
  <header class="topbar">
    <button id="menu-btn"
            style="display:none; background:none; border:none; cursor:pointer; padding:4px;"
            aria-label="Menú"
            onclick="toggleSidebar()">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6b3a4a" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/>
        <line x1="3" y1="12" x2="21" y2="12"/>
        <line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>

    <h1 class="topbar-title">Catálogo / <span>Stock</span> 🌸</h1>

    <div class="topbar-search">
      <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5l4 4"/></svg>
      <input type="text" id="search-input" placeholder="Buscar producto, categoría..." oninput="filterTable()"/>
    </div>

    <div class="topbar-actions">
      <div class="topbar-btn" title="Notificaciones">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        <span class="topbar-notif-dot"></span>
      </div>
      <div class="topbar-btn" title="Exportar inventario" onclick="alert('Exportando inventario...')">
        <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      </div>
    </div>

    <div class="topbar-date">
      <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      <span id="live-date">Cargando...</span>
    </div>
  </header>

  <!-- ══════════════════ CONTENIDO ══════════════════ -->
  <main class="main-content">

    <!-- ALERTA STOCK BAJO -->
    <div id="stock-alert-banner" class="stock-alert-banner" style="display:none;">
      <svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      <span>Hay productos con <strong>stock bajo o agotado</strong> que requieren atención.</span>
      <span class="alert-count">—</span>
    </div>

    <!-- STATS STRIP -->
    <div class="stats-strip">
      <div class="stat-card">
        <div class="stat-icon pink">
          <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-total">—</div>
          <div class="stat-label">Total productos</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green">
          <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-ok">—</div>
          <div class="stat-label">Disponibles</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon amber">
          <svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-bajos">—</div>
          <div class="stat-label">Stock bajo</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon red">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-agotados">—</div>
          <div class="stat-label">Agotados</div>
        </div>
      </div>
    </div>

    <!-- TOOLBAR -->
    <div class="toolbar">
      <div class="filter-tabs">
        <button class="filter-tab active" data-status="todos"      onclick="setFilter(this)">Todos</button>
        <button class="filter-tab"        data-status="disponible" onclick="setFilter(this)">Disponibles</button>
        <button class="filter-tab"        data-status="bajo"       onclick="setFilter(this)">Stock bajo</button>
        <button class="filter-tab"        data-status="agotado"    onclick="setFilter(this)">Agotados</button>
      </div>
      <div class="toolbar-right">
        <!-- Toggle vista tabla / grid -->
        <div class="view-toggle">
          <button class="view-btn active" id="view-btn-tabla" title="Vista tabla" onclick="setView('tabla')">
            <svg viewBox="0 0 24 24"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
          </button>
          <button class="view-btn" id="view-btn-grid" title="Vista tarjetas" onclick="setView('grid')">
            <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
          </button>
        </div>
        <button class="btn-outline" onclick="alert('Filtros avanzados')">
          <svg viewBox="0 0 24 24"><line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="11" y1="18" x2="13" y2="18"/></svg>
          Filtrar
        </button>
        <button class="btn-primary" onclick="openModal()">
          <svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Nuevo producto
        </button>
      </div>
    </div>

    <!-- VISTA TABLA -->
    <div id="table-card" class="table-card">
      <div class="table-wrap">
        <table id="catalogo-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Producto</th>
              <th>Precio</th>
              <th>Stock</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody id="table-body">
            <!-- Filas generadas por catalogo.js -->
          </tbody>
        </table>
      </div>
      <div class="pagination">
        <span id="pagination-info">Cargando...</span>
        <div class="page-btns">
          <button class="page-btn">
            <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <button class="page-btn active">1</button>
          <button class="page-btn">2</button>
          <button class="page-btn">
            <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
      </div>
    </div>

    <!-- VISTA GRID (oculta por defecto) -->
    <div id="grid-wrap" style="display:none;">
      <div id="products-grid" class="products-grid">
        <!-- Tarjetas generadas por catalogo.js -->
      </div>
    </div>

  </main>
</div>

<!-- ══════════════════ MODAL NUEVO / EDITAR PRODUCTO ══════════════════ -->
<div class="modal-overlay" id="modal-product" onclick="if(event.target===this)closeModal()">
  <div class="modal">
    <div class="modal-header">
      <div>
        <div class="modal-title" id="modal-product-title">Nuevo Producto</div>
        <div class="modal-subtitle">Complete los datos del producto</div>
      </div>
      <button class="modal-close" onclick="closeModal()">
        <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Nombre del producto</label>
          <input type="text" id="f-nombre" class="form-input" placeholder="Ej. Ramo de rosas rojas"/>
        </div>
        <div class="form-group">
          <label class="form-label">Categoría</label>
          <select id="f-categoria" class="form-select">
            <option value="">Seleccionar...</option>
            <!-- Opciones dinámicas desde la BD -->
          </select>
        </div>
      </div>
      <div class="form-row triple">
        <div class="form-group">
          <label class="form-label">Precio (Bs.)</label>
          <input type="number" id="f-precio" class="form-input" placeholder="0.00" min="0" step="0.5"/>
        </div>
        <div class="form-group">
          <label class="form-label">Stock inicial</label>
          <input type="number" id="f-stock" class="form-input" placeholder="0" min="0"/>
        </div>
        <div class="form-group">
          <label class="form-label">Stock mínimo</label>
          <input type="number" id="f-stock-min" class="form-input" placeholder="5" min="0"/>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Estado</label>
          <select id="f-estado" class="form-select">
            <option value="activo">Activo</option>
            <option value="desactivo">Desactivo</option>
            <option value="agotado">Agotado</option>
          </select>
        </div>
      </div>
      <div class="form-row single">
        <div class="form-group">
          <label class="form-label">Descripción</label>
          <textarea id="f-descripcion" class="form-textarea" placeholder="Descripción del producto, colores, tamaño..."></textarea>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-outline" onclick="closeModal()">Cancelar</button>
      <button class="btn-primary" onclick="saveProduct()">
        <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
        Guardar producto
      </button>
    </div>
  </div>
</div>

<!-- ══════════════════ MODAL AJUSTE DE STOCK ══════════════════ -->
<div class="modal-overlay" id="modal-stock" onclick="if(event.target===this)closeStockModal()">
  <div class="modal" style="max-width:380px;">
    <div class="modal-header">
      <div>
        <div class="modal-title">Ajustar Stock</div>
        <div class="modal-subtitle" id="stock-modal-name">—</div>
      </div>
      <button class="modal-close" onclick="closeStockModal()">
        <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label" id="stock-modal-current">Stock actual: — unidades</label>
        <div class="stock-input-wrap">
          <button type="button" onclick="changeStockInput(-1)">−</button>
          <input type="number" id="stock-ajuste-input" value="0"/>
          <button type="button" onclick="changeStockInput(1)">+</button>
        </div>
        <span style="font-size:.72rem; color:var(--text-light); margin-top:4px;">
          Usa valores negativos para restar stock (ej. −3)
        </span>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-outline" onclick="closeStockModal()">Cancelar</button>
      <button class="btn-primary" onclick="saveStockAjuste()">
        <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
        Confirmar ajuste
      </button>
    </div>
  </div>
</div>

<script src="../assets/js/catalogo.js"></script>
<script>
  // Carga de datos con API.js — sin condición de carrera
  API.cargar(API.productos.bind(API), function(data) {
    window.PRODUCTOS = data;
    if (typeof applyFilters === 'function') applyFilters();
  }, 'PRODUCTOS');
</script>
<script src="../assets/js/petalos-global.js"></script>
</body>
</html>