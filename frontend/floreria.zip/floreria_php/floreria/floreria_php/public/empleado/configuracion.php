<?php
session_start();
if (empty($_SESSION["id"]) || empty($_SESSION["rol"]) || $_SESSION["tipo"] !== "empleado") {
    $root = preg_replace('/\/public\/empleado\/[^\/]+$/', '', $_SERVER['SCRIPT_NAME']);
    header("Location: " . $root . "/public/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap"/>
  <link rel="stylesheet" href="../assets/css/styles-empleado.css"/>
  <title>Configuración — Florería Alesli</title>
</head>
<body>
<script src="../assets/js/api.js"></script>
<script>
  API.requireAuth('login.php');
  document.addEventListener('DOMContentLoaded', () => API.injectUserInfo());
</script>

<!-- Overlay mobile sidebar -->
<div id="sidebar-overlay"
     style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.3); z-index:99;"
     onclick="closeSidebar()">
</div>

<div class="app-layout">
  <!-- ══════════════════ SIDEBAR ══════════════════ -->
  <aside class="sidebar">
    <a class="sidebar-logo" href="dashboard.php">
      <div class="sidebar-logo-icon">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
      </div>
      <div>
        <div class="sidebar-logo-text">Florería <span>Alesli</span></div>
        <span class="sidebar-logo-badge">Empleado</span>
      </div>
    </a>
    <nav class="sidebar-nav">
      <p class="sidebar-section-label">Principal</p>
      <a class="nav-item" href="dashboard.php">
        <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        Dashboard
      </a>
      <a class="nav-item" href="pedidos.php">
        <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        Pedidos
        <span class="nav-badge" id="badge-pedidos">—</span>
      </a>
      <a class="nav-item" href="catalogo.php">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
        Catálogo / Stock
        <span class="nav-badge warning" id="badge-stock">—</span>
      </a>
      <a class="nav-item" href="clientes.php">
        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
        Clientes
      </a>
      <p class="sidebar-section-label">Ventas</p>
      <a class="nav-item" href="ventas.php">
        <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        Caja / Ventas
      </a>
      <a class="nav-item" href="entregas.php">
        <svg viewBox="0 0 24 24"><rect x="1" y="3" width="15" height="13" rx="1"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
        Entregas
      </a>
      <p class="sidebar-section-label">Otros</p>
      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        Notificaciones
        <span class="nav-badge" id="badge-notif">—</span>
      </a>
      <a class="nav-item active" href="configuracion.php">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 4.93l1.41 1.41M12 2v2M12 20v2M20 12h2M2 12h2M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41"/></svg>
        Configuración
      </a>
    </nav>
    <div class="sidebar-footer">
      <div class="user-card">
        <div class="user-avatar" id="user-avatar">—</div>
        <div class="user-info">
          <div class="user-name" id="user-name">—</div>
          <div class="user-role" id="user-role">—</div>
        </div>
        <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      </div>
    </div>
  </aside>

  <!-- ══════════════════ TOPBAR ══════════════════ -->
  <header class="topbar">
    <button id="menu-btn"
            style="display:none; background:none; border:none; cursor:pointer; padding:4px;"
            aria-label="Menú"
            onclick="toggleSidebar()">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6b3a4a" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/>
        <line x1="3" y1="12" x2="21" y2="12"/>
        <line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>
    <h1 class="topbar-title">Mi <span>Configuración</span> ⚙️</h1>
    <div class="topbar-search" style="visibility:hidden;"></div>
    <div class="topbar-actions">
      <div class="topbar-btn" title="Notificaciones">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        <span class="topbar-notif-dot"></span>
      </div>
    </div>
    <div class="topbar-date">
      <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      <span id="live-date">Cargando...</span>
    </div>
  </header>

  <!-- ══════════════════ CONTENIDO ══════════════════ -->
  <main class="main-content">

    <!-- PROFILE HERO -->
    <div class="cfg-profile-hero">
      <div class="cfg-avatar-wrap">
        <div class="cfg-avatar" id="cfg-avatar-display">MA</div>
        <button class="cfg-avatar-btn" onclick="document.getElementById('avatar-upload').click()" title="Cambiar foto">
          <svg viewBox="0 0 24 24"><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/></svg>
        </button>
        <input type="file" id="avatar-upload" accept="image/*" style="display:none" onchange="handleAvatarUpload(event)"/>
      </div>
      <div class="cfg-hero-info">
        <div class="cfg-hero-name" id="cfg-hero-name">María Antonieta</div>
        <div class="cfg-hero-role" id="cfg-hero-role">Empleada · Florería Alesli</div>
        <div class="cfg-hero-meta">
          <span id="cfg-hero-phone">
            <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.07 1.18a2 2 0 012-2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 6.27a16 16 0 006.29 6.29l.44-.44a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
            —
          </span>
          <span id="cfg-hero-email">
            <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            —
          </span>
        </div>
      </div>
      <div class="cfg-hero-badge" id="cfg-hero-status-badge">Activo</div>
    </div>

    <!-- TABS NAV -->
    <div class="cfg-tabs">
      <button class="cfg-tab active" data-tab="perfil" onclick="switchTab(this)">
        <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        Perfil
      </button>
      <button class="cfg-tab" data-tab="contacto" onclick="switchTab(this)">
        <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.07 1.18a2 2 0 012-2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 6.27a16 16 0 006.29 6.29l.44-.44a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
        Contacto
      </button>
      <button class="cfg-tab" data-tab="preferencias" onclick="switchTab(this)">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 4.93l1.41 1.41M12 2v2M12 20v2M20 12h2M2 12h2M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41"/></svg>
        Preferencias
      </button>
      <button class="cfg-tab" data-tab="apariencia" onclick="switchTab(this)">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
        Apariencia
      </button>
    </div>

    <!-- ── TAB: PERFIL ── -->
    <div class="cfg-tab-panel active" id="panel-perfil">
      <div class="cfg-section-grid">

        <!-- Datos personales -->
        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              Datos personales
            </div>
            <span class="cfg-card-hint">Visible para el equipo</span>
          </div>
          <div class="cfg-card-body">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Nombre</label>
                <input type="text" id="cfg-nombre" class="form-input" placeholder="Tu nombre"/>
              </div>
              <div class="form-group">
                <label class="form-label">Apellido</label>
                <input type="text" id="cfg-apellido" class="form-input" placeholder="Tu apellido"/>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Apodo / Nombre para mostrar</label>
                <input type="text" id="cfg-apodo" class="form-input" placeholder="¿Cómo te llaman?"/>
              </div>
              <div class="form-group">
                <label class="form-label">Fecha de nacimiento</label>
                <input type="date" id="cfg-nacimiento" class="form-input"/>
              </div>
            </div>
            <div class="form-row single">
              <div class="form-group">
                <label class="form-label">Biografía corta</label>
                <textarea id="cfg-bio" class="form-input cfg-textarea" placeholder="Cuéntanos algo sobre ti..."></textarea>
              </div>
            </div>
          </div>
        </div>

        <!-- Información laboral (solo lectura) -->
        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/></svg>
              Información laboral
            </div>
            <span class="cfg-card-hint cfg-readonly-badge">Solo lectura</span>
          </div>
          <div class="cfg-card-body">
            <div class="cfg-readonly-grid">
              <div class="cfg-readonly-item">
                <div class="cfg-ro-label">Cargo</div>
                <div class="cfg-ro-value" id="ro-cargo">Empleado</div>
              </div>
              <div class="cfg-readonly-item">
                <div class="cfg-ro-label">Área</div>
                <div class="cfg-ro-value" id="ro-area">Atención al cliente</div>
              </div>
              <div class="cfg-readonly-item">
                <div class="cfg-ro-label">Fecha de ingreso</div>
                <div class="cfg-ro-value" id="ro-ingreso">—</div>
              </div>
              <div class="cfg-readonly-item">
                <div class="cfg-ro-label">ID de empleado</div>
                <div class="cfg-ro-value" id="ro-id">#EMP-001</div>
              </div>
            </div>
            <div class="cfg-info-note">
              <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              Para modificar estos datos contacta al administrador.
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ── TAB: CONTACTO ── -->
    <div class="cfg-tab-panel" id="panel-contacto">
      <div class="cfg-section-grid">

        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              Correo electrónico
            </div>
          </div>
          <div class="cfg-card-body">
            <div class="form-row single">
              <div class="form-group">
                <label class="form-label">Correo principal</label>
                <input type="email" id="cfg-email" class="form-input" placeholder="tu@correo.com"/>
              </div>
            </div>
            <div class="form-row single">
              <div class="form-group">
                <label class="form-label">Correo alternativo</label>
                <input type="email" id="cfg-email2" class="form-input" placeholder="otro@correo.com (opcional)"/>
              </div>
            </div>
          </div>
        </div>

        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.07 1.18a2 2 0 012-2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 6.27a16 16 0 006.29 6.29l.44-.44a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
              Teléfonos
            </div>
          </div>
          <div class="cfg-card-body">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Teléfono celular</label>
                <input type="tel" id="cfg-telefono" class="form-input" placeholder="Ej. 77712345"/>
              </div>
              <div class="form-group">
                <label class="form-label">Teléfono de emergencia</label>
                <input type="tel" id="cfg-tel-emergencia" class="form-input" placeholder="Contacto de emergencia"/>
              </div>
            </div>
            <div class="form-row single">
              <div class="form-group">
                <label class="form-label">Relación (contacto emergencia)</label>
                <input type="text" id="cfg-rel-emergencia" class="form-input" placeholder="Ej. Mamá, Pareja..."/>
              </div>
            </div>
          </div>
        </div>

        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
              Dirección
            </div>
          </div>
          <div class="cfg-card-body">
            <div class="form-row single">
              <div class="form-group">
                <label class="form-label">Calle / Avenida</label>
                <input type="text" id="cfg-calle" class="form-input" placeholder="Calle, número, edificio..."/>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Barrio / Zona</label>
                <input type="text" id="cfg-barrio" class="form-input" placeholder="Ej. Sopocachi"/>
              </div>
              <div class="form-group">
                <label class="form-label">Ciudad</label>
                <input type="text" id="cfg-ciudad" class="form-input" placeholder="Ej. La Paz"/>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ── TAB: PREFERENCIAS ── -->
    <div class="cfg-tab-panel" id="panel-preferencias">
      <div class="cfg-section-grid">

        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
              Notificaciones
            </div>
          </div>
          <div class="cfg-card-body">
            <div class="cfg-toggle-list">
              <div class="cfg-toggle-item">
                <div>
                  <div class="cfg-toggle-label">Nuevos pedidos</div>
                  <div class="cfg-toggle-desc">Recibir alerta cuando llegue un pedido nuevo</div>
                </div>
                <label class="cfg-switch">
                  <input type="checkbox" id="notif-pedidos" checked/>
                  <span class="cfg-slider"></span>
                </label>
              </div>
              <div class="cfg-toggle-item">
                <div>
                  <div class="cfg-toggle-label">Entregas del día</div>
                  <div class="cfg-toggle-desc">Recordatorio de entregas programadas para hoy</div>
                </div>
                <label class="cfg-switch">
                  <input type="checkbox" id="notif-entregas" checked/>
                  <span class="cfg-slider"></span>
                </label>
              </div>
              <div class="cfg-toggle-item">
                <div>
                  <div class="cfg-toggle-label">Stock bajo</div>
                  <div class="cfg-toggle-desc">Alerta cuando un producto esté por agotarse</div>
                </div>
                <label class="cfg-switch">
                  <input type="checkbox" id="notif-stock"/>
                  <span class="cfg-slider"></span>
                </label>
              </div>
              <div class="cfg-toggle-item">
                <div>
                  <div class="cfg-toggle-label">Mensajes del equipo</div>
                  <div class="cfg-toggle-desc">Notificaciones de chat interno</div>
                </div>
                <label class="cfg-switch">
                  <input type="checkbox" id="notif-mensajes" checked/>
                  <span class="cfg-slider"></span>
                </label>
              </div>
            </div>
          </div>
        </div>

        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              Horario de trabajo
            </div>
          </div>
          <div class="cfg-card-body">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Hora de entrada</label>
                <input type="time" id="cfg-hora-entrada" class="form-input" value="08:00"/>
              </div>
              <div class="form-group">
                <label class="form-label">Hora de salida</label>
                <input type="time" id="cfg-hora-salida" class="form-input" value="17:00"/>
              </div>
            </div>
            <div class="form-row single">
              <div class="form-group">
                <label class="form-label">Días de trabajo</label>
                <div class="cfg-days-picker">
                  <button class="cfg-day active" data-day="lun">Lun</button>
                  <button class="cfg-day active" data-day="mar">Mar</button>
                  <button class="cfg-day active" data-day="mie">Mié</button>
                  <button class="cfg-day active" data-day="jue">Jue</button>
                  <button class="cfg-day active" data-day="vie">Vie</button>
                  <button class="cfg-day" data-day="sab">Sáb</button>
                  <button class="cfg-day" data-day="dom">Dom</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 010 20M12 2a15.3 15.3 0 000 20"/></svg>
              Idioma y región
            </div>
          </div>
          <div class="cfg-card-body">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Idioma de la interfaz</label>
                <select id="cfg-idioma" class="form-select">
                  <option value="es" selected>Español</option>
                  <option value="en">English</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Zona horaria</label>
                <select id="cfg-timezone" class="form-select">
                  <option value="America/La_Paz" selected>Bolivia (GMT-4)</option>
                  <option value="America/Lima">Perú (GMT-5)</option>
                  <option value="America/Bogota">Colombia (GMT-5)</option>
                  <option value="America/Santiago">Chile (GMT-3)</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Formato de fecha</label>
                <select id="cfg-fecha-fmt" class="form-select">
                  <option value="dd/mm/yyyy" selected>DD/MM/AAAA</option>
                  <option value="mm/dd/yyyy">MM/DD/AAAA</option>
                  <option value="yyyy-mm-dd">AAAA-MM-DD</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Moneda</label>
                <select id="cfg-moneda" class="form-select">
                  <option value="BOB" selected>Boliviano (Bs.)</option>
                  <option value="USD">Dólar (USD)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- ── TAB: APARIENCIA ── -->
    <div class="cfg-tab-panel" id="panel-apariencia">
      <div class="cfg-section-grid">

        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
              Tema de color
            </div>
          </div>
          <div class="cfg-card-body">
            <div class="cfg-theme-grid">
              <button class="cfg-theme-btn active" data-theme="default" onclick="setTheme(this)" title="Rosa Alesli (predeterminado)">
                <span class="cfg-theme-swatch" style="background: linear-gradient(135deg,#c45e7e,#a8436a)"></span>
                <span>Rosa Alesli</span>
              </button>
              <button class="cfg-theme-btn" data-theme="lavender" onclick="setTheme(this)" title="Lavanda">
                <span class="cfg-theme-swatch" style="background: linear-gradient(135deg,#9b7fd4,#7c5ab8)"></span>
                <span>Lavanda</span>
              </button>
              <button class="cfg-theme-btn" data-theme="sage" onclick="setTheme(this)" title="Salvia verde">
                <span class="cfg-theme-swatch" style="background: linear-gradient(135deg,#6aaa6a,#4d8c4d)"></span>
                <span>Salvia</span>
              </button>
              <button class="cfg-theme-btn" data-theme="peach" onclick="setTheme(this)" title="Durazno">
                <span class="cfg-theme-swatch" style="background: linear-gradient(135deg,#e8835c,#cc6040)"></span>
                <span>Durazno</span>
              </button>
              <button class="cfg-theme-btn" data-theme="sky" onclick="setTheme(this)" title="Cielo">
                <span class="cfg-theme-swatch" style="background: linear-gradient(135deg,#4da6d6,#2a7fb8)"></span>
                <span>Cielo</span>
              </button>
              <button class="cfg-theme-btn" data-theme="dark" onclick="setTheme(this)" title="Oscuro">
                <span class="cfg-theme-swatch" style="background: linear-gradient(135deg,#3a3a4a,#1e1e2e)"></span>
                <span>Oscuro</span>
              </button>
            </div>
          </div>
        </div>

        <div class="table-card cfg-card">
          <div class="cfg-card-header">
            <div class="cfg-card-title">
              <svg viewBox="0 0 24 24"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>
              Diseño y accesibilidad
            </div>
          </div>
          <div class="cfg-card-body">
            <div class="cfg-toggle-list">
              <div class="cfg-toggle-item">
                <div>
                  <div class="cfg-toggle-label">Sidebar contraído por defecto</div>
                  <div class="cfg-toggle-desc">El menú lateral inicia minimizado</div>
                </div>
                <label class="cfg-switch">
                  <input type="checkbox" id="pref-sidebar-compact"/>
                  <span class="cfg-slider"></span>
                </label>
              </div>
              <div class="cfg-toggle-item">
                <div>
                  <div class="cfg-toggle-label">Animaciones reducidas</div>
                  <div class="cfg-toggle-desc">Menos efectos visuales para mejor rendimiento</div>
                </div>
                <label class="cfg-switch">
                  <input type="checkbox" id="pref-reduce-motion"/>
                  <span class="cfg-slider"></span>
                </label>
              </div>
              <div class="cfg-toggle-item">
                <div>
                  <div class="cfg-toggle-label">Texto grande</div>
                  <div class="cfg-toggle-desc">Aumenta el tamaño de fuente en la interfaz</div>
                </div>
                <label class="cfg-switch">
                  <input type="checkbox" id="pref-large-text"/>
                  <span class="cfg-slider"></span>
                </label>
              </div>
            </div>
            <div class="form-row" style="margin-top:16px;">
              <div class="form-group">
                <label class="form-label">Densidad de información</label>
                <select id="cfg-density" class="form-select">
                  <option value="cómoda" selected>Cómoda</option>
                  <option value="compacta">Compacta</option>
                  <option value="holgada">Holgada</option>
                </select>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- BOTONES GUARDAR -->
    <div class="cfg-footer-actions">
      <button class="btn-outline" onclick="resetChanges()">
        <svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/></svg>
        Descartar cambios
      </button>
      <button class="btn-primary" onclick="saveConfig()">
        <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
        Guardar configuración
      </button>
    </div>

    <!-- TOAST -->
    <div class="cfg-toast" id="cfg-toast">
      <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
      <span id="cfg-toast-msg">Cambios guardados correctamente</span>
    </div>

  </main>
</div>

<script src="../assets/js/configuracion.js"></script>
<script src="../assets/js/petalos-global.js"></script>
</body>
</html>