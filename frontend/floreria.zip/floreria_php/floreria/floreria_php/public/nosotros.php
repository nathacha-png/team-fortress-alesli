<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nosotros — Florería Alesli</title>
  <link rel="stylesheet" href="assets/css/estilo.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,400&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    .hero-nosotros { padding-top:0; }
    .about-hero {
      position:relative;
      background:url('https://images.unsplash.com/photo-1519163219899-21d2bb723b3e?auto=format&fit=crop&w=1350&q=80') center/cover no-repeat;
      height:480px;
      display:flex; align-items:center; justify-content:center; text-align:center;
    }
    .hero-overlay { position:absolute; inset:0; background:rgba(132,47,81,.55); }
    .about-hero-content { position:relative; z-index:1; padding-top:70px; }
    .about-hero-content h1 { color:#fff; font-size:3.2rem; margin-bottom:.5rem; }
    .about-hero-content p  { color:rgba(255,255,255,.82); font-size:1.05rem; max-width:520px; margin:0 auto; }
    .quienes { display:grid; grid-template-columns:1fr 1fr; gap:3rem; align-items:center; padding:80px 10%; text-align:left; background:#fff; }
    @media(max-width:768px){.quienes{grid-template-columns:1fr;}}
    .quienes .seccion-tag { display:block; margin-bottom:.5rem; font-size:.95rem; }
    .quienes h2 { text-align:left; margin-bottom:1rem; }
    .quienes p  { color:#666; line-height:1.8; margin-bottom:1rem; font-size:.95rem; }
    .info-card { background:#fff; border-radius:24px; border-right:8px solid var(--pink-primary); padding:2.2rem; box-shadow:0 12px 40px rgba(194,77,119,.08); transition:transform .3s; }
    .info-card:hover { transform:scale(1.02); }
    .info-card h4 { font-family:'Playfair Display',serif; font-size:1.2rem; color:#333; margin:0 0 1.2rem; }
    .info-item { display:flex; gap:.9rem; align-items:flex-start; margin-bottom:1.1rem; }
    .info-item:last-child { margin-bottom:0; }
    .info-item .ico { font-size:1.4rem; flex-shrink:0; margin-top:.1rem; }
    .info-item strong { display:block; font-size:.85rem; color:#333; margin-bottom:.15rem; }
    .info-item span   { font-size:.85rem; color:#777; line-height:1.5; }
    .stats-band { background:linear-gradient(135deg,#c24d77,#8c2f51); padding:60px 10%; display:flex; justify-content:center; gap:4rem; flex-wrap:wrap; text-align:center; }
    .stat-item strong { display:block; font-size:2.8rem; font-weight:700; color:#fff; font-family:'Playfair Display',serif; }
    .stat-item span   { font-size:.85rem; color:rgba(255,255,255,.75); font-weight:500; margin-top:.25rem; display:block; }
    .servicios { padding:80px 10%; background:#fdf6f8; text-align:center; }
    .servicios-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:1.6rem; margin:2.5rem auto 0; max-width:960px; }
    .servicio-box { background:#fff; border-radius:20px; padding:2rem 1.5rem; box-shadow:0 8px 24px rgba(194,77,119,.05); border-bottom:4px solid transparent; transition:all .3s; text-align:left; }
    .servicio-box:hover { transform:translateY(-8px); border-bottom-color:#c24d77; }
    .icon-box-circle { width:60px; height:60px; background:#fff0f3; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.6rem; margin-bottom:1rem; }
    .servicio-box h3 { font-size:1rem; color:#333; margin-bottom:.5rem; }
    .servicio-box p  { font-size:.85rem; color:#888; line-height:1.6; margin:0; }
    .equipo { padding:80px 10%; text-align:center; background:#fff; }
    .equipo-grid { display:flex; justify-content:center; gap:2rem; flex-wrap:wrap; margin-top:2.5rem; }
    .equipo-card { background:#fff; border-radius:20px; padding:1.8rem; width:200px; box-shadow:0 8px 24px rgba(194,77,119,.06); transition:transform .3s; }
    .equipo-card:hover { transform:translateY(-6px); }
    .avatar-circle { width:80px; height:80px; border-radius:50%; background:linear-gradient(135deg,#f5d5e2,#c24d77); display:flex; align-items:center; justify-content:center; font-size:1.8rem; margin:0 auto 1rem; }
    .equipo-card h4 { font-size:.95rem; color:#333; margin:0 0 .25rem; }
    .equipo-card span { font-size:.8rem; color:#c24d77; font-weight:600; }
    .map-section { padding:0 10% 80px; }
    .map-section h2 { text-align:center; margin-bottom:1.5rem; }
    .map-wrapper { border-radius:20px; overflow:hidden; box-shadow:0 12px 40px rgba(0,0,0,.08); }
    .contacto-section { padding:80px 10%; background:linear-gradient(135deg,#fff0f5,#fde8f0); text-align:center; scroll-margin-top:80px; }
    .contacto-grid { display:flex; justify-content:center; gap:1.5rem; flex-wrap:wrap; margin-top:2rem; }
    .contacto-card { background:#fff; border-radius:18px; padding:1.8rem 1.5rem; min-width:200px; box-shadow:0 6px 20px rgba(194,77,119,.08); }
    .contacto-card .ico { font-size:2rem; margin-bottom:.6rem; }
    .contacto-card h4  { font-size:.9rem; color:#8c2f51; margin:0 0 .3rem; font-weight:700; }
    .contacto-card p   { font-size:.85rem; color:#555; margin:0; line-height:1.5; }
    .wa-btn { display:inline-flex; align-items:center; gap:.5rem; background:#25d366; color:#fff; padding:.75rem 1.6rem; border-radius:2rem; text-decoration:none; font-weight:700; font-size:.9rem; margin-top:1.8rem; transition:background .2s; }
    .wa-btn:hover { background:#1ebe5d; }
  </style>
</head>
<body>
  <header class="nav-bar">
    <div class="logo">Floreria <span>alesli</span></div>
    <nav>
      <a href="index.php">Inicio</a>
      <a href="catalogo.php">Catálogo</a>
      <a href="nosotros.php" style="color:#c24d77;font-weight:600;">Nosotros</a>
      <a href="#contacto">Contacto</a>
    </nav>
    <div class="action">
      <button class="btn-login">Entrar</button>
    </div>
  </header>

  <main class="hero-nosotros">

    <div class="about-hero">
      <div class="hero-overlay"></div>
      <div class="about-hero-content">
        <h1>Nuestra Historia</h1>
        <p>Cultivando momentos, diseñando emociones desde 2015.</p>
      </div>
    </div>

    <section class="quienes">
      <div>
        <span class="seccion-tag">Desde el corazón</span>
        <h2>Quiénes Somos</h2>
        <p>En Florería Alesli creemos que cada flor lleva un mensaje que transmitir. Nacimos del amor por la naturaleza y el arte del diseño floral, con el sueño de transformar momentos en recuerdos inolvidables.</p>
        <p>Nuestros artesanos florales combinan técnicas tradicionales con tendencias modernas para ofrecerte piezas que no solo adornan espacios, sino que tocan corazones. Trabajamos con productores locales de La Paz para garantizar la frescura de cada arreglo.</p>
        <p>Lo que comenzó como un pequeño taller en Sopocachi hoy es la florería de confianza de más de 1.200 familias paceñas.</p>
      </div>
      <div id="contacto">
        <div class="info-card">
          <h4>📍 Ubicación y Contacto</h4>
          <div class="info-item">
            <span class="ico">🏢</span>
            <div><strong>Dirección</strong><span>Av. Las Flores #123, Sopocachi, La Paz.</span></div>
          </div>
          <div class="info-item">
            <span class="ico">📞</span>
            <div><strong>WhatsApp</strong><span>+591 70 000 000</span></div>
          </div>
          <div class="info-item">
            <span class="ico">📧</span>
            <div><strong>Correo</strong><span>info@floreria-alesli.com</span></div>
          </div>
          <div class="info-item">
            <span class="ico">🕒</span>
            <div><strong>Horario</strong><span>Lun – Sáb: 08:00 – 20:00<br>Dom: 09:00 – 14:00</span></div>
          </div>
        </div>
      </div>
    </section>

    <div class="stats-band">
      <div class="stat-item"><strong>1,200+</strong><span>Clientes felices</span></div>
      <div class="stat-item"><strong>10</strong><span>Años de experiencia</span></div>
      <div class="stat-item"><strong>98%</strong><span>Satisfacción</span></div>
      <div class="stat-item"><strong>Mismo día</strong><span>Entrega en La Paz</span></div>
    </div>

    <section class="servicios">
      <span class="seccion-tag">SERVICIOS</span>
      <h2>¿Qué ofrecemos?</h2>
      <div class="servicios-grid">
        <div class="servicio-box">
          <div class="icon-box-circle">🚚</div>
          <h3>Entregas a Domicilio</h3>
          <p>Envíos en toda La Paz. Pedidos antes de las 14:00 se entregan el mismo día con garantía de frescura total.</p>
        </div>
        <div class="servicio-box">
          <div class="icon-box-circle">✏️</div>
          <h3>Arreglos Personalizados</h3>
          <p>Diseñamos el ramo de tus sueños. Cuéntanos la ocasión, los colores y el presupuesto; nosotros hacemos el resto.</p>
        </div>
        <div class="servicio-box">
          <div class="icon-box-circle">🎉</div>
          <h3>Eventos y Bodas</h3>
          <p>Decoración floral completa para bodas, quinceañeras, cumpleaños y eventos corporativos. Presupuesto sin costo.</p>
        </div>
        <div class="servicio-box">
          <div class="icon-box-circle">🔄</div>
          <h3>Política de Devolución</h3>
          <p>Aceptamos cambios dentro de las 12 horas si hay defectos de calidad. Tu satisfacción es nuestra prioridad.</p>
        </div>
      </div>
    </section>

    <section class="equipo">
      <span class="seccion-tag">EQUIPO</span>
      <h2>Las personas detrás de cada ramo</h2>
      <div class="equipo-grid">
        <div class="equipo-card">
          <div class="avatar-circle">👩</div>
          <h4>Alesli Mamani</h4>
          <span>Fundadora &amp; Diseñadora</span>
        </div>
        <div class="equipo-card">
          <div class="avatar-circle">👩‍🌾</div>
          <h4>María Quispe</h4>
          <span>Florista Senior</span>
        </div>
        <div class="equipo-card">
          <div class="avatar-circle">👨</div>
          <h4>Carlos Flores</h4>
          <span>Repartidor</span>
        </div>
        <div class="equipo-card">
          <div class="avatar-circle">👩‍💼</div>
          <h4>Lucía Torres</h4>
          <span>Atención al cliente</span>
        </div>
      </div>
    </section>

    <section class="map-section">
      <h2>¿Dónde estamos?</h2>
      <div class="map-wrapper">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d402.08221787469876!2d-68.1223900721661!3d-16.512346366439825!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x915f21ee1f938795%3A0x71f9216e03298c64!2zQWxlc2zDrQ!5e0!3m2!1ses!2sbo!4v1778820795755!5m2!1ses!2sbo"
          width="100%" height="420" style="border:0;display:block;" allowfullscreen loading="lazy"></iframe>
      </div>
    </section>

    <section class="contacto-section">
      <span class="seccion-tag">CONTÁCTANOS</span>
      <h2>¿Listo para sorprender a alguien?</h2>
      <p style="color:#888;max-width:500px;margin:0 auto;">Escríbenos y creamos juntos el arreglo perfecto para tu ocasión especial.</p>
      <div class="contacto-grid">
        <div class="contacto-card"><div class="ico">📞</div><h4>Llámanos</h4><p>+591 70 000 000</p></div>
        <div class="contacto-card"><div class="ico">📧</div><h4>Escríbenos</h4><p>info@floreria-alesli.com</p></div>
        <div class="contacto-card"><div class="ico">📍</div><h4>Visítanos</h4><p>Av. Las Flores #123<br>Sopocachi, La Paz</p></div>
      </div>
      <a href="https://wa.me/59170000000?text=Hola%2C%20quiero%20un%20arreglo%20floral" target="_blank" class="wa-btn">
        <ion-icon name="logo-whatsapp"></ion-icon>
        Pedir por WhatsApp
      </a>
    </section>

  </main>

  <footer class="footer">
    <div class="footer-logo">🌸 Florería Alesli</div>
    <div class="copyright">© 2026 Florería Alesli. Hecho con ✨ para ti.</div>
  </footer>

  <script src="assets/js/cliente-auth.js"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="assets/js/petalos-global.js"></script>
</body>
</html>
