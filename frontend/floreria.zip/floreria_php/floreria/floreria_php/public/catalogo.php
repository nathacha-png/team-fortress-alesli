<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Catálogo — Florería Alesli</title>
  <link rel="stylesheet" href="assets/css/estilo.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;1,400&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    /* ── Catálogo layout ── */
    .catalogo-hero {
      background: linear-gradient(135deg, #fff0f5 0%, #fde8f0 100%);
      padding: 120px 10% 60px;
      text-align: center;
    }
    .catalogo-hero h1 { font-size: 3rem; margin-bottom: .5rem; }
    .catalogo-hero p  { color: #888; max-width: 520px; margin: 0 auto 2rem; }

    /* Filtros */
    .filtros {
      display: flex;
      justify-content: center;
      gap: .6rem;
      flex-wrap: wrap;
      margin-bottom: 2.5rem;
    }
    .filtro-btn {
      background: #fff;
      border: 2px solid #e8c5d5;
      color: #8c2f51;
      padding: .45rem 1.2rem;
      border-radius: 2rem;
      font-size: .85rem;
      font-weight: 600;
      cursor: pointer;
      transition: all .2s;
      font-family: 'Poppins', sans-serif;
    }
    .filtro-btn:hover, .filtro-btn.activo {
      background: #c24d77;
      border-color: #c24d77;
      color: #fff;
    }

    /* Grid */
    .catalogo-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
      gap: 2rem;
      padding: 0 10% 80px;
      max-width: 1400px;
      margin: 0 auto;
    }

    /* Skeleton loader */
    .skeleton-card {
      background: #fff;
      border-radius: 30px;
      overflow: hidden;
      box-shadow: 0 8px 25px rgba(194,77,119,.07);
    }
    .skeleton-img  { width:100%; height:240px; background: linear-gradient(90deg,#f5e6ed 25%,#fdf0f5 50%,#f5e6ed 75%); background-size:200%; animation: shimmer 1.4s infinite; }
    .skeleton-body { padding: 1.2rem; }
    .skeleton-line { height:14px; background: linear-gradient(90deg,#f5e6ed 25%,#fdf0f5 50%,#f5e6ed 75%); background-size:200%; animation: shimmer 1.4s infinite; border-radius:8px; margin-bottom:.7rem; }
    .skeleton-line.short { width:60%; }
    @keyframes shimmer { to { background-position: -200% center; } }

    /* Product card mejorado */
    .product-card { position: relative; }
    .badge-agotado {
      position: absolute; top: 14px; right: 14px;
      background: #ef4444; color: #fff;
      font-size:.7rem; font-weight:700; padding:.25rem .6rem;
      border-radius: 1rem; letter-spacing:.04em;
      pointer-events: none;
    }
    .badge-new {
      position: absolute; top: 14px; left: 14px;
      background: #c24d77; color: #fff;
      font-size:.7rem; font-weight:700; padding:.25rem .6rem;
      border-radius: 1rem; letter-spacing:.04em;
      pointer-events: none;
    }
    .stock-badge {
      display: inline-block;
      font-size: .72rem;
      color: #10b981;
      font-weight: 600;
      margin-bottom: .4rem;
    }
    .stock-badge.low { color: #f59e0b; }

    /* Modal detalle */
    .detalle-overlay {
      display: none;
      position: fixed; inset: 0; z-index: 9000;
      background: rgba(0,0,0,.5); backdrop-filter: blur(4px);
      align-items: center; justify-content: center;
    }
    .detalle-overlay.open { display: flex; }
    .detalle-modal {
      background: #fff;
      border-radius: 1.5rem;
      width: min(700px, 94vw);
      max-height: 90vh;
      overflow-y: auto;
      display: grid;
      grid-template-columns: 1fr 1fr;
      box-shadow: 0 30px 80px rgba(194,77,119,.2);
      position: relative;
    }
    @media(max-width:600px) { .detalle-modal { grid-template-columns: 1fr; } }
    .detalle-img { width:100%; height:320px; object-fit:cover; border-radius: 1.5rem 0 0 1.5rem; }
    @media(max-width:600px) { .detalle-img { height:220px; border-radius:1.5rem 1.5rem 0 0; } }
    .detalle-body { padding: 2rem 1.8rem; display:flex; flex-direction:column; }
    .detalle-categoria { font-size:.75rem; font-weight:700; color:#c24d77; letter-spacing:.08em; text-transform:uppercase; margin-bottom:.5rem; }
    .detalle-nombre { font-family:'Playfair Display',serif; font-size:1.7rem; color:#333; margin:0 0 .5rem; }
    .detalle-precio { font-size:1.8rem; font-weight:700; color:#c24d77; margin-bottom:1rem; }
    .detalle-desc  { font-size:.9rem; color:#666; line-height:1.7; flex:1; margin-bottom:1.2rem; }
    .detalle-stock { font-size:.82rem; color:#10b981; font-weight:600; margin-bottom:1.2rem; }
    .detalle-stock.low { color:#f59e0b; }
    .detalle-qty   { display:flex; align-items:center; gap:.8rem; margin-bottom:1.2rem; }
    .detalle-qty button { background:#f5e6ed; border:none; width:34px; height:34px; border-radius:50%; font-size:1.2rem; font-weight:700; color:#8c2f51; cursor:pointer; }
    .detalle-qty span { font-size:1.1rem; font-weight:600; min-width:24px; text-align:center; }
    .detalle-add { background:#c24d77; color:#fff; border:none; width:100%; padding:.9rem; border-radius:1rem; font-size:1rem; font-weight:700; cursor:pointer; transition:background .2s; }
    .detalle-add:hover { background:#a83d63; }
    .detalle-add:disabled { background:#e5a0b5; cursor:not-allowed; }
    .detalle-close { position:absolute; top:.9rem; right:1rem; background:none; border:none; font-size:1.4rem; cursor:pointer; color:#999; z-index:10; }

    /* Vacío / error */
    .catalogo-empty { text-align:center; padding:5rem 1rem; color:#aaa; grid-column:1/-1; }
    .catalogo-empty svg { width:64px; display:block; margin:0 auto 1rem; opacity:.3; }

    /* Toast */
    #cat-toast { position:fixed; bottom:1.5rem; right:1.5rem; z-index:8000; display:flex; flex-direction:column; gap:.5rem; }
    .cat-toast-msg { background:#10b981; color:#fff; padding:.7rem 1.2rem; border-radius:.6rem; font-size:.88rem; box-shadow:0 4px 14px rgba(0,0,0,.15); animation:fadeup .25s ease; font-family:'Poppins',sans-serif; }
    .cat-toast-msg.err { background:#ef4444; }
    @keyframes fadeup { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:none} }

    /* FAB carrito */
    .fab-cart { position:fixed; bottom:1.4rem; right:1.4rem; background:#c24d77; color:#fff; width:56px; height:56px; border-radius:50%; display:flex; align-items:center; justify-content:center; box-shadow:0 6px 20px rgba(194,77,119,.45); text-decoration:none; z-index:900; transition:transform .2s; }
    .fab-cart:hover { transform:translateY(-4px); }
    .fab-cart ion-icon { font-size:1.5rem; }
    .fab-badge { position:absolute; top:-4px; right:-4px; background:#333; color:#fff; font-size:.65rem; font-weight:700; width:20px; height:20px; border-radius:50%; display:none; align-items:center; justify-content:center; }
    .fab-badge.visible { display:flex; }
  </style>
</head>
<body>
  <header class="nav-bar">
    <div class="logo">Floreria <span>alesli</span></div>
    <nav>
      <a href="index.php">Inicio</a>
      <a href="catalogo.php" style="color:#c24d77;font-weight:600;">Catálogo</a>
      <a href="nosotros.php">Nosotros</a>
      <a href="nosotros.php#contacto">Contacto</a>
    </nav>
    <div class="action">
      <button class="btn-login">Entrar</button>
    </div>
  </header>

  <!-- Hero del catálogo -->
  <div class="catalogo-hero">
    <p class="tag-line">🌸 Nuestras flores</p>
    <h1>Elige tu <span>ramo perfecto</span></h1>
    <p>Arreglos frescos, entrega el mismo día en La Paz. Filtra por categoría o busca tu flor favorita.</p>

    <!-- Búsqueda -->
    <div style="max-width:440px;margin:0 auto 1.5rem;position:relative;">
      <input id="busqueda" type="text" placeholder="Buscar producto…"
        style="width:100%;padding:.75rem 1.2rem .75rem 2.8rem;border:2px solid #f5d5e2;border-radius:2rem;font-size:.9rem;font-family:'Poppins',sans-serif;outline:none;box-sizing:border-box;color:#333;"
        oninput="filtrarProductos()">
      <span style="position:absolute;left:.95rem;top:50%;transform:translateY(-50%);color:#c24d77;font-size:1.05rem;">🔍</span>
    </div>

    <!-- Filtros de categoría -->
    <div class="filtros" id="filtros">
      <button class="filtro-btn activo" data-cat="todos" onclick="setCategoria('todos',this)">Todos</button>
    </div>
  </div>

  <!-- Grid de productos -->
  <div class="catalogo-grid" id="catalogo-grid">
    <!-- skeletons mientras carga -->
    <div class="skeleton-card"><div class="skeleton-img"></div><div class="skeleton-body"><div class="skeleton-line"></div><div class="skeleton-line short"></div></div></div>
    <div class="skeleton-card"><div class="skeleton-img"></div><div class="skeleton-body"><div class="skeleton-line"></div><div class="skeleton-line short"></div></div></div>
    <div class="skeleton-card"><div class="skeleton-img"></div><div class="skeleton-body"><div class="skeleton-line"></div><div class="skeleton-line short"></div></div></div>
    <div class="skeleton-card"><div class="skeleton-img"></div><div class="skeleton-body"><div class="skeleton-line"></div><div class="skeleton-line short"></div></div></div>
  </div>

  <!-- Modal detalle -->
  <div class="detalle-overlay" id="detalle-overlay" onclick="if(event.target===this)cerrarDetalle()">
    <div class="detalle-modal" id="detalle-modal">
      <button class="detalle-close" onclick="cerrarDetalle()">✕</button>
      <img id="det-img" class="detalle-img" src="assets/img/flores1.jpeg" alt="">
      <div class="detalle-body">
        <div class="detalle-categoria" id="det-cat"></div>
        <h2 class="detalle-nombre" id="det-nombre"></h2>
        <div class="detalle-precio" id="det-precio"></div>
        <p class="detalle-desc" id="det-desc"></p>
        <div class="detalle-stock" id="det-stock"></div>
        <div class="detalle-qty">
          <button onclick="cambiarQty(-1)">−</button>
          <span id="det-qty">1</span>
          <button onclick="cambiarQty(1)">+</button>
        </div>
        <button class="detalle-add" id="det-add" onclick="agregarDesdeDetalle()">🛒 Añadir al carrito</button>
      </div>
    </div>
  </div>

  <!-- Toast -->
  <div id="cat-toast"></div>

  <!-- FAB carrito -->
  <a href="carrito.php" class="fab-cart">
    <ion-icon name="cart-outline"></ion-icon>
    <span class="fab-badge" id="fab-badge">0</span>
  </a>

  <footer class="footer" style="margin-top:2rem;">
    <div class="footer-logo">🌸 Florería Alesli</div>
    <div class="copyright">© 2026 Florería Alesli. Hecho con ✨ para ti.</div>
  </footer>

  <script src="assets/js/cliente-auth.js"></script>
  <script>
  /* ── Estado ── */
  let todosLosProductos = [];
  let categoriaActiva   = 'todos';
  let productoDetalle   = null;
  let qtyDetalle        = 1;

  /* ── Toast ── */
  function toast(msg, tipo='ok') {
    const box = document.getElementById('cat-toast');
    const t   = document.createElement('div');
    t.className = 'cat-toast-msg' + (tipo==='err' ? ' err' : '');
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(() => t.remove(), 3400);
  }

  /* ── Cargar productos ── */
  async function cargarCatalogo() {
    try {
      const res = await fetch('../api/productos.php');
      todosLosProductos = await res.json();
      if (!Array.isArray(todosLosProductos)) todosLosProductos = [];
      construirFiltros();
      renderProductos();
      actualizarFAB();
    } catch {
      document.getElementById('catalogo-grid').innerHTML =
        '<div class="catalogo-empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 9v3m0 3h.01M10.29 3.86 1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></svg><p>No se pudo cargar el catálogo.<br><small>Verifica la conexión con el servidor.</small></p></div>';
    }
  }

  /* ── Construir botones de categoría ── */
  function construirFiltros() {
    const cats = [...new Set(todosLosProductos.map(p => p.categoria).filter(Boolean))].sort();
    const box  = document.getElementById('filtros');
    cats.forEach(cat => {
      const btn = document.createElement('button');
      btn.className   = 'filtro-btn';
      btn.dataset.cat = cat;
      btn.textContent = cat;
      btn.onclick     = () => setCategoria(cat, btn);
      box.appendChild(btn);
    });
  }

  function setCategoria(cat, btn) {
    categoriaActiva = cat;
    document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('activo'));
    btn.classList.add('activo');
    renderProductos();
  }

  /* ── Filtrar por búsqueda ── */
  function filtrarProductos() { renderProductos(); }

  /* ── Render ── */
  function renderProductos() {
    const q    = (document.getElementById('busqueda').value || '').toLowerCase();
    const grid = document.getElementById('catalogo-grid');

    let lista = todosLosProductos.filter(p => p.estado === 'activo' || p.estado === 'agotado');
    if (categoriaActiva !== 'todos') lista = lista.filter(p => p.categoria === categoriaActiva);
    if (q) lista = lista.filter(p =>
      (p.nombre + ' ' + p.descripcion + ' ' + p.categoria).toLowerCase().includes(q)
    );

    if (!lista.length) {
      grid.innerHTML = '<div class="catalogo-empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><p>Sin resultados para esa búsqueda.</p></div>';
      return;
    }

    grid.innerHTML = lista.map(p => {
      const agotado  = p.estado === 'agotado' || p.stock === 0;
      const stockTxt = agotado ? '' : p.stock <= 5
        ? `<span class="stock-badge low">⚠ Solo ${p.stock} disponibles</span><br>`
        : `<span class="stock-badge">✓ En stock</span><br>`;
      const foto = p.foto ? `../uploads/${p.foto}` : 'assets/img/flores1.jpeg';
      return `
        <div class="product-card" id="pc-${p.id}">
          ${agotado ? '<span class="badge-agotado">Agotado</span>' : ''}
          <div class="product-image" style="cursor:pointer" onclick="abrirDetalle(${p.id})">
            <img src="${foto}" alt="${p.nombre}" onerror="this.src='assets/img/flores1.jpeg'" style="width:100%;height:100%;object-fit:cover;">
          </div>
          <div class="product-info">
            <h3>${p.nombre}</h3>
            <p class="price">${parseFloat(p.precio).toFixed(2)} Bs.</p>
            ${stockTxt}
            <p class="product-desc">${(p.descripcion || '').substring(0, 80)}${(p.descripcion||'').length>80?'…':''}</p>
            <div class="product-action">
              <button class="btn-info" onclick="abrirDetalle(${p.id})">Ver detalles</button>
              <button class="btn-cart" onclick="agregarAlCarrito(${p.id})" ${agotado?'disabled style="opacity:.5;cursor:not-allowed"':''}>🛒 Añadir</button>
            </div>
          </div>
        </div>`;
    }).join('');
  }

  /* ── Detalle ── */
  function abrirDetalle(id) {
    productoDetalle = todosLosProductos.find(p => p.id === id);
    if (!productoDetalle) return;
    qtyDetalle = 1;
    const p    = productoDetalle;
    const foto = p.foto ? `../uploads/${p.foto}` : 'assets/img/flores1.jpeg';
    const agotado = p.estado === 'agotado' || p.stock === 0;

    document.getElementById('det-img').src      = foto;
    document.getElementById('det-img').onerror  = function(){ this.src='assets/img/flores1.jpeg'; };
    document.getElementById('det-cat').textContent    = p.categoria || 'Producto';
    document.getElementById('det-nombre').textContent = p.nombre;
    document.getElementById('det-precio').textContent = parseFloat(p.precio).toFixed(2) + ' Bs.';
    document.getElementById('det-desc').textContent   = p.descripcion || 'Sin descripción.';
    document.getElementById('det-qty').textContent    = 1;

    const stockEl = document.getElementById('det-stock');
    if (agotado) {
      stockEl.textContent = '✗ Producto agotado';
      stockEl.className   = 'detalle-stock low';
    } else if (p.stock <= 5) {
      stockEl.textContent = `⚠ Solo ${p.stock} unidades disponibles`;
      stockEl.className   = 'detalle-stock low';
    } else {
      stockEl.textContent = `✓ ${p.stock} unidades disponibles`;
      stockEl.className   = 'detalle-stock';
    }

    const addBtn = document.getElementById('det-add');
    addBtn.disabled  = agotado;
    addBtn.textContent = agotado ? 'Sin stock' : '🛒 Añadir al carrito';

    document.getElementById('detalle-overlay').classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function cerrarDetalle() {
    document.getElementById('detalle-overlay').classList.remove('open');
    document.body.style.overflow = '';
  }

  function cambiarQty(delta) {
    if (!productoDetalle) return;
    const max = productoDetalle.stock || 99;
    qtyDetalle = Math.max(1, Math.min(max, qtyDetalle + delta));
    document.getElementById('det-qty').textContent = qtyDetalle;
  }

  async function agregarDesdeDetalle() {
    if (!productoDetalle) return;
    await agregarAlCarrito(productoDetalle.id, qtyDetalle);
    cerrarDetalle();
  }

  /* ── Agregar al carrito ── */
  async function agregarAlCarrito(idProducto, cantidad = 1) {
    const sesion = AuthModal.getSession();
    if (!sesion) { AuthModal.open('login'); return; }
    try {
      const res = await fetch('../api/carrito.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id_usuario: sesion.id, id_producto: idProducto, cantidad }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Error');
      toast('🛒 Agregado al carrito');
      actualizarFAB();
    } catch(e) {
      toast(e.message, 'err');
    }
  }

  /* ── FAB: mostrar cantidad en carrito ── */
  async function actualizarFAB() {
    const sesion = AuthModal.getSession();
    if (!sesion) return;
    try {
      const res   = await fetch(`../api/carrito.php?id_usuario=${sesion.id}`);
      const items = await res.json();
      const count = Array.isArray(items) ? items.reduce((s, i) => s + i.cantidad, 0) : 0;
      const badge = document.getElementById('fab-badge');
      badge.textContent = count;
      badge.classList.toggle('visible', count > 0);
    } catch { /* silencioso */ }
  }

  /* ── Init ── */
  cargarCatalogo();
  </script>

  <script src="https://cdn.jsdelivr.net/npm/tsparticles-confetti@2.12.0/tsparticles.confetti.bundle.min.js"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="assets/js/petalos-global.js"></script>
</body>
</html>
