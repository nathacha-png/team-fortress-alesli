/* petalos-global.js — Pétalos CSS que caen en todas las vistas */
(function () {
  const EMOJIS = ['🌸','🌺','🌷','🌹','💮'];
  const TOTAL   = 18;

  const style = document.createElement('style');
  style.textContent = `
    .petalo-fall {
      position: fixed;
      top: -60px;
      font-size: 1.4rem;
      opacity: 0;
      pointer-events: none;
      z-index: 99999;
      animation: petalo-caer linear infinite;
      user-select: none;
    }
    @keyframes petalo-caer {
      0%   { transform: translateY(0)   rotate(0deg)   scale(1);   opacity: 0; }
      5%   { opacity: 0.85; }
      90%  { opacity: 0.7; }
      100% { transform: translateY(110vh) rotate(720deg) scale(0.6); opacity: 0; }
    }
  `;
  document.head.appendChild(style);

  function crearPetalo() {
    const el = document.createElement('span');
    el.className  = 'petalo-fall';
    el.textContent = EMOJIS[Math.floor(Math.random() * EMOJIS.length)];

    const duracion = (Math.random() * 7 + 6).toFixed(1);   // 6s – 13s
    const delay    = (Math.random() * 10).toFixed(1);        // 0s – 10s
    const left     = (Math.random() * 100).toFixed(1);       // 0% – 100%
    const size     = (Math.random() * 0.9 + 0.9).toFixed(2); // 0.9 – 1.8rem
    const drift    = (Math.random() * 80 - 40).toFixed(0);   // -40px – +40px

    el.style.cssText += `
      left: ${left}%;
      font-size: ${size}rem;
      animation-duration: ${duracion}s;
      animation-delay: ${delay}s;
      filter: hue-rotate(${Math.random()*60}deg) drop-shadow(0 2px 4px rgba(194,77,119,.3));
      margin-left: ${drift}px;
    `;

    document.body.appendChild(el);

    // Reciclar el pétalo al terminar en lugar de acumular en el DOM
    const totalMs = (parseFloat(duracion) + parseFloat(delay)) * 1000;
    setTimeout(() => {
      el.remove();
      crearPetalo(); // reemplazar por uno nuevo
    }, totalMs + 200);
  }

  // Arrancar cuando el DOM esté listo
  function init() {
    for (let i = 0; i < TOTAL; i++) {
      setTimeout(crearPetalo, i * 400); // escalonar la aparición inicial
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
