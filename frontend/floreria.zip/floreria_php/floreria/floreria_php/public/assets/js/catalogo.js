// ══════════════════════════════════════════
//  catalogo.js  —  Lógica de Catálogo / Stock
//  Los datos se inyectan desde la BD vía window.PRODUCTOS
// ══════════════════════════════════════════

// Estado
let currentFilter = 'todos';
let currentView   = 'tabla';   // 'tabla' | 'grid'

// ── Constantes ───────────────────────────────
const STOCK_MIN_CRITICO = 5;
const STOCK_MIN_BAJO    = 10;

// ── Utilidades ───────────────────────────────
function getStockClass(qty) {
  if (qty <= STOCK_MIN_CRITICO) return 'critical';
  if (qty <= STOCK_MIN_BAJO)    return 'low';
  return 'ok';
}

function getStockLabel(qty) {
  if (qty === 0)                return 'agotado';
  if (qty <= STOCK_MIN_BAJO)    return 'bajo';
  return 'disponible';
}

function getStockPct(qty, max = 50) {
  return Math.min(100, Math.round((qty / max) * 100));
}

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// ── Fecha en vivo ────────────────────────────
function updateDate() {
  const d    = new Date();
  const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const el   = document.getElementById('live-date');
  if (el) el.textContent = d.toLocaleDateString('es-BO', opts);
}

// ── Stats ────────────────────────────────────
function updateStats(data) {
  const total     = data.length;
  const agotados  = data.filter(p => p.stock === 0).length;
  const bajos     = data.filter(p => p.stock > 0 && p.stock <= STOCK_MIN_BAJO).length;
  const ok        = data.filter(p => p.stock > STOCK_MIN_BAJO).length;

  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('stat-total',    total);
  set('stat-agotados', agotados);
  set('stat-bajos',    bajos);
  set('stat-ok',       ok);

  // Banner de alerta
  const banner = document.getElementById('stock-alert-banner');
  const count  = agotados + bajos;
  if (banner) {
    if (count > 0) {
      banner.style.display = 'flex';
      const countEl = banner.querySelector('.alert-count');
      if (countEl) countEl.textContent = `${count} producto${count > 1 ? 's' : ''}`;
    } else {
      banner.style.display = 'none';
    }
  }
}

// ── Render tabla ─────────────────────────────
function renderTabla(list) {
  const tbody = document.getElementById('table-body');
  if (!tbody) return;

  tbody.innerHTML = list.map(p => {
    const cls = getStockClass(p.stock);
    const lbl = getStockLabel(p.stock);
    const pct = getStockPct(p.stock);
    return `
      <tr>
        <td class="product-id">#${p.id}</td>
        <td>
          <div class="product-cell">
            <div class="product-thumb">
              <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
            </div>
            <div>
              <div class="product-name-cell">${p.nombre}</div>
              <div class="product-cat">${p.categoria}</div>
            </div>
          </div>
        </td>
        <td class="price-cell">Bs. ${p.precio}</td>
        <td>
          <div class="stock-cell">
            <span class="stock-num ${cls}">${p.stock} u.</span>
            <div class="stock-bar-wrap">
              <div class="stock-bar ${cls}" style="width:${pct}%;"></div>
            </div>
          </div>
        </td>
        <td>
          <span class="badge ${lbl}">
            <span class="badge-dot"></span>
            ${capitalize(lbl)}
          </span>
        </td>
        <td>
          <div class="actions-cell">
            <button class="btn-icon" title="Editar" onclick="openEditModal('${p.id}')">
              <svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="btn-icon" title="Ajustar stock" onclick="openStockModal('${p.id}')">
              <svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </button>
            <button class="btn-icon" title="Eliminar" onclick="deleteProduct('${p.id}')">
              <svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

// ── Render grid ──────────────────────────────
function renderGrid(list) {
  const grid = document.getElementById('products-grid');
  if (!grid) return;

  grid.innerHTML = list.map(p => {
    const cls  = getStockClass(p.stock);
    const lbl  = getStockLabel(p.stock);
    const colors = { ok: '#10b981', low: '#f59e0b', critical: '#ef4444' };
    return `
      <div class="product-card">
        <div class="product-card-icon">
          <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
        </div>
        <div>
          <div class="product-card-name">${p.nombre}</div>
          <div class="product-card-cat">${p.categoria}</div>
        </div>
        <div class="product-card-footer">
          <span class="product-card-price">Bs. ${p.precio}</span>
          <span class="product-card-stock">
            <span class="dot" style="background:${colors[cls]};"></span>
            ${p.stock} u.
          </span>
        </div>
        <div class="product-card-actions">
          <button class="btn-outline" style="flex:1; justify-content:center; font-size:.75rem; padding:6px 8px;"
                  onclick="openStockModal('${p.id}')">+ Stock</button>
          <button class="btn-icon" onclick="openEditModal('${p.id}')">
            <svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
        </div>
      </div>
    `;
  }).join('');
}

// ── Filtros y búsqueda ───────────────────────
function setFilter(btn) {
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentFilter = btn.dataset.status;
  applyFilters();
}

function filterTable() {
  applyFilters();
}

function applyFilters() {
  const q    = (document.getElementById('search-input')?.value || '').toLowerCase();
  const data = window.PRODUCTOS || [];

  let list = data;

  // Filtro por estado de stock
  if (currentFilter === 'disponible') list = list.filter(p => p.stock > STOCK_MIN_BAJO);
  else if (currentFilter === 'bajo')  list = list.filter(p => p.stock > 0 && p.stock <= STOCK_MIN_BAJO);
  else if (currentFilter === 'agotado') list = list.filter(p => p.stock === 0);

  // Búsqueda
  if (q) list = list.filter(p =>
    p.nombre.toLowerCase().includes(q) ||
    p.categoria.toLowerCase().includes(q) ||
    String(p.id).includes(q)
  );

  // Render según vista activa
  const tableCard  = document.getElementById('table-card');
  const gridWrap   = document.getElementById('grid-wrap');

  if (currentView === 'tabla') {
    if (tableCard) tableCard.style.display = '';
    if (gridWrap)  gridWrap.style.display  = 'none';
    renderTabla(list);
  } else {
    if (tableCard) tableCard.style.display = 'none';
    if (gridWrap)  gridWrap.style.display  = '';
    renderGrid(list);
  }

  const info = document.getElementById('pagination-info');
  if (info) info.textContent = `Mostrando ${list.length} de ${data.length} productos`;

  updateStats(data);
}

// ── Cambio de vista tabla / grid ─────────────
function setView(view) {
  currentView = view;
  document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
  const btn = document.getElementById('view-btn-' + view);
  if (btn) btn.classList.add('active');
  applyFilters();
}

// ── ID del producto en edición (null = nuevo) ─
let _editingProductId = null;

// ── Modal nuevo / editar producto ────────────
function openModal() {
  _editingProductId = null;
  const title = document.getElementById('modal-product-title');
  if (title) title.textContent = 'Nuevo Producto';
  // Limpiar formulario
  ['f-nombre','f-categoria','f-precio','f-stock','f-descripcion'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = id === 'f-categoria' ? 'General' : (id === 'f-stock' ? '0' : '');
  });
  const estadoEl = document.getElementById('f-estado');
  if (estadoEl) estadoEl.value = 'activo';
  document.getElementById('modal-product')?.classList.add('open');
}

function openEditModal(id) {
  const data = window.PRODUCTOS || [];
  const p    = data.find(x => String(x.id) === String(id));
  if (!p) return;

  _editingProductId = p.id;

  const title = document.getElementById('modal-product-title');
  if (title) title.textContent = 'Editar Producto';

  // Poblar formulario con datos del producto
  const set = (elId, val) => { const el = document.getElementById(elId); if (el) el.value = val ?? ''; };
  set('f-nombre',      p.nombre);
  set('f-categoria',   p.categoria);
  set('f-precio',      p.precio);
  set('f-stock',       p.stock);
  set('f-descripcion', p.descripcion);
  const estadoEl = document.getElementById('f-estado');
  if (estadoEl) estadoEl.value = p.estado || 'activo';

  document.getElementById('modal-product')?.classList.add('open');
}

function closeModal() {
  document.getElementById('modal-product')?.classList.remove('open');
  _editingProductId = null;
}

async function saveProduct() {
  const nombre      = document.getElementById('f-nombre')?.value?.trim() ?? '';
  const categoria   = document.getElementById('f-categoria')?.value ?? 'General';
  const precio      = parseFloat(document.getElementById('f-precio')?.value ?? 0);
  const stock       = parseInt(document.getElementById('f-stock')?.value ?? 0);
  const descripcion = document.getElementById('f-descripcion')?.value?.trim() ?? '';
  const estado      = document.getElementById('f-estado')?.value ?? 'activo';

  if (!nombre || isNaN(precio) || precio < 0) {
    alert('❌ Nombre y precio válido son obligatorios'); return;
  }

  try {
    if (_editingProductId) {
      // ── EDITAR: PUT a productos.php
      const res = await fetch('../../api/productos.php', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: _editingProductId, nombre, categoria, precio, stock, descripcion, estado }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Error al editar');
    } else {
      // ── CREAR: POST a productos/create.php (multipart para soporte de foto)
      const fd = new FormData();
      fd.append('nombre',      nombre);
      fd.append('categoria',   categoria);
      fd.append('precio',      precio);
      fd.append('stock',       stock);
      fd.append('descripcion', descripcion);
      fd.append('estado',      estado);
      const fotoInput = document.getElementById('f-foto');
      if (fotoInput && fotoInput.files[0]) fd.append('foto', fotoInput.files[0]);
      const res = await fetch('../../api/productos/create.php', { method: 'POST', body: fd });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Error al crear');
    }
    // Recargar lista desde BD
    const data = await fetch('../../api/productos.php').then(r => r.json());
    window.PRODUCTOS = data;
    applyFilters();
    closeModal();
    alert(_editingProductId ? '✅ Producto actualizado' : '✅ Producto creado correctamente');
  } catch (e) {
    alert('❌ ' + e.message);
  }
}

// ── Modal ajuste de stock ─────────────────────
let _stockProductId = null;

function openStockModal(id) {
  _stockProductId = id;
  const data = window.PRODUCTOS || [];
  const p    = data.find(x => String(x.id) === String(id));
  if (!p) return;

  const nameEl = document.getElementById('stock-modal-name');
  const currEl = document.getElementById('stock-modal-current');
  const inputEl = document.getElementById('stock-ajuste-input');

  if (nameEl) nameEl.textContent = p.nombre;
  if (currEl) currEl.textContent = `Stock actual: ${p.stock} unidades`;
  if (inputEl) inputEl.value = 0;

  document.getElementById('modal-stock')?.classList.add('open');
}

function closeStockModal() {
  document.getElementById('modal-stock')?.classList.remove('open');
  _stockProductId = null;
}

function changeStockInput(delta) {
  const input = document.getElementById('stock-ajuste-input');
  if (!input) return;
  const val = parseInt(input.value) || 0;
  input.value = Math.max(-999, val + delta);
}

async function saveStockAjuste() {
  if (!_stockProductId) return;
  const ajuste = parseInt(document.getElementById('stock-ajuste-input')?.value) || 0;
  if (ajuste === 0) { closeStockModal(); return; }

  const data = window.PRODUCTOS || [];
  const p    = data.find(x => String(x.id) === String(_stockProductId));
  if (!p) return;

  const nuevoStock = Math.max(0, p.stock + ajuste);

  try {
    const res = await fetch('../../api/productos.php', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: _stockProductId, stock: nuevoStock }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Error al actualizar stock');

    // Actualizar localmente
    p.stock  = json.stock;
    p.estado = json.estado;
    applyFilters();
    closeStockModal();
    alert(`✅ Stock actualizado a ${nuevoStock} unidades`);
  } catch (e) {
    alert('❌ ' + e.message);
  }
}

// ── Eliminar producto ─────────────────────────
async function deleteProduct(id) {
  if (!confirm('¿Eliminar este producto del catálogo? Esta acción no se puede deshacer.')) return;

  try {
    const res = await fetch(`../../api/productos.php?id=${id}`, { method: 'DELETE' });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Error al eliminar');

    // Quitar de la lista local
    if (window.PRODUCTOS) {
      window.PRODUCTOS = window.PRODUCTOS.filter(p => String(p.id) !== String(id));
      applyFilters();
    }
    alert('✅ Producto eliminado');
  } catch (e) {
    alert('❌ ' + e.message);
  }
}

// ── Sidebar móvil ────────────────────────────
function toggleSidebar() {
  document.querySelector('.sidebar')?.classList.toggle('open');
  const overlay = document.getElementById('sidebar-overlay');
  if (overlay) overlay.style.display = 'block';
}

function closeSidebar() {
  document.querySelector('.sidebar')?.classList.remove('open');
  const overlay = document.getElementById('sidebar-overlay');
  if (overlay) overlay.style.display = 'none';
}

// ── Inicialización ───────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  updateDate();
  setInterval(updateDate, 60000);
  // window.PRODUCTOS lo inyecta el fetch del HTML.
  if (window.PRODUCTOS) applyFilters();
});