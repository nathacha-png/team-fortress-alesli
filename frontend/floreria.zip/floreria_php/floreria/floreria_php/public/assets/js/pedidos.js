// ══════════════════════════════════════════
//  pedidos.js  —  Lógica de la página de pedidos
//  Los datos se inyectan desde la BD vía window.PEDIDOS
// ══════════════════════════════════════════

// Estado de la app
let currentFilter = 'todos';
let currentOrder  = null;

const statusCycle    = ['pendiente', 'preparando', 'listo', 'entregado'];
const priorityLabel  = { alta: 'Alta', media: 'Media', baja: 'Baja' };

// ── Utilidades ──────────────────────────────
function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function getInitials(name) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2);
}

// ── Fecha en vivo ────────────────────────────
function updateDate() {
  const d    = new Date();
  const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const el   = document.getElementById('live-date');
  if (el) el.textContent = d.toLocaleDateString('es-BO', opts);
}

// ── Render de filas ──────────────────────────
function renderRows(list) {
  const tbody = document.getElementById('table-body');
  if (!tbody) return;

  tbody.innerHTML = list.map(p => `
    <tr data-status="${p.status}">
      <td class="order-id">#${p.id}</td>
      <td>
        <div class="client-cell">
          <div class="client-avatar">${getInitials(p.name)}</div>
          <div>
            <div class="client-name">${p.name}</div>
            <div class="client-phone">${p.phone}</div>
          </div>
        </div>
      </td>
      <td>
        <div class="product-cell">
          <div class="product-name">${p.product}</div>
          <div class="product-detail">1 unidad</div>
        </div>
      </td>
      <td class="price-cell">${p.price}</td>
      <td class="date-cell">${p.delivery}</td>
      <td>
        <span class="priority ${p.priority}">
          <span class="priority-dot"></span>
          ${priorityLabel[p.priority]}
        </span>
      </td>
      <td>
        <span class="badge ${p.status}">
          <span class="badge-dot"></span>
          ${capitalize(p.status)}
        </span>
      </td>
      <td>
        <div class="actions-cell">
          <button class="btn-icon" title="Cambiar estado" onclick="cycleStatus('${p.id}')">
            <svg viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 014-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 01-4 4H3"/></svg>
          </button>
          <button class="btn-icon" title="Ver detalle" onclick="openDetail('${p.id}')">
            <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
          <button class="btn-icon" title="Imprimir" onclick="printOrder('${p.id}')">
            <svg viewBox="0 0 24 24"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

// ── Filtros ──────────────────────────────────
function setFilter(btn) {
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentFilter = btn.dataset.status;
  applyFilters();
}

function filterTable() {
  applyFilters();
}

function applyFilters() {
  const q    = (document.getElementById('search-input')?.value || '').toLowerCase();
  const data = window.PEDIDOS || [];

  let list = data;
  if (currentFilter !== 'todos') list = list.filter(p => p.status === currentFilter);
  if (q) list = list.filter(p =>
    p.name.toLowerCase().includes(q) ||
    p.product.toLowerCase().includes(q) ||
    String(p.id).includes(q)
  );

  renderRows(list);

  const info = document.getElementById('pagination-info');
  if (info) info.textContent = `Mostrando ${list.length} de ${data.length} pedidos`;
}

// ── Ciclo de estados ─────────────────────────
function cycleStatus(id) {
  const data  = window.PEDIDOS || [];
  const order = data.find(p => String(p.id) === String(id));
  if (!order) return;

  const idx = statusCycle.indexOf(order.status);
  if (idx < statusCycle.length - 1) {
    const nuevoEstado = statusCycle[idx + 1];
    // Persistir en BD vía API.js
    fetch('../../api/pedidos.php', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: id, estado: nuevoEstado })
    })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        order.status = nuevoEstado;
        applyFilters();
      } else {
        alert('Error al actualizar: ' + (data.error || 'desconocido'));
      }
    })
    .catch(() => alert('No se pudo conectar con el servidor.'));
  }
}

// ── Modal nuevo pedido ───────────────────────
function openModal() {
  document.getElementById('modal-new')?.classList.add('open');
}

function closeModal() {
  document.getElementById('modal-new')?.classList.remove('open');
}

function saveOrder() {
  // Aquí recogerás los valores del form y harás POST a tu BD
  closeModal();
  alert('✅ Pedido guardado correctamente');
}

// ── Panel de detalle ─────────────────────────
function openDetail(id) {
  const data = window.PEDIDOS || [];
  const p    = data.find(o => String(o.id) === String(id));
  if (!p) return;
  currentOrder = p;

  document.getElementById('d-id').textContent       = '#' + p.id;
  document.getElementById('d-name').textContent     = p.name;
  document.getElementById('d-phone').textContent    = p.phone;
  document.getElementById('d-product').textContent  = p.product;
  document.getElementById('d-price').textContent    = p.price;
  document.getElementById('d-total').textContent    = p.price;
  document.getElementById('d-delivery').textContent = p.delivery;
  document.getElementById('d-priority').textContent = priorityLabel[p.priority];

  updateTimeline(p.status);
  document.getElementById('detail-overlay')?.classList.add('open');
}

function updateTimeline(status) {
  const steps = ['recibido', 'preparando', 'listo', 'entregado'];
  const idx   = ['pendiente', 'preparando', 'listo', 'entregado'].indexOf(status);

  const times = {
    preparando: 'Hoy, 09:35',
    listo:      'Hoy, 11:20',
    entregado:  'Hoy, 11:55'
  };

  steps.forEach((s, i) => {
    const dot = document.getElementById('dot-' + s)
              || document.querySelector(`#ts-${s} .timeline-dot`);
    if (!dot) return;

    dot.className = 'timeline-dot';
    if (i < idx + 1) {
      dot.className   = 'timeline-dot done';
      dot.innerHTML   = '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>';
    } else if (i === idx + 1) {
      dot.className = 'timeline-dot curr';
      dot.innerHTML = '';
    } else {
      dot.className = 'timeline-dot pending';
      dot.innerHTML = '';
    }
  });

  ['preparando', 'listo', 'entregado'].forEach(s => {
    const el = document.getElementById('t-' + s);
    if (!el) return;
    el.textContent =
      status === s || statusCycle.indexOf(status) > statusCycle.indexOf(s)
        ? (times[s] || '—')
        : 'Pendiente';
  });
}

function closeDetail() {
  document.getElementById('detail-overlay')?.classList.remove('open');
  currentOrder = null;
}

function advanceStatus() {
  if (!currentOrder) return;
  cycleStatus(currentOrder.id);
  updateTimeline(currentOrder.status);
}

// ── Imprimir ─────────────────────────────────
function printOrder(id) {
  alert(`Imprimiendo pedido #${id}`);
  // Aquí podrás abrir una vista de impresión con los datos del pedido
}

// ── Sidebar móvil ────────────────────────────
function toggleSidebar() {
  document.querySelector('.sidebar')?.classList.toggle('open');
  const overlay = document.getElementById('sidebar-overlay');
  if (overlay) overlay.style.display = 'block';
}

function closeSidebar() {
  document.querySelector('.sidebar')?.classList.remove('open');
  const overlay = document.getElementById('sidebar-overlay');
  if (overlay) overlay.style.display = 'none';
}

// ── Inicialización ───────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  updateDate();
  setInterval(updateDate, 60000);
  // window.PEDIDOS lo inyecta el fetch del HTML; si ya llegó, renderizamos.
  if (window.PEDIDOS) applyFilters();
});