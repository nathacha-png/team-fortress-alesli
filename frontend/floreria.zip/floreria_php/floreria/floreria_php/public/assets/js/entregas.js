
// ── Estado de filtros ─────────────────────
let currentFilter = 'todas';
let searchTerm    = '';

// ── Utilidades ───────────────────────────
function initials(name) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function updateDate() {
  const el = document.getElementById('live-date');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleDateString('es-BO', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
  });
}

// ── Filtros ───────────────────────────────
function setFilter(btn) {
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentFilter = btn.dataset.status;
  renderEntregas();
}

function filterEntregas() {
  searchTerm = document.getElementById('search-input')?.value.toLowerCase() || '';
  renderEntregas();
}

function getFiltered() {
  return (window.ENTREGAS || []).filter(e => {
    const matchStatus = currentFilter === 'todas' || e.estado === currentFilter;
    const hay = `${e.cliente} ${e.direccion} ${e.zona} ${e.producto}`.toLowerCase();
    const matchSearch = !searchTerm || hay.includes(searchTerm);
    return matchStatus && matchSearch;
  });
}

// ── Render ────────────────────────────────
function renderEntregas() {
  const grid = document.getElementById('entregas-grid');
  if (!grid) return;

  const data = getFiltered();

  // Actualizar stats
  const todas        = window.ENTREGAS || [];
  const entregadas   = todas.filter(e => e.estado === 'entregado').length;
  const pendientes   = todas.filter(e => e.estado !== 'entregado').length;
  const zonas        = new Set(todas.map(e => e.zona)).size;
  document.getElementById('stat-total')?.setAttribute('data-v', todas.length);
  document.getElementById('stat-total').textContent      = todas.length;
  document.getElementById('stat-entregadas').textContent = entregadas;
  document.getElementById('stat-pendientes').textContent = pendientes;
  document.getElementById('stat-zonas').textContent      = zonas;

  if (data.length === 0) {
    grid.innerHTML = `
      <div class="entregas-empty">
        <svg viewBox="0 0 24 24"><rect x="1" y="3" width="15" height="13" rx="1"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
        No hay entregas que coincidan con los filtros.
      </div>`;
    return;
  }

  const estadoLabel = { pendiente: 'Pendiente', 'en-camino': 'En camino', entregado: 'Entregado' };

  grid.innerHTML = data.map(e => `
    <div class="entrega-card status-${e.estado}" onclick="verDetalle('${e.id}')">
      <div class="entrega-card-header">
        <span class="entrega-id">${e.id}</span>
        <span class="badge-estado ${e.estado}">${estadoLabel[e.estado]}</span>
      </div>

      <div class="entrega-cliente">
        <div class="entrega-avatar">${initials(e.cliente)}</div>
        <div>
          <div class="entrega-nombre">${e.cliente}</div>
          <div class="entrega-producto">${e.producto}</div>
        </div>
      </div>

      <div class="entrega-meta">
        <div class="entrega-meta-row">
          <svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
          <span>${e.direccion}</span>
        </div>
        <div class="entrega-meta-row">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          <span>Hora programada</span>
          <span class="entrega-hora-badge">🕐 ${e.hora}</span>
        </div>
      </div>

      ${e.notas ? `<div class="entrega-notas">📝 ${e.notas}</div>` : ''}

      <div class="entrega-card-footer" onclick="event.stopPropagation()">
        ${e.estado !== 'entregado' ? `
          <button class="btn-primary" onclick="marcarEntregado('${e.id}')">
            <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
            Entregado
          </button>
        ` : `
          <button class="btn-outline" style="flex:1; justify-content:center;" disabled>
            <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
            Completado
          </button>
        `}
        <button class="btn-icon whatsapp" title="WhatsApp" onclick="abrirWhatsApp('${e.telefono}','${e.cliente}')">
          <svg viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
        </button>
        <button class="btn-icon" title="Editar" onclick="openModalEditar('${e.id}')">
          <svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        </button>
      </div>
    </div>
  `).join('');
}

// ── Acciones ──────────────────────────────
function marcarEntregado(id) {
  const e = (window.ENTREGAS || []).find(x => x.id === id);
  if (!e) return;
  fetch('../../api/entregas.php', {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id: id, estado: 'entregado' })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) { e.estado = 'entregado'; renderEntregas(); }
    else alert('Error al actualizar: ' + (data.error || 'desconocido'));
  })
  .catch(() => alert('No se pudo conectar con el servidor.'));
}

function verDetalle(id) {
  const e = (window.ENTREGAS || []).find(x => x.id === id);
  if (!e) return;
  alert(`Entrega ${e.id}\nCliente: ${e.cliente}\nDirección: ${e.direccion}\nEstado: ${e.estado}`);
}

function abrirWhatsApp(telefono, nombre) {
  const msg = encodeURIComponent(`Hola ${nombre}, le contactamos de Florería Alesli 🌸. Su pedido está en camino.`);
  const num = telefono.replace(/\D/g, '');
  window.open(`https://wa.me/591${num}?text=${msg}`, '_blank');
}

function imprimirRuta() {
  window.print();
}

// ── Modal nueva/editar entrega ────────────
function openModal() {
  document.getElementById('modal-title').textContent = 'Nueva entrega';
  document.getElementById('edit-id').value = '';
  ['f-cliente','f-telefono','f-direccion','f-producto','f-notas'].forEach(id => {
    document.getElementById(id).value = '';
  });
  document.getElementById('f-hora').value = '';
  document.getElementById('f-estado').value = 'pendiente';
  document.getElementById('modal-entrega')?.classList.add('open');
}

function openModalEditar(id) {
  const e = (window.ENTREGAS || []).find(x => x.id === id);
  if (!e) return;
  document.getElementById('modal-title').textContent = 'Editar entrega';
  document.getElementById('edit-id').value     = e.id;
  document.getElementById('f-cliente').value   = e.cliente;
  document.getElementById('f-telefono').value  = e.telefono;
  document.getElementById('f-direccion').value = e.direccion;
  document.getElementById('f-hora').value      = e.hora;
  document.getElementById('f-zona').value      = e.zona;
  document.getElementById('f-producto').value  = e.producto;
  document.getElementById('f-estado').value    = e.estado;
  document.getElementById('f-notas').value     = e.notas;
  document.getElementById('modal-entrega')?.classList.add('open');
}

function closeModal() {
  document.getElementById('modal-entrega')?.classList.remove('open');
}

function saveEntrega() {
  const id    = document.getElementById('edit-id').value;
  const datos = {
    cliente:   document.getElementById('f-cliente').value.trim(),
    telefono:  document.getElementById('f-telefono').value.trim(),
    direccion: document.getElementById('f-direccion').value.trim(),
    hora:      document.getElementById('f-hora').value,
    zona:      document.getElementById('f-zona').value,
    producto:  document.getElementById('f-producto').value.trim(),
    estado:    document.getElementById('f-estado').value,
    notas:     document.getElementById('f-notas').value.trim(),
  };

  if (!datos.cliente || !datos.direccion) {
    alert('Por favor completa los campos obligatorios.');
    return;
  }

  if (id) {
    // Actualizar estado en BD si cambió
    fetch('../../api/entregas.php', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: id, estado: datos.estado })
    }).catch(() => {});
    const idx = window.ENTREGAS.findIndex(x => x.id === id);
    if (idx !== -1) window.ENTREGAS[idx] = { id, ...datos };
  } else {
    const newId = 'E' + String((window.ENTREGAS.length + 1)).padStart(3, '0');
    window.ENTREGAS.push({ id: newId, ...datos });
  }

  closeModal();
  renderEntregas();
}

// ── Sidebar móvil ─────────────────────────
function toggleSidebar() {
  document.querySelector('.sidebar')?.classList.toggle('open');
  const overlay = document.getElementById('sidebar-overlay');
  if (overlay) overlay.style.display = 'block';
}

function logout() {
  if (confirm('¿Cerrar sesión?')) { API.clearSession(); API.logout(); }
}

// ── Inicialización ────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  updateDate();
  setInterval(updateDate, 60000);
  // window.ENTREGAS lo inyecta el fetch del HTML.
  if (window.ENTREGAS) renderEntregas();
});