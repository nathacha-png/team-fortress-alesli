/* =============================================
   dashboard.js — Florería Alesli
   ============================================= */

// ── Fecha en vivo ──────────────────────────────
function updateDate() {
  const el = document.getElementById('live-date');
  if (!el) return;
  const now = new Date();
  const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  el.textContent = now.toLocaleDateString('es-BO', opts);
}

// ── Menú mobile ───────────────────────────────
function initMobileMenu() {
  const btn     = document.getElementById('menu-btn');
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  if (!btn || !sidebar) return;

  btn.addEventListener('click', () => {
    const isOpen = sidebar.classList.toggle('open');
    overlay.style.display = isOpen ? 'block' : 'none';
  });
}

// ── Búsqueda en tabla ─────────────────────────
function initTableSearch() {
  const input = document.getElementById('table-search');
  const table = document.getElementById('pedidos-table');
  if (!input || !table) return;

  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    table.querySelectorAll('tbody tr').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
}

// ── Filtros de pedidos ────────────────────────
function initFilterButtons() {
  const btns  = document.querySelectorAll('.filter-btn');
  const table = document.getElementById('pedidos-table');
  if (!btns.length || !table) return;

  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      // estado activo
      btns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.dataset.filter;
      table.querySelectorAll('tbody tr').forEach(row => {
        if (filter === 'todos') {
          row.style.display = '';
        } else {
          const badge = row.querySelector('.badge');
          row.style.display = (badge && badge.classList.contains(filter)) ? '' : 'none';
        }
      });
    });
  });
}

// ── Cambiar estado de pedido ──────────────────
const STATUS_CYCLE = ['pendiente', 'preparando', 'listo', 'entregado'];
const STATUS_LABEL = {
  pendiente:  'Pendiente',
  preparando: 'Preparando',
  listo:      'Listo',
  entregado:  'Entregado',
};

function changeStatus(btn, orderId) {
  const row   = btn.closest('tr');
  const badge = row.querySelector('.badge');
  if (!badge) return;

  // detectar clase actual
  const current = STATUS_CYCLE.find(s => badge.classList.contains(s)) || 'pendiente';
  const nextIdx = (STATUS_CYCLE.indexOf(current) + 1) % STATUS_CYCLE.length;
  const next    = STATUS_CYCLE[nextIdx];

  // actualizar badge
  badge.classList.remove(...STATUS_CYCLE);
  badge.classList.add(next);
  badge.textContent = STATUS_LABEL[next];

  console.log(`Pedido #${orderId} → ${next}`);
}

// ── Cerrar sesión ─────────────────────────────
function logout() {
  if (confirm('¿Cerrar sesión?')) {
    API.clearSession();
    API.logout();
  }
}

// ── Init con datos del dashboard ──────────────
function initDashboard(data) {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('stat-pedidos-hoy', data.pedidos_hoy   ?? '—');
  set('stat-pendientes',  data.pendientes    ?? '—');
  set('stat-entregas',    data.entregas_hoy  ?? '—');
  set('stat-ventas',      data.ventas_hoy != null ? 'Bs. ' + Number(data.ventas_hoy).toLocaleString('es-BO', {minimumFractionDigits:2}) : '—');

  // Tabla de pedidos recientes
  const tbody = document.querySelector('#pedidos-table tbody');
  if (tbody && Array.isArray(data.pedidos_recientes) && data.pedidos_recientes.length) {
    tbody.innerHTML = data.pedidos_recientes.map(p => `
      <tr>
        <td>#${p.id}</td>
        <td>${p.cliente}</td>
        <td>${p.producto}</td>
        <td>Bs. ${Number(p.total).toFixed(2)}</td>
        <td><span class="badge ${p.estado}">${p.estado}</span></td>
        <td>${p.fecha}</td>
        <td><button class="btn-sm" onclick="changeStatus(this,'${p.id}')">Cambiar</button></td>
      </tr>
    `).join('');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  updateDate();
  initMobileMenu();
  initTableSearch();
  initFilterButtons();
});

// Exportar para tests o uso desde otros módulos (opcional)
window.changeStatus = changeStatus;
window.logout       = logout;