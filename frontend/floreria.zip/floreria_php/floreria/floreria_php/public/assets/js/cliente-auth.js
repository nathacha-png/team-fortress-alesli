/* ══════════════════════════════════════════════════════
   cliente-auth.js — Florería Alesli
   Modal login / registro para clientes (index.php, carrito.php)
   ══════════════════════════════════════════════════════ */

(function () {
  'use strict';

  // ── Clave de sesión en localStorage (con expiración de 8h) ──
  const SESSION_KEY = 'alesli_cliente';

  function getSession() {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const s = JSON.parse(raw);
      if (s.expires && Date.now() > s.expires) { localStorage.removeItem(SESSION_KEY); return null; }
      return s;
    } catch { return null; }
  }

  function setSession(usuario) {
    const s = { ...usuario, expires: Date.now() + 8 * 60 * 60 * 1000 };
    localStorage.setItem(SESSION_KEY, JSON.stringify(s));
  }

  function clearSession() {
    localStorage.removeItem(SESSION_KEY);
  }

  // ── Inyectar modal en el DOM ──────────────────────────────────
  function injectModal() {
    const html = `
    <div id="auth-overlay" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.45);backdrop-filter:blur(3px);align-items:center;justify-content:center;">
      <div id="auth-modal" style="background:#fff;border-radius:1.2rem;padding:2.2rem 2rem;width:min(420px,92vw);box-shadow:0 20px 60px rgba(194,77,119,.22);position:relative;">
        <button onclick="AuthModal.close()" style="position:absolute;top:.8rem;right:1rem;background:none;border:none;font-size:1.4rem;cursor:pointer;color:#999;">✕</button>
        
        <!-- Tabs -->
        <div style="display:flex;gap:.5rem;margin-bottom:1.6rem;">
          <button id="tab-login" onclick="AuthModal.showTab('login')"
            style="flex:1;padding:.6rem;border-radius:.7rem;border:2px solid #c24d77;background:#c24d77;color:#fff;font-weight:600;cursor:pointer;transition:.2s;">
            Iniciar sesión
          </button>
          <button id="tab-register" onclick="AuthModal.showTab('register')"
            style="flex:1;padding:.6rem;border-radius:.7rem;border:2px solid #c24d77;background:#fff;color:#c24d77;font-weight:600;cursor:pointer;transition:.2s;">
            Registrarse
          </button>
        </div>

        <!-- LOGIN -->
        <div id="panel-login">
          <h2 style="font-family:'Playfair Display',serif;color:#8c2f51;margin:0 0 1.2rem;font-size:1.5rem;">Bienvenida 🌸</h2>
          <input id="login-correo" type="email" placeholder="Correo electrónico"
            style="width:100%;padding:.75rem;border:1.5px solid #e0c4d0;border-radius:.6rem;margin-bottom:.8rem;font-size:.9rem;box-sizing:border-box;">
          <input id="login-pass" type="password" placeholder="Contraseña"
            style="width:100%;padding:.75rem;border:1.5px solid #e0c4d0;border-radius:.6rem;margin-bottom:1rem;font-size:.9rem;box-sizing:border-box;">
          <div id="login-error" style="color:#ef4444;font-size:.82rem;margin-bottom:.8rem;display:none;"></div>
          <button onclick="AuthModal.doLogin()"
            style="width:100%;padding:.85rem;background:#c24d77;color:#fff;border:none;border-radius:.7rem;font-weight:700;font-size:1rem;cursor:pointer;">
            Entrar
          </button>
        </div>

        <!-- REGISTRO -->
        <div id="panel-register" style="display:none;">
          <h2 style="font-family:'Playfair Display',serif;color:#8c2f51;margin:0 0 1.2rem;font-size:1.5rem;">Crea tu cuenta 🌺</h2>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:.6rem;margin-bottom:.8rem;">
            <input id="reg-nombre"   type="text"  placeholder="Nombre *"
              style="padding:.75rem;border:1.5px solid #e0c4d0;border-radius:.6rem;font-size:.9rem;">
            <input id="reg-apellido" type="text"  placeholder="Apellido *"
              style="padding:.75rem;border:1.5px solid #e0c4d0;border-radius:.6rem;font-size:.9rem;">
          </div>
          <input id="reg-correo"   type="email"    placeholder="Correo electrónico *"
            style="width:100%;padding:.75rem;border:1.5px solid #e0c4d0;border-radius:.6rem;margin-bottom:.8rem;font-size:.9rem;box-sizing:border-box;">
          <input id="reg-telefono" type="tel"      placeholder="Teléfono (opcional)"
            style="width:100%;padding:.75rem;border:1.5px solid #e0c4d0;border-radius:.6rem;margin-bottom:.8rem;font-size:.9rem;box-sizing:border-box;">
          <input id="reg-pass"     type="password" placeholder="Contraseña (mín. 6 caracteres) *"
            style="width:100%;padding:.75rem;border:1.5px solid #e0c4d0;border-radius:.6rem;margin-bottom:.8rem;font-size:.9rem;box-sizing:border-box;">
          <input id="reg-confirmar" type="password" placeholder="Repetir contraseña *"
            style="width:100%;padding:.75rem;border:1.5px solid #e0c4d0;border-radius:.6rem;margin-bottom:1rem;font-size:.9rem;box-sizing:border-box;">
          <div id="reg-error" style="color:#ef4444;font-size:.82rem;margin-bottom:.8rem;display:none;"></div>
          <button onclick="AuthModal.doRegister()"
            style="width:100%;padding:.85rem;background:#c24d77;color:#fff;border:none;border-radius:.7rem;font-weight:700;font-size:1rem;cursor:pointer;">
            Crear cuenta
          </button>
        </div>
      </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
  }

  // ── Actualizar botón "Entrar" según sesión ───────────────────
  function updateNavButton() {
    const s = getSession();
    document.querySelectorAll('.btn-login').forEach(btn => {
      if (s) {
        btn.textContent = s.nombre;
        btn.style.cursor = 'default';
        btn.onclick = null;
        // Añadir botón de salir si no existe
        if (!document.getElementById('btn-salir')) {
          const out = document.createElement('button');
          out.id = 'btn-salir';
          out.textContent = 'Salir';
          out.style.cssText = 'background:transparent;color:#c24d77;border:1.5px solid #c24d77;padding:8px 18px;border-radius:20px;cursor:pointer;font-size:.85rem;margin-left:.5rem;';
          out.onclick = () => { clearSession(); location.reload(); };
          btn.insertAdjacentElement('afterend', out);
        }
      } else {
        btn.textContent = 'Entrar';
        btn.onclick = () => window.AuthModal.open();
      }
    });
  }

  // ── API base ──────────────────────────────────────────────────
  function apiBase() {
    // Detectar raíz del proyecto buscando /public/ en la ruta
    const match = location.pathname.match(/^(\/.*?)\/public\//);
    if (match) return match[1] + '/api';
    // Si estamos en la raíz de public (ej: /floreria_php/public/index.php)
    const parts = location.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) return '/' + parts[0] + '/api';
    return '/api';
  }

  // ── Módulo público ─────────────────────────────────────────────
  window.AuthModal = {
    open(tab = 'login') {
      const ov = document.getElementById('auth-overlay');
      if (ov) { ov.style.display = 'flex'; this.showTab(tab); }
    },
    close() {
      const ov = document.getElementById('auth-overlay');
      if (ov) ov.style.display = 'none';
    },
    showTab(tab) {
      document.getElementById('panel-login').style.display    = tab === 'login'    ? '' : 'none';
      document.getElementById('panel-register').style.display = tab === 'register' ? '' : 'none';
      const active = 'background:#c24d77;color:#fff;';
      const inactive= 'background:#fff;color:#c24d77;';
      document.getElementById('tab-login').style.cssText    += tab === 'login'    ? active : inactive;
      document.getElementById('tab-register').style.cssText += tab === 'register' ? active : inactive;
    },
    async doLogin() {
      const correo    = document.getElementById('login-correo').value.trim();
      const contrasena= document.getElementById('login-pass').value;
      const errEl     = document.getElementById('login-error');
      errEl.style.display = 'none';

      if (!correo || !contrasena) { errEl.textContent='Completa todos los campos'; errEl.style.display=''; return; }
      try {
        const res  = await fetch(apiBase() + '/login.php', {
          method: 'POST', headers: {'Content-Type':'application/json'},
          credentials: 'include',
          body: JSON.stringify({ correo, contrasena }),
        });
        const json = await res.json();
        if (!json.success) throw new Error(json.mensaje || 'Error al iniciar sesión');
        setSession(json.usuario);
        // Guardar también en sessionStorage con la clave que usa api.js en el panel
        sessionStorage.setItem('usuario', JSON.stringify(json.usuario));
        // Si es admin o empleado, redirigir al panel correspondiente
        if (json.usuario.rol === 'admin' || json.usuario.rol === 'empleado') {
          errEl.style.color = '#10b981';
          errEl.textContent = '✅ Bienvenido ' + json.usuario.nombre + ', redirigiendo al panel...';
          errEl.style.display = '';
          setTimeout(() => { window.location.href = json.redirect; }, 900);
          return;
        }
        this.close();
        updateNavButton();
      } catch(e) { errEl.textContent = e.message; errEl.style.display = ''; }
    },
    async doRegister() {
      const nombre    = document.getElementById('reg-nombre').value.trim();
      const apellido  = document.getElementById('reg-apellido').value.trim();
      const correo    = document.getElementById('reg-correo').value.trim();
      const telefono  = document.getElementById('reg-telefono').value.trim();
      const contrasena= document.getElementById('reg-pass').value;
      const confirmar = document.getElementById('reg-confirmar').value;
      const errEl     = document.getElementById('reg-error');
      errEl.style.display = 'none';

      if (!nombre||!apellido||!correo||!contrasena) { errEl.textContent='Completa los campos obligatorios (*)'; errEl.style.display=''; return; }
      if (contrasena !== confirmar) { errEl.textContent='Las contraseñas no coinciden'; errEl.style.display=''; return; }
      try {
        const res  = await fetch(apiBase() + '/register.php', {
          method: 'POST', headers: {'Content-Type':'application/json'},
          credentials: 'include',
          body: JSON.stringify({ nombre, apellido, correo, telefono, contrasena, confirmar }),
        });
        const json = await res.json();
        if (!json.success) throw new Error(json.mensaje || 'Error al registrarse');
        setSession(json.usuario);
        this.close();
        updateNavButton();
      } catch(e) { errEl.textContent = e.message; errEl.style.display = ''; }
    },
    getSession,
  };

  // ── Inicializar al cargar DOM ─────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => {
    injectModal();
    updateNavButton();
    // Cerrar al hacer clic en el overlay
    document.getElementById('auth-overlay').addEventListener('click', function(e) {
      if (e.target === this) window.AuthModal.close();
    });
  });

})();
