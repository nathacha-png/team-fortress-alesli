<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Florería Alesli</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body>
    <header class="nav-bar">
        <div class="logo">Floreria <span>alesli</span> </div>
        <nav>
            <a href="index.php" style="color:#c24d77;font-weight:600;">Inicio</a>
            <a href="catalogo.php">Catálogo</a>
            <a href="nosotros.php">Nosotros</a>
            <a href="nosotros.php#contacto">Contacto</a>
        </nav>

        <div class="action">
            <button class="btn-login">Entrar</button>
        </div>


    </header>

    <main class="hero">
        <div class="hero-container">
            <p class="tag-line">hecho con amor desde </p>
            <h1>Flores que <br><span>cuentan</span><br>tu historia</h1>
            <p class="descripcion">En Florería Alesli diseñamos arreglos únicos para cada momento especial. Frescura, elegancia y entrega a domicilio el mismo día</p>
            <div class="cta-buttons">
                <button class="btn-primary" onclick="window.location.href='catalogo.php'">Catálogo</button>
                <button class="btn-secundary">Personalizar</button>
            </div>
            
            <div class="stats">
                <div ><strong>1.2k</strong><br>Clientes felices</div>
                <div ><strong>1.2k</strong><br>Satisfaccion</div>
                <div ><strong>1.2k</strong><br>Entrega</div>
            </div>
        </div>

        <div class="hero-image">
            <div class="imagen-wraper">
                <img src="assets/img/imagen-ini.jpeg" alt="ramo">
                <div class="badge-rating">★ 4.9 / 5</div>
                <div class="order-popup">Pedido entregado: <strong>Ramo "Eterna"</strong></div>
            </div>
        </div>
        </main>


        <script src="https://cdn.jsdelivr.net/npm/tsparticles-confetti@2.12.0/tsparticles.confetti.bundle.min.js"></script>

        <script>
        window.addEventListener('scroll', () => {
            document.querySelector('.nav-bar').classList.toggle('scrolled', window.scrollY > 40);
        });
        </script>
        <script src="assets/js/efecto-petalos.js"></script>
        <script src="assets/js/cliente-auth.js"></script>
        <script>
        /* ── Cargar productos dinámicamente desde la BD ── */
        document.addEventListener('DOMContentLoaded', async () => {
            const grid = document.querySelector('.product-grid');
            if (!grid) return;

            try {
                const productos = await fetch('../api/productos.php').then(r => r.json());
                const activos   = Array.isArray(productos) ? productos.filter(p => p.estado === 'activo').slice(0, 4) : [];

                if (!activos.length) return; // mantiene el card HTML estático de fallback

                grid.innerHTML = activos.map(p => `
                    <div class="product-card">
                        <div class="product-image">
                            <img src="../uploads/${p.foto || ''}" alt="${p.nombre}"
                                 onerror="this.src='assets/img/flores1.jpeg'"
                                 style="width:100%;height:100%;object-fit:cover;">
                        </div>
                        <div class="product-info">
                            <h3>${p.nombre}</h3>
                            <p class="price">${parseFloat(p.precio).toFixed(2)}bs</p>
                            <p class="product-desc">${p.descripcion || ''}</p>
                            <div class="product-action">
                                <button class="btn-info" onclick="verDetalle(${p.id}, '${p.nombre.replace(/'/g,"\\'")}')">Ver detalles</button>
                                <button class="btn-cart" onclick="agregarAlCarrito(${p.id})">🛒 Añadir</button>
                            </div>
                        </div>
                    </div>
                `).join('');
            } catch { /* fallback silencioso */ }
        });

        function verDetalle(id, nombre) {
            window.location.href = 'catalogo.php';
        }

        async function actualizarFAB() {
            const sesion = typeof AuthModal !== 'undefined' ? AuthModal.getSession() : null;
            if (!sesion) return;
            try {
                const res   = await fetch('../api/carrito.php?id_usuario=' + sesion.id);
                const items = await res.json();
                const count = Array.isArray(items) ? items.reduce((s,i) => s + i.cantidad, 0) : 0;
                const badge = document.getElementById('fab-badge');
                if (badge) {
                    badge.textContent = count;
                    badge.style.display = count > 0 ? 'flex' : 'none';
                }
            } catch {}
        }
        document.addEventListener('DOMContentLoaded', () => setTimeout(actualizarFAB, 800));

        async function agregarAlCarrito(idProducto) {
            const sesion = AuthModal.getSession();
            if (!sesion) { AuthModal.open('login'); return; }

            try {
                const res = await fetch('../api/carrito.php', {
                    method: 'POST',
                    headers: {'Content-Type':'application/json'},
                    body: JSON.stringify({ id_usuario: sesion.id, id_producto: idProducto, cantidad: 1 }),
                });
                const json = await res.json();
                if (!res.ok) throw new Error(json.error || 'Error');
                // Mini toast
                const t = document.createElement('div');
                t.textContent = '🛒 Agregado al carrito';
                Object.assign(t.style, {
                    position:'fixed', bottom:'1.5rem', right:'1.5rem', background:'#10b981',
                    color:'#fff', padding:'.7rem 1.2rem', borderRadius:'.6rem',
                    fontFamily:'Poppins,sans-serif', fontSize:'.88rem', zIndex:'8000',
                    boxShadow:'0 4px 14px rgba(0,0,0,.15)', animation:'none',
                });
                document.body.appendChild(t);
                setTimeout(() => t.remove(), 3000);
            } catch(e) {
                alert('❌ ' + e.message);
            }
        }
        </script>


        <section class="explore">
            <span class="seccion-tag">EXPLORA</span>
            <h2>Tu ramo perfecto te espera </h2>
            <p>Elige entre nuestro catalogo o personaliza un arreglo único pensado para ti.</p>

            <div class="product-grid">
                <div class="product-card">
                    <div class="product-image">
                        <img src="assets/img/flores1.jpeg" alt="">
                    </div>
                    <div class="product-info">
                        <h3>Ramo "Amanecer"</h3>
                        <p class="price">50bs</p>
                        <p class="product-desc">combinacion de rosas rosadas y follaje silvestre</p>
                        <div class="product-action">
                            <button class="btn-info">Ver detalles </button>
                            <button class="btn-cart">🛒 Añadir</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        
        <div class="faq">
            <span class="section-faq">AYUDA</span>
            <h2>Preguntas Frecuentes</h2>
            <div class="faq-container">
                <details class="faq-item">
                    <summary>¿Hacen entregas el mismo día? <span class="icon">+</span></summary>
                    <div class="faq-content">
                        <p>Sí. Los pedidos realizados antes de las 14:00 se entregan el mismo día en toda la ciudad de La Paz. Para zonas alejadas puede aplicarse un cargo adicional de transporte.</p>
                    </div>
                </details>
                <details class="faq-item">
                    <summary>¿Puedo personalizar mi ramo? <span class="icon">+</span></summary>
                    <div class="faq-content">
                        <p>¡Por supuesto! Cuéntanos los colores, tipo de flores y presupuesto que tienes en mente. Puedes escribirnos por WhatsApp o dejar una nota en tu pedido al finalizar la compra.</p>
                    </div>
                </details>
                <details class="faq-item">
                    <summary>¿Qué métodos de pago aceptan? <span class="icon">+</span></summary>
                    <div class="faq-content">
                        <p>Aceptamos efectivo al momento de la entrega, pago por QR (Tigo Money, Pago Fácil), transferencia bancaria y tarjeta de crédito/débito.</p>
                    </div>
                </details>
                <details class="faq-item">
                    <summary>¿Qué pasa si las flores llegan en mal estado? <span class="icon">+</span></summary>
                    <div class="faq-content">
                        <p>Tenemos política de cambio dentro de las 12 horas siguientes a la entrega si se detectan defectos de calidad. Basta con enviarnos una foto por WhatsApp y coordinamos el reemplazo sin costo.</p>
                    </div>
                </details>
                <details class="faq-item">
                    <summary>¿Atienden los domingos? <span class="icon">+</span></summary>
                    <div class="faq-content">
                        <p>Sí, los domingos atendemos de 09:00 a 14:00 en tienda y aceptamos pedidos online con entrega el lunes si se realizan después del mediodía del domingo.</p>
                    </div>
                </details>
            </div>
        </div>



        <section class="about">
            <span class="section-tag">SOBRE NOSOTROS</span>
            <h2>La historia de <span>Alesli</span></h2>
            <p class="about-text">Florería Alesli nació en 2015 del sueño de transformar momentos en recuerdos inolvidables a través de las flores. Lo que empezó como un pequeño taller hoy es la florería de confianza de cientos de familias.</p>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="icon-box">❤️</div>
                    <h3>Hecho con amor </h3>
                    <p>Cada arreglo es una pieza unica y artesanal </p>
                </div>
                <div class="feature-card">
                    <div class="icon-box">🍃</div>
                    <h3>Flores frescas </h3>
                    <p>Cosechadas de productores locales </p>
                </div>

                <div class="feature-card">
                    <div class="icon-box">🚚</div>
                    <h3>Envios coordinados </h3>
                    <p>Entrega a domicilio el mismo día en la ciudad. </p>
                </div>

                <div class="feature-card">
                    <div class="icon-box">🏅</div>
                    <h3>Calidad premium</h3>
                    <p>Más de 1.200 clientes satisfechos lo respaldan. </p>
                </div>
                
                
            </div>
        </section>


        <section class="testimonials">
            <span class="section-tag">RESEÑAS</span>
            <h2>Lo que dicen nuestros clientes</h2>
            <div class="testimonial-grid">
                <div class="testi-card">
                    <div class="testi-stars">★★★★★</div>
                    <p>El ramo llegó impecable y las flores duraron más de una semana. ¡El mejor regalo que he dado en años!</p>
                    <span>Andrés Flores Moya</span>
                </div>
                <div class="testi-card">
                    <div class="testi-stars">★★★★★</div>
                    <p>Pedí un arreglo personalizado para la boda de mi hermana y superaron todas mis expectativas. Profesionales y puntuales.</p>
                    <span>Carla Romero</span>
                </div>
                <div class="testi-card">
                    <div class="testi-stars">★★★★★</div>
                    <p>Entregan rapidísimo y las flores siempre frescas. Ya les compré cuatro veces y nunca han fallado. 100% recomendados.</p>
                    <span>Roberto Quispe</span>
                </div>
            </div>
        </section>

        
        <a href="carrito.php" class="boton-emergencia" id="fab-carrito" style="position:relative;">
          <span class="icono"><ion-icon name="cart-outline"></ion-icon></span>
          <span id="fab-badge" style="display:none;position:absolute;top:-4px;right:-4px;background:#333;color:#fff;font-size:.65rem;font-weight:700;width:20px;height:20px;border-radius:50%;align-items:center;justify-content:center;">0</span>
        </a>


        </main><!-- /main -->

        <footer class="footer">
            <div class="footer-logo">🌸 Florería Alesli</div>
            <div class="copyright">© 2026 Florería Alesli. Hecho con ✨ para ti.</div>
        </footer>
        
        <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
        
<script src="assets/js/petalos-global.js"></script>
<script>
// Animaciones de entrada con IntersectionObserver
document.addEventListener('DOMContentLoaded', () => {
    const targets = document.querySelectorAll('.product-card, .feature-card, .testi-card, .faq-item, .explore h2, .about h2, .testimonials h2');
    targets.forEach(el => el.classList.add('fade-up'));

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); }});
    }, { threshold: 0.15 });

    document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
});
</script>
</body>
</html>