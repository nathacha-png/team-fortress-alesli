<?php
// api/register.php
require_once __DIR__ . '/cors.php';
// Registro de nuevos CLIENTES de la Florería Alesli

header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'mensaje' => 'Método no permitido.']);
    exit;
}

require_once 'conexion.php';

// Leer JSON o form-data
$datos = json_decode(file_get_contents('php://input'), true);
if (!$datos) {
    $datos = $_POST;
}

$nombre     = trim($datos['nombre']     ?? '');
$apellido   = trim($datos['apellido']   ?? '');
$correo     = trim($datos['correo']     ?? '');
$telefono   = trim($datos['telefono']   ?? '');
$contrasena = $datos['contrasena']      ?? '';
$confirmar  = $datos['confirmar']       ?? '';

// ── Validaciones ─────────────────────────────────────────────────────────────

$errores = [];

if (empty($nombre))   $errores[] = 'El nombre es obligatorio.';
if (empty($apellido)) $errores[] = 'El apellido es obligatorio.';

if (empty($correo)) {
    $errores[] = 'El correo es obligatorio.';
} elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    $errores[] = 'El formato del correo no es válido.';
}

if (empty($contrasena)) {
    $errores[] = 'La contraseña es obligatoria.';
} elseif (strlen($contrasena) < 6) {
    $errores[] = 'La contraseña debe tener al menos 6 caracteres.';
}

if ($contrasena !== $confirmar) {
    $errores[] = 'Las contraseñas no coinciden.';
}

// Teléfono opcional pero validar formato si viene
if (!empty($telefono) && !preg_match('/^[0-9+\-\s]{7,20}$/', $telefono)) {
    $errores[] = 'El teléfono tiene un formato inválido.';
}

if (!empty($errores)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errores' => $errores, 'mensaje' => $errores[0]]);
    exit;
}

// ── Verificar correo único (en usuarios Y en empleados) ───────────────────────

try {
    // Chequear en usuarios
    $stmt = $conexion->prepare("SELECT id_usuario FROM usuarios WHERE correo = :correo LIMIT 1");
    $stmt->execute([':correo' => $correo]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['success' => false, 'mensaje' => 'Ya existe una cuenta con ese correo.']);
        exit;
    }

    // Chequear en empleados (por si acaso)
    $stmt2 = $conexion->prepare("SELECT id_empleado FROM empleados WHERE correo = :correo LIMIT 1");
    $stmt2->execute([':correo' => $correo]);
    if ($stmt2->fetch()) {
        http_response_code(409);
        echo json_encode(['success' => false, 'mensaje' => 'Ese correo ya está registrado en el sistema.']);
        exit;
    }

    // ── Insertar nuevo usuario ────────────────────────────────────────────────

    $hash = password_hash($contrasena, PASSWORD_BCRYPT);

    $insert = $conexion->prepare(
        "INSERT INTO usuarios (nombre, apellido, correo, telefono, contrasena, estado)
         VALUES (:nombre, :apellido, :correo, :telefono, :contrasena, 'activo')"
    );
    $insert->execute([
        ':nombre'     => $nombre,
        ':apellido'   => $apellido,
        ':correo'     => $correo,
        ':telefono'   => !empty($telefono) ? $telefono : null,
        ':contrasena' => $hash,
    ]);

    $nuevoId = $conexion->lastInsertId();

    // Iniciar sesión automáticamente tras el registro
    session_start();
    session_regenerate_id(true);

    $_SESSION['id']       = $nuevoId;
    $_SESSION['nombre']   = $nombre;
    $_SESSION['apellido'] = $apellido;
    $_SESSION['correo']   = $correo;
    $_SESSION['rol']      = 'cliente';
    $_SESSION['tipo']     = 'usuario';

    http_response_code(201);
    echo json_encode([
        'success' => true,
        'mensaje' => '¡Cuenta creada exitosamente! Bienvenido, ' . $nombre . '.',
        'usuario' => [
            'id'       => $nuevoId,
            'nombre'   => $nombre,
            'apellido' => $apellido,
            'correo'   => $correo,
            'rol'      => 'cliente',
            'tipo'     => 'usuario',
        ],
        'redirect' => '../index.php',
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'mensaje' => 'Error interno del servidor.']);
    // Para desarrollo:
    // echo json_encode(['success' => false, 'mensaje' => $e->getMessage()]);
}