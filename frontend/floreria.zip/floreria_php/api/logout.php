<?php
// api/logout.php
require_once __DIR__ . '/cors.php';
// Cierra la sesión del usuario o empleado activo y redirige al login.

session_unset();
session_destroy();

header('Location: ../public/empleado/login.php');
exit;
