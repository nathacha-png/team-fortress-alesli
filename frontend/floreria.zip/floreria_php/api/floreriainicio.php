<?php
// api/floreriainicio.php — Catálogo público con datos reales
// Redirige a la versión HTML+JS pura del catálogo
header('Location: ../public/catalogo.php');
exit;
