<?php
require_once __DIR__ . '/cors.php';
header('Content-Type: application/json');
require_once 'conexion.php';

// ── PATCH /api/entregas.php  →  actualizar estado de entrega ──
if ($_SERVER['REQUEST_METHOD'] === 'PATCH') {
    $datos  = json_decode(file_get_contents('php://input'), true);
    // El JS usa IDs con formato "E001", extraemos el número
    $id_raw = $datos['id'] ?? '';
    $id     = intval(ltrim($id_raw, 'Ee0') ?: $id_raw);
    $estado = trim($datos['estado'] ?? '');
    $estados_validos = ['pendiente','en-camino','entregado'];

    if (!$id || !in_array($estado, $estados_validos)) {
        http_response_code(400);
        echo json_encode(['error' => 'id y estado válido son requeridos']);
        exit;
    }
    try {
        $stmt = $conexion->prepare(
            "UPDATE entregas SET estado = :estado WHERE id_entrega = :id"
        );
        $stmt->execute([':estado' => $estado, ':id' => $id]);
        echo json_encode(['success' => true, 'id' => $id_raw, 'estado' => $estado]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── GET /api/entregas.php  →  listar entregas del día ──
try {
    $stmt = $conexion->query("
        SELECT
            CONCAT('E', LPAD(id_entrega, 3, '0')) AS id,
            cliente,
            COALESCE(telefono, '')                AS telefono,
            direccion,
            COALESCE(zona, '')                    AS zona,
            producto,
            TIME_FORMAT(hora, '%H:%i')            AS hora,
            estado,
            COALESCE(notas, '')                   AS notas
        FROM entregas
        WHERE fecha = CURDATE()
        ORDER BY hora ASC
    ");
    echo json_encode($stmt->fetchAll());
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
