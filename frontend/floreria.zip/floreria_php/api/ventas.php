<?php
require_once __DIR__ . '/cors.php';
header('Content-Type: application/json');
require_once 'conexion.php';

// ── POST /api/ventas.php  →  registrar nueva venta ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos   = json_decode(file_get_contents('php://input'), true);
    $cliente = trim($datos['cliente']  ?? '');
    $producto= trim($datos['producto'] ?? '');
    $monto   = floatval($datos['monto'] ?? 0);
    $metodo  = trim($datos['metodo']   ?? 'efectivo');
    $metodos_validos = ['efectivo','qr','transferencia','tarjeta'];

    if (!$cliente || !$producto || $monto <= 0 || !in_array($metodo, $metodos_validos)) {
        http_response_code(400);
        echo json_encode(['error' => 'Datos incompletos o inválidos']);
        exit;
    }

    $id_pedido  = intval($datos['id_pedido']  ?? 0) ?: null;
    $id_empleado= intval($datos['id_empleado']?? 0) ?: null;

    try {
        $stmt = $conexion->prepare(
            "INSERT INTO ventas (id_pedido, id_empleado, cliente, producto, monto, metodo, estado, hora, fecha)
             VALUES (:id_pedido, :id_empleado, :cliente, :producto, :monto, :metodo, 'completado', NOW(), CURDATE())"
        );
        $stmt->execute([
            ':id_pedido'   => $id_pedido,
            ':id_empleado' => $id_empleado,
            ':cliente'     => $cliente,
            ':producto'    => $producto,
            ':monto'       => $monto,
            ':metodo'      => $metodo,
        ]);
        $nuevo_id = $conexion->lastInsertId();
        echo json_encode(['success' => true, 'id' => 'V' . str_pad($nuevo_id, 3, '0', STR_PAD_LEFT)]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── GET /api/ventas.php  →  listar ventas ──
try {
    $stmt = $conexion->query("
        SELECT
            CONCAT('V', LPAD(id_venta, 3, '0')) AS id,
            cliente,
            producto,
            monto,
            metodo,
            TIME_FORMAT(hora, '%H:%i')           AS hora,
            estado
        FROM ventas
        ORDER BY fecha DESC, hora DESC
    ");
    echo json_encode($stmt->fetchAll());
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
