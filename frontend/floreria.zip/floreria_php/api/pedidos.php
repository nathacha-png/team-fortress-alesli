<?php
require_once __DIR__ . '/cors.php';
header('Content-Type: application/json');
require_once 'conexion.php';

// ── PATCH /api/pedidos.php  →  actualizar estado de un pedido ──
if ($_SERVER['REQUEST_METHOD'] === 'PATCH') {
    $datos  = json_decode(file_get_contents('php://input'), true);
    $id     = intval($datos['id']     ?? 0);
    $estado = trim($datos['estado']   ?? '');
    $estados_validos = ['pendiente','preparando','listo','entregado','cancelado'];

    if (!$id || !in_array($estado, $estados_validos)) {
        http_response_code(400);
        echo json_encode(['error' => 'id y estado válido son requeridos']);
        exit;
    }
    try {
        $stmt = $conexion->prepare(
            "UPDATE pedidos SET estado = :estado WHERE id_pedido = :id"
        );
        $stmt->execute([':estado' => $estado, ':id' => $id]);
        echo json_encode(['success' => true, 'id' => $id, 'estado' => $estado]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── GET /api/pedidos.php  →  listar pedidos ──
try {
    $stmt = $conexion->query("
        SELECT
            p.id_pedido                          AS id,
            CONCAT(u.nombre, ' ', u.apellido)   AS name,
            COALESCE(p.telefono, u.telefono, '') AS phone,
            p.producto                           AS product,
            CONCAT('Bs. ', FORMAT(p.total, 2))  AS price,
            COALESCE(DATE_FORMAT(p.fecha_entrega,'%d/%m/%Y'), '—') AS delivery,
            p.prioridad                          AS priority,
            p.estado                             AS status
        FROM pedidos p
        JOIN usuarios u ON p.id_usuario = u.id_usuario
        ORDER BY p.fecha_pedido DESC
    ");
    echo json_encode($stmt->fetchAll());
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
