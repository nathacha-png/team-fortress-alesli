<?php
// api/login.php
// Login para EMPLEADOS y ADMIN de la Florería Alesli

session_start();
header('Content-Type: application/json');
$origin = $_SERVER['HTTP_ORIGIN'] ?? 'http://localhost';
header('Access-Control-Allow-Origin: ' . $origin);
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") { http_response_code(204); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'mensaje' => 'Método no permitido.']);
    exit;
}

require_once 'conexion.php';

$datos = json_decode(file_get_contents('php://input'), true);
if (!$datos) { $datos = $_POST; }

$correo     = trim($datos['correo'] ?? '');
$contrasena = $datos['contrasena'] ?? '';

if (empty($correo) || empty($contrasena)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'mensaje' => 'Correo y contraseña son obligatorios.']);
    exit;
}

if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'mensaje' => 'Formato de correo inválido.']);
    exit;
}

// Detectar la raíz del proyecto con ruta absoluta
// SCRIPT_NAME ej: /floreria_php/api/login.php  → raíz = /floreria_php
$root = preg_replace('/\/api\/login\.php$/', '', $_SERVER['SCRIPT_NAME']);

try {
    // Buscar en empleados (admin o empleado)
    $stmt = $conexion->prepare(
        "SELECT id_empleado AS id, nombre, apellido, correo, contrasena, rol, estado
         FROM empleados WHERE correo = :correo LIMIT 1"
    );
    $stmt->execute([':correo' => $correo]);
    $empleado = $stmt->fetch();

    if ($empleado) {
        // $2b$ (Python/Node bcrypt) → $2y$ (PHP bcrypt) son el mismo algoritmo
        $hash = str_replace('$2b$', '$2y$', $empleado['contrasena']);
        if (!password_verify($contrasena, $hash)) {
            http_response_code(401);
            echo json_encode(['success' => false, 'mensaje' => 'Correo o contraseña incorrectos.']);
            exit;
        }
        if ($empleado['estado'] !== 'activo') {
            http_response_code(403);
            echo json_encode(['success' => false, 'mensaje' => 'Tu cuenta está inactiva. Contacta al administrador.']);
            exit;
        }

        session_regenerate_id(true);
        $_SESSION['id']       = $empleado['id'];
        $_SESSION['nombre']   = $empleado['nombre'];
        $_SESSION['apellido'] = $empleado['apellido'];
        $_SESSION['correo']   = $empleado['correo'];
        $_SESSION['rol']      = $empleado['rol'];
        $_SESSION['tipo']     = 'empleado';

        $redirect = $empleado['rol'] === 'admin'
            ? $root . '/public/admin/index.php'
            : $root . '/public/empleado/dashboard.php';

        echo json_encode([
            'success'  => true,
            'mensaje'  => 'Bienvenido, ' . $empleado['nombre'] . '.',
            'usuario'  => [
                'id'       => $empleado['id'],
                'nombre'   => $empleado['nombre'],
                'apellido' => $empleado['apellido'],
                'correo'   => $empleado['correo'],
                'rol'      => $empleado['rol'],
                'tipo'     => 'empleado',
            ],
            'redirect' => $redirect,
        ]);
        exit;
    }

    // Buscar en usuarios (clientes)
    $stmt2 = $conexion->prepare(
        "SELECT id_usuario AS id, nombre, apellido, correo, contrasena, estado
         FROM usuarios WHERE correo = :correo LIMIT 1"
    );
    $stmt2->execute([':correo' => $correo]);
    $usuario = $stmt2->fetch();

    if ($usuario) {
        $hash2 = str_replace('$2b$', '$2y$', $usuario['contrasena']);
        if (!password_verify($contrasena, $hash2)) {
            http_response_code(401);
            echo json_encode(['success' => false, 'mensaje' => 'Correo o contraseña incorrectos.']);
            exit;
        }
        if ($usuario['estado'] !== 'activo') {
            http_response_code(403);
            echo json_encode(['success' => false, 'mensaje' => 'Tu cuenta está inactiva.']);
            exit;
        }

        session_regenerate_id(true);
        $_SESSION['id']       = $usuario['id'];
        $_SESSION['nombre']   = $usuario['nombre'];
        $_SESSION['apellido'] = $usuario['apellido'];
        $_SESSION['correo']   = $usuario['correo'];
        $_SESSION['rol']      = 'cliente';
        $_SESSION['tipo']     = 'usuario';

        echo json_encode([
            'success'  => true,
            'mensaje'  => 'Bienvenido, ' . $usuario['nombre'] . '.',
            'usuario'  => [
                'id'       => $usuario['id'],
                'nombre'   => $usuario['nombre'],
                'apellido' => $usuario['apellido'],
                'correo'   => $usuario['correo'],
                'rol'      => 'cliente',
                'tipo'     => 'usuario',
            ],
            'redirect' => $root . '/public/index.php',
        ]);
        exit;
    }

    http_response_code(401);
    echo json_encode(['success' => false, 'mensaje' => 'Correo o contraseña incorrectos.']);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'mensaje' => 'Error interno del servidor.']);
}
