<?php
// api/clientes.php — CRUD completo de clientes (tabla usuarios)
require_once __DIR__ . '/cors.php';
header('Content-Type: application/json');
require_once 'conexion.php';

$method = $_SERVER['REQUEST_METHOD'];

// ── DELETE /api/clientes.php?id=X
if ($method === 'DELETE') {
    $id = intval($_GET['id'] ?? 0);
    if (!$id) { http_response_code(400); echo json_encode(['error' => 'id requerido']); exit; }
    try {
        $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id_usuario = :id");
        $stmt->execute([':id' => $id]);
        if ($stmt->rowCount() === 0) {
            http_response_code(404); echo json_encode(['error' => 'Cliente no encontrado']); exit;
        }
        echo json_encode(['success' => true, 'id' => $id]);
    } catch (PDOException $e) {
        http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── PUT /api/clientes.php  →  editar cliente
if ($method === 'PUT') {
    $d  = json_decode(file_get_contents('php://input'), true);
    $id = intval($d['id'] ?? 0);
    if (!$id) { http_response_code(400); echo json_encode(['error' => 'id requerido']); exit; }

    // Separar nombre completo si viene así
    $nombre_full = trim($d['nombre'] ?? '');
    $partes      = explode(' ', $nombre_full, 2);
    $nombre      = $partes[0] ?? $nombre_full;
    $apellido    = $partes[1] ?? ($d['apellido'] ?? '');

    $correo    = trim($d['correo']    ?? '');
    $telefono  = trim($d['telefono'] ?? '');
    $direccion = trim($d['direccion']?? '');
    $tipo_vals = ['nuevo','frecuente','vip','inactivo'];
    $tipo      = in_array($d['tipo'] ?? '', $tipo_vals) ? $d['tipo'] : 'nuevo';
    $estado    = ($d['estado'] ?? 'activo') === 'inactivo' ? 'inactivo' : 'activo';
    $cumpleanos= trim($d['cumpleanos'] ?? '');
    $notas     = trim($d['notas']     ?? '');

    if (empty($nombre) || empty($correo) || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400); echo json_encode(['error' => 'nombre y correo válido son requeridos']); exit;
    }
    try {
        // Verificar correo único (excluyendo este id)
        $ck = $conexion->prepare("SELECT id_usuario FROM usuarios WHERE correo=:correo AND id_usuario<>:id");
        $ck->execute([':correo'=>$correo,':id'=>$id]);
        if ($ck->fetch()) {
            http_response_code(409); echo json_encode(['error' => 'Ese correo ya está en uso']); exit;
        }
        $stmt = $conexion->prepare("
            UPDATE usuarios SET
              nombre=:nombre, apellido=:apellido, correo=:correo,
              telefono=:telefono, direccion=:direccion, tipo=:tipo,
              estado=:estado, cumpleanos=:cumpleanos, notas=:notas
            WHERE id_usuario=:id
        ");
        $stmt->execute([
            ':nombre'=>$nombre,':apellido'=>$apellido,':correo'=>$correo,
            ':telefono'=>$telefono?:null,':direccion'=>$direccion?:null,
            ':tipo'=>$tipo,':estado'=>$estado,
            ':cumpleanos'=>$cumpleanos?:null,':notas'=>$notas?:null,
            ':id'=>$id
        ]);
        echo json_encode(['success' => true, 'id' => $id]);
    } catch (PDOException $e) {
        http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── POST /api/clientes.php  →  crear cliente (sin contraseña, admin la asigna)
if ($method === 'POST') {
    $d = json_decode(file_get_contents('php://input'), true);

    $nombre    = trim($d['nombre']    ?? '');
    $apellido  = trim($d['apellido']  ?? '');
    // Si nombre viene como nombre completo
    if (empty($apellido) && str_contains($nombre, ' ')) {
        $partes  = explode(' ', $nombre, 2);
        $nombre  = $partes[0];
        $apellido= $partes[1];
    }
    $correo    = trim($d['correo']    ?? '');
    $telefono  = trim($d['telefono'] ?? '');
    $direccion = trim($d['direccion']?? '');
    $tipo      = in_array($d['tipo']??'', ['nuevo','frecuente','vip','inactivo']) ? $d['tipo'] : 'nuevo';
    $cumpleanos= trim($d['cumpleanos']?? '');
    $notas     = trim($d['notas']    ?? '');
    // Contraseña temporal si el admin crea un cliente
    $contrasena = password_hash($d['contrasena'] ?? bin2hex(random_bytes(8)), PASSWORD_BCRYPT);

    if (empty($nombre) || empty($correo) || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400); echo json_encode(['error' => 'nombre y correo válido son requeridos']); exit;
    }
    try {
        $ck = $conexion->prepare("SELECT id_usuario FROM usuarios WHERE correo=:correo LIMIT 1");
        $ck->execute([':correo'=>$correo]);
        if ($ck->fetch()) {
            http_response_code(409); echo json_encode(['error' => 'Ya existe un cliente con ese correo']); exit;
        }
        $stmt = $conexion->prepare("
            INSERT INTO usuarios (nombre,apellido,correo,telefono,direccion,tipo,cumpleanos,notas,contrasena,estado)
            VALUES (:nombre,:apellido,:correo,:telefono,:direccion,:tipo,:cumpleanos,:notas,:contrasena,'activo')
        ");
        $stmt->execute([
            ':nombre'=>$nombre,':apellido'=>$apellido,':correo'=>$correo,
            ':telefono'=>$telefono?:null,':direccion'=>$direccion?:null,
            ':tipo'=>$tipo,':cumpleanos'=>$cumpleanos?:null,
            ':notas'=>$notas?:null,':contrasena'=>$contrasena
        ]);
        $newId = $conexion->lastInsertId();
        http_response_code(201);
        echo json_encode(['success' => true, 'id' => $newId]);
    } catch (PDOException $e) {
        http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── GET /api/clientes.php
try {
    $sql  = "SELECT id_usuario, nombre, apellido, correo, telefono, direccion,
                    tipo, cumpleanos, notas, estado,
                    DATE_FORMAT(creado_en, '%Y-%m-%d') AS fecha_registro
             FROM usuarios ORDER BY creado_en DESC";
    $stmt = $conexion->query($sql);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $clientes = array_map(function($r) {
        return [
            'id'        => (int)$r['id_usuario'],
            'nombre'    => $r['nombre'] . ' ' . $r['apellido'],
            'email'     => $r['correo'],
            'telefono'  => $r['telefono'] ?? '',
            'direccion' => $r['direccion'] ?? '',
            'tipo'      => $r['tipo'],
            'cumpleanos'=> $r['cumpleanos'] ?? '',
            'notas'     => $r['notas'] ?? '',
            'estado'    => $r['estado'],
            'fecha'     => $r['fecha_registro'],
        ];
    }, $rows);

    echo json_encode($clientes);
} catch (PDOException $e) {
    http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
}
