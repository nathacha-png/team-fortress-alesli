<?php
// api/carrito.php — Operaciones del carrito de compras
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once 'conexion.php';

$method = $_SERVER['REQUEST_METHOD'];

// ── DELETE: eliminar item del carrito
if ($method === 'DELETE') {
    $id_item    = intval($_GET['id_item']    ?? 0);
    $id_usuario = intval($_GET['id_usuario'] ?? 0);
    if (!$id_item || !$id_usuario) {
        http_response_code(400); echo json_encode(['error' => 'id_item e id_usuario requeridos']); exit;
    }
    try {
        $stmt = $conexion->prepare("DELETE FROM carrito WHERE id_item=:id AND id_usuario=:uid");
        $stmt->execute([':id'=>$id_item,':uid'=>$id_usuario]);
        echo json_encode(['success' => true]);
    } catch(PDOException $e) {
        http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── PATCH: actualizar cantidad
if ($method === 'PATCH') {
    $d          = json_decode(file_get_contents('php://input'), true);
    $id_item    = intval($d['id_item']    ?? 0);
    $id_usuario = intval($d['id_usuario'] ?? 0);
    $cantidad   = intval($d['cantidad']   ?? 0);
    if (!$id_item || !$id_usuario || $cantidad < 1) {
        http_response_code(400); echo json_encode(['error' => 'id_item, id_usuario y cantidad >= 1 requeridos']); exit;
    }
    try {
        $stmt = $conexion->prepare("UPDATE carrito SET cantidad=:q WHERE id_item=:id AND id_usuario=:uid");
        $stmt->execute([':q'=>$cantidad, ':id'=>$id_item, ':uid'=>$id_usuario]);
        if ($stmt->rowCount() === 0) {
            http_response_code(403); echo json_encode(['error' => 'Item no encontrado o no pertenece al usuario']); exit;
        }
        echo json_encode(['success' => true]);
    } catch(PDOException $e) {
        http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── POST: agregar producto al carrito (o incrementar si ya existe)
if ($method === 'POST') {
    $d          = json_decode(file_get_contents('php://input'), true);
    $id_usuario = intval($d['id_usuario'] ?? 0);
    $id_producto= intval($d['id_producto']?? 0);
    $cantidad   = max(1, intval($d['cantidad'] ?? 1));
    if (!$id_usuario || !$id_producto) {
        http_response_code(400); echo json_encode(['error' => 'id_usuario e id_producto requeridos']); exit;
    }
    try {
        // Verificar que producto existe y tiene stock
        $ck = $conexion->prepare("SELECT stock FROM catalogo WHERE id_producto=:id AND estado='activo'");
        $ck->execute([':id'=>$id_producto]);
        $prod = $ck->fetch();
        if (!$prod) {
            http_response_code(404); echo json_encode(['error' => 'Producto no disponible']); exit;
        }
        if ($prod['stock'] < $cantidad) {
            http_response_code(409); echo json_encode(['error' => 'Stock insuficiente']); exit;
        }
        // Upsert: si ya está en el carrito, suma la cantidad
        $stmt = $conexion->prepare("
            INSERT INTO carrito (id_usuario, id_producto, cantidad)
            VALUES (:uid, :pid, :q)
            ON DUPLICATE KEY UPDATE cantidad = cantidad + :q2
        ");
        $stmt->execute([':uid'=>$id_usuario,':pid'=>$id_producto,':q'=>$cantidad,':q2'=>$cantidad]);
        http_response_code(201);
        echo json_encode(['success' => true]);
    } catch(PDOException $e) {
        http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── GET: listar carrito del usuario con info del producto
$id_usuario = intval($_GET['id_usuario'] ?? 0);
if (!$id_usuario) {
    http_response_code(400); echo json_encode(['error' => 'id_usuario requerido']); exit;
}
try {
    $stmt = $conexion->prepare("
        SELECT
            c.id_item,
            c.id_producto,
            c.cantidad,
            p.nombre,
            p.descripcion,
            p.precio,
            p.foto,
            p.stock
        FROM carrito c
        JOIN catalogo p ON p.id_producto = c.id_producto
        WHERE c.id_usuario = :uid
        ORDER BY c.agregado_en DESC
    ");
    $stmt->execute([':uid'=>$id_usuario]);
    $rows = $stmt->fetchAll();
    // Ajustar tipos
    $items = array_map(function($r) {
        return [
            'id_item'     => (int)$r['id_item'],
            'id_producto' => (int)$r['id_producto'],
            'cantidad'    => (int)$r['cantidad'],
            'nombre'      => $r['nombre'],
            'descripcion' => $r['descripcion'] ?? '',
            'precio'      => floatval($r['precio']),
            'foto'        => $r['foto'] ?? '',
            'stock'       => (int)$r['stock'],
        ];
    }, $rows);
    echo json_encode($items);
} catch(PDOException $e) {
    http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
}
