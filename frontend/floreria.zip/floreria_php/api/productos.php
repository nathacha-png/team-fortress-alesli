<?php
require_once __DIR__ . '/cors.php';
header('Content-Type: application/json');
require_once 'conexion.php';

$method = $_SERVER['REQUEST_METHOD'];

// ── DELETE /api/productos.php?id=X
if ($method === 'DELETE') {
    $id = intval($_GET['id'] ?? 0);
    if (!$id) { http_response_code(400); echo json_encode(['error' => 'id requerido']); exit; }
    try {
        $stmt = $conexion->prepare("DELETE FROM catalogo WHERE id_producto = :id");
        $stmt->execute([':id' => $id]);
        if ($stmt->rowCount() === 0) {
            http_response_code(404); echo json_encode(['error' => 'Producto no encontrado']); exit;
        }
        echo json_encode(['success' => true, 'id' => $id]);
    } catch (PDOException $e) {
        http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── PATCH /api/productos.php  →  actualizar solo stock
if ($method === 'PATCH') {
    $datos = json_decode(file_get_contents('php://input'), true);
    $id    = intval($datos['id']    ?? 0);
    $stock = intval($datos['stock'] ?? -1);
    if (!$id || $stock < 0) {
        http_response_code(400); echo json_encode(['error' => 'id y stock >= 0 requeridos']); exit;
    }
    try {
        $estado = $stock === 0 ? 'agotado' : 'activo';
        $stmt = $conexion->prepare("UPDATE catalogo SET stock=:stock, estado=:estado WHERE id_producto=:id");
        $stmt->execute([':stock' => $stock, ':estado' => $estado, ':id' => $id]);
        echo json_encode(['success' => true, 'id' => $id, 'stock' => $stock, 'estado' => $estado]);
    } catch (PDOException $e) {
        http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── PUT /api/productos.php  →  editar producto completo
if ($method === 'PUT') {
    $datos  = json_decode(file_get_contents('php://input'), true);
    $id     = intval($datos['id'] ?? 0);
    if (!$id) { http_response_code(400); echo json_encode(['error' => 'id requerido']); exit; }

    $nombre      = trim($datos['nombre']      ?? '');
    $descripcion = trim($datos['descripcion'] ?? '');
    $precio      = floatval($datos['precio']  ?? 0);
    $stock       = intval($datos['stock']     ?? 0);
    $categoria   = trim($datos['categoria']   ?? 'General');
    $foto        = trim($datos['foto']        ?? '');
    $estado_validos = ['activo','desactivo','agotado'];
    $estado = in_array($datos['estado'] ?? '', $estado_validos) ? $datos['estado'] : ($stock === 0 ? 'agotado' : 'activo');

    if (empty($nombre) || $precio < 0) {
        http_response_code(400); echo json_encode(['error' => 'nombre y precio son requeridos']); exit;
    }
    try {
        $stmt = $conexion->prepare("
            UPDATE catalogo SET
              nombre=:nombre, descripcion=:descripcion, precio=:precio,
              stock=:stock, categoria=:categoria, estado=:estado, foto=:foto
            WHERE id_producto=:id
        ");
        $stmt->execute([
            ':nombre'=>$nombre,':descripcion'=>$descripcion,':precio'=>$precio,
            ':stock'=>$stock,':categoria'=>$categoria,':estado'=>$estado,
            ':foto'=>$foto?:null,':id'=>$id
        ]);
        if ($stmt->rowCount() === 0) {
            http_response_code(404); echo json_encode(['error' => 'Producto no encontrado']); exit;
        }
        echo json_encode(['success' => true, 'id' => $id]);
    } catch (PDOException $e) {
        http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ── GET /api/productos.php
try {
    $stmt = $conexion->query("
        SELECT id_producto AS id, nombre,
               COALESCE(categoria,'General') AS categoria,
               precio, COALESCE(stock,0) AS stock, estado,
               COALESCE(descripcion,'') AS descripcion,
               COALESCE(foto,'') AS foto
        FROM catalogo ORDER BY id_producto DESC
    ");
    echo json_encode($stmt->fetchAll());
} catch (PDOException $e) {
    http_response_code(500); echo json_encode(['error' => $e->getMessage()]);
}
