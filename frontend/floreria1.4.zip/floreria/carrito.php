<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="estilo/carrito.css">
    
</head>
<body>
    <header class="nav-bar">
        <div class="logo">  </div>
        <nav>
            <a href="">Inicio</a>
            <a href="">Catalogo</a>
            <a href="">Personalizar</a>
            <a href="">Nosotros </a>
            <a href="">Contactos</a>
        </nav>

        <div class="action">
            <button class="btn-login">Entrar</button>
        </div>

        <main class="hero">

        </main>


    </header>
    <main class="hero">
        <div class="hero-container">

            <h1 class="page-title">Tu <span>carrito</span></h1>

            <p class="page-subtitle">Revisa y personaliza tu pedido</p>

            <div class="cart-grid">
                <!--izquierda -->
                <section class="products-section">
                    <h2>Productos seleccionados</h2>

                    <!--funcional-->
                    <div id="lista-productos"></div>
                    <div id="carrito-vacio" style="display:none; text-align:center; padding:40px 0;">
                    
                        <p style="font-size:1.2rem;">tu carrito esta vacio</p>
                        <a href="catalogoi.php" style="color:#2d6a4f; font-weight:bold;">Ver catálogo →</a>
                    </div>
                </section>
                    <!--fin funcional -->
                    <!--derecha-->
                    <aside class="order-summary">
                        <h2>resumen del pedido</h2>
                        <div class="summary-row">
                            <span id="resumen-cantidad">subtotal (0 articulos)</span>
                            <span id="resumen-subtotal">0 bs</span>
                        </div>
                        <div class="summary-row">
                            <span>Envio a domicilio</span>
                            <span>30bs</span>
                        </div>
                        <div class="summary-row">
                            <span>Tarjeta de mensajes</span>
                            <span>Gratis</span>
                        </div>
                        <div class="promo-input">
                            <input type="text" id="codigo-promo" placeholder="Codigo de descuento">
                            <button onclick="aplicarPromo()">Aplicar</button>
                        </div>
                        <div class="summary-row">
                            <span>Total</span>
                            <span id="resumen-total">30 bs</span>
                        </div>
                        <button class="checkout-btn" onclick="finalizarCompra()">Finalizar compra</button>
                        <p class="delivery-note">Entrega en 24hrs</p>
                    </aside>
                </div>

                    <!--fin derecha-->
                    <!--quitar
                    <article class="cart-item">
                        <img src="imagenes/demostracion.jpg" alt="">
                        <div class="item-info">
                            <div class="item-name">Ramo de Rosas Rojas</div>
                            <div class="item-desc">>descripcion del producto a comprar kotoko kei</div>
                            <div class="qty-control">
                                <button onclick="cambiarCantidad(this, -1)">−</button>
                                <span>1</span>
                                <button onclick="cambiarCantidad(this, 1)">+</button>
                            </div>
                        </div>
                        <div class="item-price">
                            <div class="price">
                                358bs
                            </div>
                            <button class="remove-btn">Eliminar</button>
                        </div>
                    </article> -->
                

                



            <!--seccion de agregados-->
            <section class="extras-section">
                <h2>agrega algo especial</h2>
                <div class="extras-grid">



                    <div class="extra-card">
                        <img src="imagenes/demostracion2regalo.jpg" alt="">
                        <div class="extra-info">
                            <div class="extra-name">chocolates artesanales</div>
                            <div class="extra-price">120bs</div>
                        </div>
                        <button class="add-extra" onclick="agregarExtra('Chocolates artesanales', 120, this)">+</button>
                    </div>




                    <div class="extra-card">
                        <img src="imagenes/demostracion2regalo.jpg" alt="">
                        <div class="extra-info">
                            <div class="extra-name">chocolates artesanales</div>
                            <div class="extra-price">120bs</div>
                        </div>
                        <button class="add-extra" onclick="agregarExtra('Peluche de regalo', 80, this)">+</button>
                    </div>




                    <div class="extra-card">
                        <img src="imagenes/demostracion2regalo.jpg" alt="">
                        <div class="extra-info">
                            <div class="extra-name">chocolates artesanales</div>
                            <div class="extra-price">120bs</div>
                        </div>
                        <button class="add-extra" onclick="agregarExtra('Tarjeta personalizada', 15, this)">+</button>
                    </div>
                    
                </div>
            </section>

        </div>
    </main>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="js/carrito.js"></script>
</body>
</html>