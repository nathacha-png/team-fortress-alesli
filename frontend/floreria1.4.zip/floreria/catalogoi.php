<?php
include 'bd/floreria-bd.php';

// Preparamos la consulta directamente sin filtros
$stmt = $conexion->prepare("SELECT * FROM catalogo ORDER BY id_producto DESC");
$stmt->execute();

// Obtenemos todos los resultados
$catalogo = $stmt->fetchAll(); 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo - Florería Alesli</title>
    <link rel="stylesheet" href="estilo/estilo.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <header class="nav-bar">
        <div class="logo">Floreria <span>Alesli</span> </div>
        <nav>
            <a href="floreriainicio.php">Inicio</a>
            <a href="catalogoi.php">Catalogo</a>
            <a href="personalizar.html">Personalizar</a>
            <a href="nosotros.html">Nosotros </a>
            <a href="">Contactos</a>
        </nav>
        <div class="action">
            <button class="btn-login">Entrar</button>
        </div>
    </header>






        <h2 class="titulo-cat">Nuestro Catálogo</h2>
        
        <div class="catalogo-container">
            <h2 class="catalogo-titulo">Nuestro Catálogo</h2>
    
            <div class="filtro-secciones">
                <button class="btn-seccion active" data-category="todos">Todos</button>
                <button class="btn-seccion" data-category="navidad">Navidad</button>
                <button class="btn-seccion" data-category="san-valentin">San Valentín</button>
                <button class="btn-seccion" data-category="promociones">Promociones</button>
                <button class="btn-seccion" data-category="otros">Otros</button>
            </div>

        


        <div class="product-grid" id="contenedor-catalogo">
            <?php foreach($catalogo as $row): 
                
                $categoria = !empty($row['categoria']) ? htmlspecialchars($row['categoria']) : 'otros'; 
                $precio    = !empty($row['precio'])    ? htmlspecialchars($row['precio'])    : '0';
                $foto      = 'uploads/' . htmlspecialchars($row['foto'])
            ?>

                <div class="product-card producto-item"
                     data-item="<?php echo $categoria; ?>"
                     data-nombre="<?php echo htmlspecialchars($row['nombre']); ?>"
                     data-desc="<?php echo htmlspecialchars($row['descripcion']); ?>"
                     data-precio="<?php echo $precio; ?>"
                     data-foto="<?php echo $foto; ?>">



                    <div class="product-image">
                        <img src="uploads/<?php echo htmlspecialchars($row['foto']); ?>" alt="Foto">
                    </div>

                    <div class="product-info">
                        <h3><?php echo htmlspecialchars($row['nombre']); ?></h3>

                         <p class="price"><?php echo htmlspecialchars($row['precio']); ?> bs</p>  <!-- -->

                        <p><strong>Estado:</strong><?php echo htmlspecialchars($row['estado']); ?></p> 

                        <p class="product-desc"><?php echo htmlspecialchars($row['descripcion']); ?></p>

                        <div class="product-action">
                            <button class="btn-info">Ver detalles </button>
                            <button class="btn-cart">🛒 Añadir</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>

    
    <a href="carrito.php" class="boton-emergencia">  <!--carrito-->
             <span class="icono"><ion-icon name="cart-outline"></ion-icon>
            </span>
        </a>

    <footer class="footer">
        <div class="footer-logo">🌸 Florería Alesli</div>
        <div class="copyright">© 2026 Florería Alesli. Hecho con ✨ para ti.</div>
    </footer>

    <script src="js/catalogofun.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>