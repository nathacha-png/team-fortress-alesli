function obtenerCarrito() {
    return JSON.parse(localStorage.getItem('carrito_alesli')) || [];
}

function guardarCarrito(carrito) {

    localStorage.setItem('carrito_alesli', JSON.stringify(carrito));
}



function parsearPrecio(precioStr) {
  
    return parseFloat(String(precioStr).replace(/[^0-9.]/g, '')) || 0;
}



function renderizarCarrito() {
    const carrito     = obtenerCarrito();
    const contenedor  = document.getElementById('lista-productos');
    const msgVacio    = document.getElementById('carrito-vacio');

    contenedor.innerHTML = ''; 

    if (carrito.length === 0) {
        msgVacio.style.display = 'block';
        actualizarResumen([]);
        return;
    }

    msgVacio.style.display = 'none';

    
    carrito.forEach((item, indice) => {
        const article = document.createElement('article');
        article.className = 'cart-item';

        article.innerHTML = `
            <img src="${item.foto}" alt="${item.nombre}"
                 onerror="this.src='imagenes/demostracion.jpg'">

            <div class="item-info">
                <div class="item-name">${item.nombre}</div>
                <div class="item-desc">${item.descripcion}</div>

                <!-- Botones +/- llaman a cambiarCantidad con el índice del array -->
                <div class="qty-control">
                    <button onclick="cambiarCantidad(${indice}, -1)">−</button>
                    <span>${item.cantidad}</span>
                    <button onclick="cambiarCantidad(${indice}, +1)">+</button>
                </div>
            </div>

            <div class="item-price">
                <div class="price">${parsearPrecio(item.precio) * item.cantidad} bs</div>
                <!-- Eliminar usa el índice para saber qué borrar del array -->
                <button class="remove-btn" onclick="eliminarItem(${indice})">Eliminar</button>
            </div>
        `;

        contenedor.appendChild(article);
    });

    actualizarResumen(carrito);
}


// CAMBIAR CANTIDAD 
function cambiarCantidad(indice, delta) {
    const carrito = obtenerCarrito();
    carrito[indice].cantidad += delta;

    // Si llega a 0 se eliminara el item 
    if (carrito[indice].cantidad <= 0) {
        carrito.splice(indice, 1);
    }

    guardarCarrito(carrito);
    renderizarCarrito();
}



function eliminarItem(indice) {
    const carrito = obtenerCarrito();
    carrito.splice(indice, 1); 
    guardarCarrito(carrito);
    renderizarCarrito();
}


//panel derechio
function actualizarResumen(carrito) {
    if (!carrito.length) {
        document.getElementById('resumen-cantidad').textContent = 'Subtotal (0 artículos)';
        document.getElementById('resumen-subtotal').textContent = '0 bs';
        document.getElementById('resumen-total').textContent   = '30 bs';
        return;
    }

    const subtotal   = carrito.reduce((acc, i) => acc + parsearPrecio(i.precio) * i.cantidad, 0);
    const totalItems = carrito.reduce((acc, i) => acc + i.cantidad, 0);
    const total      = subtotal + 30; // 30 bs de envío fijo

    document.getElementById('resumen-cantidad').textContent = `Subtotal (${totalItems} artículo${totalItems !== 1 ? 's' : ''})`;
    document.getElementById('resumen-subtotal').textContent = `${subtotal} bs`;
    document.getElementById('resumen-total').textContent    = `${total} bs`;
}



function aplicarPromo() {
    const codigo     = document.getElementById('codigo-promo').value.trim().toUpperCase();
    const descuentos = { 'ALESLI10': 10, 'ROSAS5': 5 }; 

    if (descuentos[codigo]) {
        alert(`✅ Código aplicado: -${descuentos[codigo]} bs`);
    } else {
        alert(' Código inválido.');
    }
}



function agregarExtra(nombre, precio, boton) {
    const carrito = obtenerCarrito();
    const existe  = carrito.findIndex(i => i.nombre === nombre);

    if (existe !== -1) {
        carrito[existe].cantidad += 1;
    } else {
        carrito.push({ nombre, descripcion: 'Extra especial', precio: `${precio}`, foto: '', cantidad: 1 });
    }

    guardarCarrito(carrito);
    renderizarCarrito();

  
    boton.textContent = '✓';
    boton.disabled = true;
    setTimeout(() => { boton.textContent = '+'; boton.disabled = false; }, 2000);
}



function finalizarCompra() {
    const carrito = obtenerCarrito();
    if (!carrito.length) {
        alert('¡Tu carrito está vacío! Añade productos antes de continuar.');
        return;
    }
    alert('🌸 ¡Gracias por tu pedido! Te contactaremos pronto para confirmar.');
   
}



renderizarCarrito();