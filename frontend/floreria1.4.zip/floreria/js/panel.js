/* =============================================
   panel.js — Lógica del panel de administración
   
   Tiene dos responsabilidades:
     1. Toggle de la sidebar (abrir/cerrar)
     2. Navegación entre secciones (SPA)
============================================= */


/* =============================================
   1. TOGGLE SIDEBAR — sin cambios respecto al original
   Agrega/quita la clase "active" en nav y container
   para colapsar o expandir la barra lateral
============================================= */
document.getElementById('toggle').onclick = function () {
    document.getElementById('nav').classList.toggle('active');
    document.getElementById('container').classList.toggle('active');
};


/* =============================================
   2. NAVEGACIÓN ENTRE SECCIONES — nuevo
   
   Cómo funciona:
   - Cada <li> del menú tiene  data-seccion="nombre"
   - Cada vista tiene          id="vista-nombre"
   - navegar() conecta ambas: muestra la vista
     correcta y marca el ítem activo en el menú
============================================= */

/*
 * navegar(seccion)
 * ----------------
 * Recibe el nombre de la sección (string)
 * y hace tres cosas:
 *   1. Oculta todas las vistas
 *   2. Muestra solo la vista elegida
 *   3. Marca el ítem del menú como activo
 */
function navegar(seccion) {

    /* Caso especial: cerrar sesión */
    if (seccion === 'logout') {
        if (confirm('¿Seguro que deseas cerrar sesión?')) {
            alert('Sesión cerrada. ¡Hasta pronto!');
        }
        return;
    }

    /* 1. Ocultar todas las vistas quitando la clase "activa" */
    document.querySelectorAll('.vista').forEach(function (vista) {
        vista.classList.remove('activa');
    });

    /* 2. Mostrar la vista que corresponde a la sección elegida
          El id siempre es  "vista-" + nombre de la sección    */
    document.getElementById('vista-' + seccion).classList.add('activa');

    /* 3. Actualizar el ítem activo en el menú */
    document.querySelectorAll('.nav li[data-seccion]').forEach(function (li) {
        /* toggle: agrega "active" si es la sección actual, lo quita si no */
        li.classList.toggle('active', li.dataset.seccion === seccion);
    });
}


/* Escuchar clics en cada ítem del menú y llamar a navegar() */
document.querySelectorAll('.nav li[data-seccion]').forEach(function (li) {
    li.addEventListener('click', function (e) {
        e.preventDefault();                  /* evita que el href="#" haga scroll */
        navegar(this.dataset.seccion);       /* navega a la sección del ítem */
    });
});


/* Cargar la sección inicial al abrir el panel */
navegar('dashboard');

