document.addEventListener("DOMContentLoaded", () => {
    const botones = document.querySelectorAll(".btn-seccion"); // Cambiado a .btn-seccion
    const productos = document.querySelectorAll(".producto-item");

    botones.forEach(boton => {
        boton.addEventListener("click", (e) => {
            botones.forEach(btn => btn.classList.remove("active"));
            e.target.classList.add("active");

            const categoriaSeleccionada = e.target.getAttribute("data-category");

            productos.forEach(producto => {
                const categoriaProducto = producto.getAttribute("data-item");

                if (categoriaSeleccionada === "todos" || categoriaSeleccionada === categoriaProducto) {
                    producto.style.display = "block";
                } else {
                    producto.style.display = "none";
                }
            });
        });
    });
});


function obtenerCarrito() {
    return JSON.parse(localStorage.getItem('carrito_alesli')) || [];
}
 
function guardarCarrito(carrito) {
    localStorage.setItem('carrito_alesli', JSON.stringify(carrito));
}
 
 
//AGREGACION DE PRODUCTO 
function agregarAlCarrito(producto) {
    const carrito = obtenerCarrito();
 
    const idx = carrito.findIndex(item => item.nombre === producto.nombre);
    if (idx !== -1) {
        // SIexista +1 
        carrito[idx].cantidad += 1;
    } else {
        // 
        carrito.push({ ...producto, cantidad: 1 });
    }
 
    guardarCarrito(carrito);
    mostrarNotificacion(producto.nombre);
    actualizarBadge();
}
 
 

function mostrarNotificacion(nombre) {
    const notif = document.createElement('div');
    notif.textContent = `✅ "${nombre}" añadido al carrito`;
    Object.assign(notif.style, {
        position:     'fixed',
        bottom:       '90px',
        right:        '20px',
        background:   '#2d6a4f',
        color:        '#fff',
        padding:      '12px 20px',
        borderRadius: '10px',
        fontSize:     '14px',
        zIndex:       '9999',
        boxShadow:    '0 4px 15px rgba(0,0,0,0.2)'
    });
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 2500);
}
 
 

function actualizarBadge() {
    const total = obtenerCarrito().reduce((acc, i) => acc + i.cantidad, 0);
 
    let badge = document.querySelector('.carrito-badge');
    if (!badge) {
        badge = document.createElement('span');
        badge.className = 'carrito-badge';
        Object.assign(badge.style, {
            position:       'absolute',
            top:            '-8px',
            right:          '-8px',
            background:     '#e63946',
            color:          '#fff',
            borderRadius:   '50%',
            width:          '20px',
            height:         '20px',
            fontSize:       '11px',
            display:        'flex',
            alignItems:     'center',
            justifyContent: 'center',
            fontWeight:     'bold'
        });
        const boton = document.querySelector('.boton-emergencia');
        if (boton) {
            
            boton.appendChild(badge);
        }
    }
 
    badge.textContent   = total;
    badge.style.display = total > 0 ? 'flex' : 'none';
}
 
 

document.querySelectorAll('.product-card').forEach(tarjeta => {
    const boton = tarjeta.querySelector('.btn-cart');
    if (!boton) return;
 
    boton.addEventListener('click', () => {
        agregarAlCarrito({
            nombre:      tarjeta.dataset.nombre  || 'Sin nombre',
            descripcion: tarjeta.dataset.desc    || '',
            precio:      tarjeta.dataset.precio  || '0',
            foto:        tarjeta.dataset.foto    || ''
        });
    });
});
 
 

actualizarBadge();