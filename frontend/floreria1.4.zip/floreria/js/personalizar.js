const videoContainer = document.getElementById('media-container');
const btnStartCamera = document.getElementById('btn-start-camera');
const btnSnap = document.getElementById('btn-snap');
const fileInput = document.getElementById('file-input');
const resultBox = document.getElementById('result-box');

let stream = null;
let videoElement = null;

// --- LÓGICA DE LA CÁMARA ---
btnStartCamera.addEventListener('click', async () => {
    try {
        // Limpiar el contenedor antes de iniciar la transmisión
        videoContainer.innerHTML = '';
        
        // Solicitar acceso a la cámara de video (preferencia cámara trasera en móviles)
        stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: "environment" }, 
            audio: false 
        });
        
        videoElement = document.createElement('video');
        videoElement.srcObject = stream;
        videoElement.autoplay = true;
        videoElement.playsInline = true;
        
        videoContainer.appendChild(videoElement);
        
        // Alternar visibilidad de los botones
        btnStartCamera.style.display = 'none';
        btnSnap.style.display = 'inline-block';
        resultBox.style.display = 'none'; // Ocultar recuadro mientras se apunta
    } catch (err) {
        alert("No se pudo acceder a la cámara: " + err.message);
    }
});

// Capturar el fotograma del video
btnSnap.addEventListener('click', () => {
    if (!videoElement) return;

    // Crear un canvas temporal en memoria para procesar el cuadro actual
    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);

    // Convertir el gráfico del canvas en una URL de imagen base64
    const imgUrl = canvas.toDataURL('image/jpeg');
    displayImage(imgUrl);

    // Apagar los sensores de la cámara para ahorrar batería/recursos
    stream.getTracks().forEach(track => track.stop());
    btnSnap.style.display = 'none';
    btnStartCamera.style.display = 'inline-block';
});

// --- LÓGICA DE SUBIR ARCHIVO LOCAL ---
fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        // Si el usuario estaba usando la cámara en vivo, apagarla primero
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            btnSnap.style.display = 'none';
            btnStartCamera.style.display = 'inline-block';
        }

        const reader = new FileReader();
        reader.onload = function(event) {
            displayImage(event.target.result);
        }
        reader.readAsDataURL(file);
    }
});

// Función auxiliar para renderizar la imagen final y activar el recuadro inferior
function displayImage(src) {
    videoContainer.innerHTML = '';
    const img = document.createElement('img');
    img.src = src;
    videoContainer.appendChild(img);
    
    // Revelar el recuadro de coincidencia de paleta de colores
    resultBox.style.display = 'block';
}