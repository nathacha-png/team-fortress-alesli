<?php
include 'bd/floreria-bd.php';

// Preparamos la consulta directamente sin filtros
$stmt = $conexion->prepare("SELECT * FROM catalogo ORDER BY id_producto DESC");
$stmt->execute();

// Obtenemos todos los resultados
$catalogo = $stmt->fetchAll(); 
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="estilo/estilo.css">
</head>
<body>
    <header class="nav-bar">
        <div class="logo">Floreria <span>alesli</span> </div>
        <nav>
            <a href="">Inicio</a>
            <a href="catalogoi.php">Catalogo</a>
            <a href="personalizar.html">Personalizar</a>
            <a href="nosotros.html">Nosotros </a>
            <a href="">Contactos</a>
        </nav>

        <div class="action">
            <button class="btn-login">Entrar</button>
        </div>


    </header>

    <main class="hero">
        <div class="hero-container">
            
            <p class="tag-line">hecho con amor desde </p>
            <h1>Flores que <br><span>cuentan</span><br>tu historia</h1>
            <p class="descripcion">En Florería Alesli diseñamos arreglos únicos para cada momento especial. Frescura, elegancia y entrega a domicilio el mismo día</p>
            <div class="cta-buttons">
                <button class="btn-primary">catalogo </button>
                <button class="btn-secundary">personalizar</button>
            </div>
            
            <div class="stats">
                <div ><strong>1.2k</strong><br>Clientes felices</div>
                <div ><strong>1.2k</strong><br>Satisfaccion</div>
                <div ><strong>1.2k</strong><br>Entrega</div>
            </div>
        </div>

        <div class="hero-image">
            <div class="imagen-wraper">
                <img src="imagenes/imagen-ini.jpeg" alt="ramo">
                <div class="badge-rating">★ 4.9 / 5</div>
                <div class="order-popup">Pedido entregado: <strong>Ramo "Eterna"</strong></div>
            </div>
        </div>




        </main>


        <script src="https://cdn.jsdelivr.net/npm/tsparticles-confetti@2.12.0/tsparticles.confetti.bundle.min.js"></script>

        <script src="js/efecto-petalos.js"></script>


        <section class="explore">
            <span class="seccion-tag">EXPLORA</span>
            <h2>Tu ramo perfecto te espera </h2>
            <p>Elige entre nuestro catalogo o personaliza un arreglo único pensado para ti.</p>

            

            <div class="product-grid">
                <?php foreach($catalogo as $row):?> <!--bd-->
                <div class="product-card">

                    <div class="product-image">
                        <img src="uploads/<?php echo htmlspecialchars($row['foto']); ?>" alt="Foto"> <!--<img src="imagenes/flores1.jpeg" alt=""> -->
                    </div>

                    <div class="product-info">
                        <h3><?php echo htmlspecialchars($row['nombre']); ?></h3>  <!--nombre-->

                        <p class="price"><?php echo htmlspecialchars($row['precio']); ?> bs</p>

                        <p ><strong>Estado:</strong> <?php echo htmlspecialchars($row['estado']); ?></p> <!--estado -->


                        <p class="product-desc"><?php echo htmlspecialchars($row['descripcion']); ?></p>   <!--descripcion -->


                        <div class="product-action">
                            <button class="btn-info">Ver detalles </button>
                            <button class="btn-cart">🛒 Añadir</button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

                
        </section>

        
        <div class="faq">
            <span class="section-faq">AYUDA</span>
            <h2>Preguntas Frecuentes</h2>
            <div class="faq-container">
                <details class="faq-item">
                    <summary> preguntas <span class="icon">+</span></summary>
                    <div class="faq-content">
                        <p>respuesta</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary> preguntas <span class="icon">+</span></summary>
                    <div class="faq-content">
                        <p>respuesta</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary> preguntas <span class="icon">+</span></summary>
                    <div class="faq-content">
                        <p>respuesta</p>
                    </div>
                </details>


            </div>
        </div>



        <section class="about">
            <span class="section-tag">SOBRE NOSOTROS</span>
            <h2>La historia de <span>Alesli</span></h2>
            <p class="about-text">Florería Alesli nació en 2015 del sueño de transformar momentos en recuerdos inolvidables a través de las flores. Lo que empezó como un pequeño taller hoy es la florería de confianza de cientos de familias.</p>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="icon-box">❤️</div>
                    <h3>Hecho con amor </h3>
                    <p>Cada arreglo es una pieza unica y artesanal </p>
                </div>
                <div class="feature-card">
                    <div class="icon-box">🍃</div>
                    <h3>Flores frescas </h3>
                    <p>Cosechadas de productores locales </p>
                </div>

                <div class="feature-card">
                    <div class="icon-box">🚚</div>
                    <h3>Envios coordinados </h3>
                    <p>Entrega a domicilio el mismo día en la ciudad. </p>
                </div>

                <div class="feature-card">
                    <div class="icon-box">🏅</div>
                    <h3>Calidad premium</h3>
                    <p>Más de 1.200 clientes satisfechos lo respaldan. </p>
                </div>
                
                
            </div>
        </section>


        <section class="testimonials">
            <span class="section-tag">RESENAS</span>
            <h2>Lo que dicen nuestros clientes</h2>
            <div class="testimonial-grid">
                <div class="testi-card">
                    <p>"El ramo 'Eterna' llegó impecable. Las flores duraron más de una semana. ¡Increíble!"</p>
                    <span>Andres flores Moya</span>
                </div>

                <div class="testi-card">
                    <p>"El ramo 'Eterna' llegó impecable. Las flores duraron más de una semana. ¡Increíble!"</p>
                    <span>Andres flores Moya</span>
                </div>


            </div>
        </section>

        
        <a href="" class="boton-emergencia">  <!--carrito-->
             <span class="icono"><ion-icon name="cart-outline"></ion-icon>
            </span>
        </a>


        <footer class="footer">
            <div class="footer-logo">🌸 Florería Alesli</div>
            <div class="copyright">© 2026 Florería Alesli. Hecho con ✨ para ti.</div>
        </footer>
        
        <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
        
</body>
</html>