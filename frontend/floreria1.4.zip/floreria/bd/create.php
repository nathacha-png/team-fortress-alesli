<?php
require_once '../bd/floreria-bd.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $estado = $_POST['estado'];
    $descripcion = $_POST['descripcion'];


    $foto_archivo = $_FILES['foto'];
    $nombre_original = $foto_archivo['name'];


    $extension = pathinfo($nombre_original, PATHINFO_EXTENSION);
    $nombre_foto_db = time() . "_" . uniqid() . "." . $extension;
    $ruta_destino = "../uploads/" . $nombre_foto_db;

    $precio = $_POST['precio'];



    if (move_uploaded_file($foto_archivo['tmp_name'], $ruta_destino)) {
        try{
            $sql = "INSERT INTO catalogo (nombre, estado, descripcion, precio ,foto) VALUES (:nombre, :estado, :descripcion, :precio ,:foto)";
            $stmt = $conexion->prepare($sql);

            $stmt->bindParam(':nombre',$nombre);
            $stmt->bindParam(':estado',$estado);
            $stmt->bindParam(':descripcion',$descripcion);
            $stmt->bindParam(':precio', $precio);
            $stmt->bindParam(':foto',$nombre_foto_db);




            if($stmt->execute()){
                header("Location: ../floreriainicio.php?success=1");
                exit();
            }else{
                echo"error al guardar xd.";
            }
        }catch (PDOException $e){
            echo "Error:" . $e->getMessage();
        }
    } else{
        echo "error al subir imagen -_- ";
    }

        }
        ?>