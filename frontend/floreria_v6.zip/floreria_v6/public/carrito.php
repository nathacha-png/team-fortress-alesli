<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tu Carrito — Florería Alesli</title>
    <link rel="stylesheet" href="assets/css/carrito.css">
    <link rel="stylesheet" href="assets/css/fonts-catalogo.css">
    <link rel="stylesheet" href="assets/css/carrito-page.css">
</head>
<body>
    <header class="nav-bar">
        <div class="logo"><a href="index.php" style="text-decoration:none;color:inherit;">Floreria <span>alesli</span></a></div>
        <nav>
            <a href="index.php">Inicio</a>
            <a href="catalogo.php">Catálogo</a>
            <a href="personalizar.php">Personalizar</a>
            <a href="nosotros.php">Nosotros</a>
            <a href="nosotros.php#contacto">Contacto</a>
        </nav>
        <div class="action" id="nav-action">
            <button class="btn-login" onclick="AuthModal.open()">Entrar</button>
        </div>
    </header>

    <main class="hero">
        <div class="hero-container">
            <h1 class="page-title">Tu <span>carrito</span></h1>
            <p class="page-subtitle" id="carrito-subtitle">Revisa y personaliza tu pedido</p>

            <!-- Estado: no logueado -->
            <div id="login-gate" style="display:none;">
                <h2>Inicia sesión para ver tu carrito</h2>
                <p>Necesitas una cuenta para agregar productos y hacer pedidos.</p>
                <button onclick="AuthModal.open('login')">Iniciar sesión</button>
                <button onclick="AuthModal.open('register')" style="background:#fff;color:#c24d77;border:2px solid #c24d77;margin-left:.5rem;padding:.85rem 2rem;border-radius:2rem;font-size:1rem;font-weight:600;cursor:pointer;">Registrarse</button>
            </div>

            <!-- Cargando -->
            <div id="carrito-loading" class="cart-loading" style="display:none;">🌸 Cargando tu carrito…</div>

            <!-- Carrito con contenido -->
            <div class="cart-grid" id="carrito-contenido" style="display:none;">
                <section class="products-section">
                    <h2>Productos seleccionados</h2>
                    <div id="carrito-items"></div>
                </section>

                <aside class="order-summary">
                    <h2>Resumen del pedido</h2>
                    <div class="summary-row">
                        <span id="resumen-items-label">0 artículos</span>
                        <span id="resumen-subtotal">Bs. 0.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Envío a domicilio</span>
                        <span id="resumen-envio">Bs. 30.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Tarjeta de mensajes</span>
                        <span>Gratis</span>
                    </div>
                    <div class="promo-input">
                        <input type="text" id="promo-code" placeholder="Código de descuento"/>
                        <button onclick="aplicarPromo()">Aplicar</button>
                    </div>
                    <div class="summary-row total">
                        <span>Total</span>
                        <span id="resumen-total">Bs. 30.00</span>
                    </div>
                    <button class="checkout-btn" onclick="finalizarCompra()">Finalizar compra</button>
                    <p class="delivery-note">Entrega en 24 hrs</p>
                </aside>
            </div>

            <!-- Carrito vacío -->
            <div id="carrito-vacio" class="cart-empty" style="display:none;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 001.99-1.74L23 6H6"/>
                </svg>
                <h3>Tu carrito está vacío</h3>
                <p>Agrega flores desde nuestro catálogo</p>
                <a href="catalogo.php" style="display:inline-block;margin-top:1rem;background:#c24d77;color:#fff;padding:.75rem 1.5rem;border-radius:2rem;text-decoration:none;font-weight:600;">Ver catálogo</a>
            </div>

            <!-- Sección extras -->
            <section class="extras-section" id="extras-section" style="display:none;">
                <h2>Agrega algo especial</h2>
                <div class="extras-grid" id="extras-grid"></div>
            </section>
        </div>
    </main>

    <div id="carrito-toast"></div>

    <script src="assets/js/cliente-auth.js"></script>
    <script src="assets/js/nav-perfil.js"></script>
<script src="assets/js/petalos-global.js"></script>
    <script src="assets/js/carrito-page.js"></script>
</body>
</html>
