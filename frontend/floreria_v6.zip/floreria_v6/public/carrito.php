<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tu Carrito — Florería Alesli</title>
    <link rel="stylesheet" href="assets/css/carrito.css">
    <link rel="stylesheet" href="assets/css/fonts-catalogo.css">
        <style>
        
        .cart-empty { text-align:center; padding:4rem 1rem; color:
        .cart-empty svg { width:64px; opacity:.35; display:block; margin:0 auto 1rem; }
        .cart-loading { text-align:center; padding:3rem; color:
        
        .qty-control button { background:
        .qty-control span   { min-width:28px; text-align:center; font-weight:600; }
        
        
        .toast-msg { background:
        .toast-msg.err { background:
        @keyframes fadeup { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:none} }
        
        
        
        
    </style>
</head>
<body>
    <header class="nav-bar">
        <div class="logo"><a href="index.php" style="text-decoration:none;color:inherit;">Floreria <span>alesli</span></a></div>
        <nav>
            <a href="index.php">Inicio</a>
            <a href="catalogo.php">Catálogo</a>
            <a href="personalizar.php">Personalizar</a>
            <a href="nosotros.php">Nosotros</a>
            <a href="nosotros.php#contacto">Contacto</a>
        </nav>
        <div class="action" id="nav-action">
            <button class="btn-login" onclick="AuthModal.open()">Entrar</button>
        </div>
    </header>

    <main class="hero">
        <div class="hero-container">
            <h1 class="page-title">Tu <span>carrito</span></h1>
            <p class="page-subtitle" id="carrito-subtitle">Revisa y personaliza tu pedido</p>

            
            <div id="login-gate" style="display:none;">
                <h2>Inicia sesión para ver tu carrito</h2>
                <p>Necesitas una cuenta para agregar productos y hacer pedidos.</p>
                <button onclick="AuthModal.open('login')">Iniciar sesión</button>
                <button onclick="AuthModal.open('register')" style="background:#fff;color:#c24d77;border:2px solid #c24d77;margin-left:.5rem;padding:.85rem 2rem;border-radius:2rem;font-size:1rem;font-weight:600;cursor:pointer;">Registrarse</button>
            </div>

            
            <div id="carrito-loading" class="cart-loading" style="display:none;">🌸 Cargando tu carrito…</div>

            
            <div class="cart-grid" id="carrito-contenido" style="display:none;">
                <section class="products-section">
                    <h2>Productos seleccionados</h2>
                    <div id="carrito-items"></div>
                </section>

                <aside class="order-summary">
                    <h2>Resumen del pedido</h2>
                    <div class="summary-row">
                        <span id="resumen-items-label">0 artículos</span>
                        <span id="resumen-subtotal">Bs. 0.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Envío a domicilio</span>
                        <span id="resumen-envio">Bs. 30.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Tarjeta de mensajes</span>
                        <span>Gratis</span>
                    </div>
                    <div class="promo-input">
                        <input type="text" id="promo-code" placeholder="Código de descuento"/>
                        <button onclick="aplicarPromo()">Aplicar</button>
                    </div>
                    <div class="summary-row total">
                        <span>Total</span>
                        <span id="resumen-total">Bs. 30.00</span>
                    </div>
                    <button class="checkout-btn" onclick="finalizarCompra()">Finalizar compra</button>
                    <p class="delivery-note">Entrega en 24 hrs</p>
                </aside>
            </div>

            
            <div id="carrito-vacio" class="cart-empty" style="display:none;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 001.99-1.74L23 6H6"/>
                </svg>
                <h3>Tu carrito está vacío</h3>
                <p>Agrega flores desde nuestro catálogo</p>
                <a href="catalogo.php" style="display:inline-block;margin-top:1rem;background:#c24d77;color:#fff;padding:.75rem 1.5rem;border-radius:2rem;text-decoration:none;font-weight:600;">Ver catálogo</a>
            </div>

            
            <section class="extras-section" id="extras-section" style="display:none;">
                <h2>Agrega algo especial</h2>
                <div class="extras-grid" id="extras-grid"></div>
            </section>
        </div>
    </main>

    <div id="carrito-toast"></div>

    <script src="assets/js/cliente-auth.js"></script>
    <script src="assets/js/nav-perfil.js"></script>
    <script>
    
    let carritoItems = [];  
    const ENVIO = 30;
    const API_BASE = '../api';

    
    function toastCarrito(msg, tipo='ok') {
        const box = document.getElementById('carrito-toast');
        const t   = document.createElement('div');
        t.className = 'toast-msg' + (tipo==='err'?' err':'');
        t.textContent = msg;
        box.appendChild(t);
        setTimeout(() => t.remove(), 3500);
    }

    
    function renderItems() {
        const container = document.getElementById('carrito-items');
        if (!carritoItems.length) {
            document.getElementById('carrito-contenido').style.display = 'none';
            document.getElementById('carrito-vacio').style.display = '';
            document.getElementById('extras-section').style.display = 'none';
            return;
        }
        document.getElementById('carrito-contenido').style.display = '';
        document.getElementById('carrito-vacio').style.display = 'none';
        document.getElementById('extras-section').style.display = '';

        container.innerHTML = carritoItems.map(item => `
            <article class="cart-item" id="item-${item.id_item}">
                <img src="${item.foto ? '../uploads/' + item.foto : 'assets/img/imagen-ini.jpeg'}" 
                     alt="${item.nombre}" onerror="this.src='assets/img/imagen-ini.jpeg'">
                <div class="item-info">
                    <div class="item-name">${item.nombre}</div>
                    <div class="item-desc">${item.descripcion || ''}</div>
                    <div class="qty-control">
                        <button onclick="cambiarCantidad(${item.id_item}, ${item.id_producto}, -1)">−</button>
                        <span id="qty-${item.id_item}">${item.cantidad}</span>
                        <button onclick="cambiarCantidad(${item.id_item}, ${item.id_producto}, 1)">+</button>
                    </div>
                </div>
                <div class="item-price">
                    <div class="price" id="price-${item.id_item}">
                        ${(item.precio * item.cantidad).toFixed(2)}bs
                    </div>
                    <button class="remove-btn" onclick="eliminarItem(${item.id_item}, ${item.id_producto})">Eliminar</button>
                </div>
            </article>
        `).join('');

        actualizarResumen();
    }

    
    function actualizarResumen() {
        const subtotal = carritoItems.reduce((s, i) => s + i.precio * i.cantidad, 0);
        const total    = subtotal + ENVIO;
        const count    = carritoItems.reduce((s, i) => s + i.cantidad, 0);
        document.getElementById('resumen-items-label').textContent = `${count} artículo${count!==1?'s':''}`;
        document.getElementById('resumen-subtotal').textContent = `Bs. ${subtotal.toFixed(2)}`;
        document.getElementById('resumen-total').textContent    = `Bs. ${total.toFixed(2)}`;
    }

    
    async function cargarCarrito(idUsuario) {
        document.getElementById('carrito-loading').style.display = '';
        try {
            const res  = await fetch(`${API_BASE}/carrito.php?id_usuario=${idUsuario}`);
            const json = await res.json();
            carritoItems = Array.isArray(json) ? json : [];
        } catch {
            carritoItems = [];
            toastCarrito('Error al cargar el carrito', 'err');
        } finally {
            document.getElementById('carrito-loading').style.display = 'none';
        }
        renderItems();
        cargarExtras();
    }

    
    async function cambiarCantidad(idItem, idProducto, delta) {
        const item = carritoItems.find(i => i.id_item === idItem);
        if (!item) return;
        const nuevaCantidad = item.cantidad + delta;
        if (nuevaCantidad < 1) { eliminarItem(idItem, idProducto); return; }

        try {
            const _sesion = AuthModal.getSession();
            const res = await fetch(`${API_BASE}/carrito.php`, {
                method: 'PATCH',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ id_item: idItem, id_usuario: _sesion ? _sesion.id : 0, cantidad: nuevaCantidad }),
            });
            if (!res.ok) throw new Error();
            item.cantidad = nuevaCantidad;
            document.getElementById(`qty-${idItem}`).textContent = nuevaCantidad;
            document.getElementById(`price-${idItem}`).textContent = `${(item.precio * nuevaCantidad).toFixed(2)}bs`;
            actualizarResumen();
        } catch { toastCarrito('Error al actualizar cantidad', 'err'); }
    }

    
    async function eliminarItem(idItem, idProducto) {
        const sesion = AuthModal.getSession();
        if (!sesion) return;
        try {
            const res = await fetch(`${API_BASE}/carrito.php?id_item=${idItem}&id_usuario=${sesion.id}`, {
                method: 'DELETE',
            });
            if (!res.ok) throw new Error();
            carritoItems = carritoItems.filter(i => i.id_item !== idItem);
            renderItems();
            toastCarrito('Producto eliminado del carrito');
        } catch { toastCarrito('Error al eliminar', 'err'); }
    }

    
    async function cargarExtras() {
        try {
            const productos = await fetch(`${API_BASE}/productos.php`).then(r => r.json());
            const extras = productos.filter(p => p.estado === 'activo').slice(0, 3);
            document.getElementById('extras-grid').innerHTML = extras.map(p => `
                <div class="extra-card">
                    <img src="${p.foto ? '../uploads/' + p.foto : 'assets/img/imagen-ini.jpeg'}"
                         alt="${p.nombre}" onerror="this.src='assets/img/imagen-ini.jpeg'">
                    <div class="extra-info">
                        <div class="extra-name">${p.nombre}</div>
                        <div class="extra-price">${parseFloat(p.precio).toFixed(2)}bs</div>
                    </div>
                    <button class="add-extra" onclick="agregarExtra(${p.id})">+</button>
                </div>
            `).join('');
        } catch {  }
    }

    
    async function agregarExtra(idProducto) {
        const sesion = AuthModal.getSession();
        if (!sesion) { AuthModal.open('login'); return; }
        try {
            const res = await fetch(`${API_BASE}/carrito.php`, {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ id_usuario: sesion.id, id_producto: idProducto, cantidad: 1 }),
            });
            const json = await res.json();
            if (!res.ok) throw new Error(json.error || 'Error');
            toastCarrito('Producto agregado 🌸');
            await cargarCarrito(sesion.id);
        } catch(e) { toastCarrito(e.message, 'err'); }
    }

    
    function aplicarPromo() {
        const code = document.getElementById('promo-code').value.trim().toUpperCase();
        if (!code) return;
        toastCarrito('Código no válido', 'err');
    }

    
    function finalizarCompra() {
        if (!carritoItems.length) { toastCarrito('Tu carrito está vacío', 'err'); return; }
        toastCarrito('Redirigiendo a pago… (próximamente) 🛍️');
    }

    
    document.addEventListener('DOMContentLoaded', () => {
        const sesion = AuthModal.getSession();
        if (!sesion) {
            document.getElementById('login-gate').style.display = '';
        } else {
            
            const subtitle = document.getElementById('carrito-subtitle');
            if (subtitle) subtitle.textContent = `Hola ${sesion.nombre}, aquí están tus productos 🌸`;
            cargarCarrito(sesion.id);
        }
    });
    </script>
<script src="assets/js/petalos-global.js"></script>
</body>
</html>
