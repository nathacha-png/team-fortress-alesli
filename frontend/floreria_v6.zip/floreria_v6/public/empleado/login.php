<?php

$root = preg_replace('/\/public\/empleado\/login\.php$/', '', $_SERVER['SCRIPT_NAME']);
header('Location: ' . $root . '/public/index.php');
exit;
