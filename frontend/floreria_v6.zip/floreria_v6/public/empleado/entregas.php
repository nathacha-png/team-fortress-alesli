<?php
session_start();
if (empty($_SESSION["id"]) || empty($_SESSION["rol"]) || $_SESSION["tipo"] !== "empleado") {
    $root = preg_replace('/\/public\/empleado\/[^\/]+$/', '', $_SERVER['SCRIPT_NAME']);
    header("Location: " . $root . "/public/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="../assets/css/fonts-panel.css">
    <link rel="stylesheet" href="../assets/css/styles-empleado.css"/>
  <title>Entregas — Florería Alesli</title>
  
  
  
</head>
<body>
<script src="../assets/js/api.js"></script>
<script>
  API.requireAuth('login.php');
  document.addEventListener('DOMContentLoaded', () => API.injectUserInfo());
</script>

<div id="sidebar-overlay"
     style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.3); z-index:99;"
     onclick="this.style.display='none'; document.querySelector('.sidebar').classList.remove('open')">
</div>

<div class="app-layout">

  
  <aside class="sidebar">
    <a class="sidebar-logo" href="dashboard.php">
      <div class="sidebar-logo-icon">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
      </div>
      <div>
        <div class="sidebar-logo-text">Florería <span>Alesli</span></div>
        <span class="sidebar-logo-badge">Empleado</span>
      </div>
    </a>

    <nav class="sidebar-nav">
      <p class="sidebar-section-label">Principal</p>

      <a class="nav-item" href="dashboard.php">
        <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        Dashboard
      </a>
      <a class="nav-item" href="pedidos.php">
        <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        Pedidos
        <span class="nav-badge">5</span>
      </a>
      <a class="nav-item" href="catalogo.php">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
        Catálogo / Stock
        <span class="nav-badge warning">2</span>
      </a>
      <a class="nav-item" href="clientes.php">
        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
        Clientes
      </a>

      <p class="sidebar-section-label">Ventas</p>

      <a class="nav-item" href="ventas.php">
        <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        Caja / Ventas
      </a>
      <a class="nav-item active" href="entregas.php">
        <svg viewBox="0 0 24 24"><rect x="1" y="3" width="15" height="13" rx="1"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
        Entregas
      </a>

      <p class="sidebar-section-label">Otros</p>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        Notificaciones
        <span class="nav-badge">3</span>
      </a>
      <a class="nav-item" href="configuracion.php">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 4.93l1.41 1.41M12 2v2M12 20v2M20 12h2M2 12h2M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41"/></svg>
        Configuración
      </a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-card" onclick="logout()">
        <div class="user-avatar">MG</div>
        <div class="user-info">
          <div class="user-name">María González</div>
          <div class="user-role">Empleada</div>
        </div>
        <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      </div>
    </div>
  </aside>

  
  <header class="topbar">
    <button id="menu-btn"
            style="display:none; background:none; border:none; cursor:pointer; padding:4px;"
            aria-label="Menú"
            onclick="toggleSidebar()">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6b3a4a" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/>
        <line x1="3" y1="12" x2="21" y2="12"/>
        <line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>

    <h1 class="topbar-title">Entregas 🚐</h1>

    <div class="topbar-search">
      <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5l4 4"/></svg>
      <input type="text" id="search-input" placeholder="Buscar por cliente, dirección..." oninput="filterEntregas()"/>
    </div>

    <div class="topbar-actions">
      <div class="topbar-btn" title="Notificaciones">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        <span class="topbar-notif-dot"></span>
      </div>
      <div class="topbar-btn" title="Imprimir hoja de ruta" onclick="imprimirRuta()">
        <svg viewBox="0 0 24 24"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
      </div>
    </div>

    <div class="topbar-date">
      <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      <span id="live-date">Cargando fecha...</span>
    </div>
  </header>

  
  <main class="main-content">

    
    <div class="stats-strip">
      <div class="stat-card">
        <div class="stat-icon amber">
          <svg viewBox="0 0 24 24"><rect x="1" y="3" width="15" height="13" rx="1"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-total">8</div>
          <div class="stat-label">Entregas hoy</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green">
          <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-entregadas">3</div>
          <div class="stat-label">Completadas</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon pink">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-pendientes">5</div>
          <div class="stat-label">Pendientes</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon blue">
          <svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-zonas">4</div>
          <div class="stat-label">Zonas activas</div>
        </div>
      </div>
    </div>

    
    <div class="toolbar">
      <div class="filter-tabs">
        <button class="filter-tab active" data-status="todas" onclick="setFilter(this)">Todas</button>
        <button class="filter-tab" data-status="pendiente" onclick="setFilter(this)">Pendientes</button>
        <button class="filter-tab" data-status="en-camino" onclick="setFilter(this)">En camino</button>
        <button class="filter-tab" data-status="entregado" onclick="setFilter(this)">Entregadas</button>
      </div>
      <div class="toolbar-right">
        <button class="btn-outline" onclick="imprimirRuta()">
          <svg viewBox="0 0 24 24"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Hoja de ruta
        </button>
        <button class="btn-primary" onclick="openModal()">
          <svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Nueva entrega
        </button>
      </div>
    </div>

    
    <div class="entregas-grid" id="entregas-grid">
      
    </div>

  </main>
</div>

<div class="modal-overlay" id="modal-entrega">
  <div class="modal">
    <div class="modal-header">
      <div>
        <div class="modal-title" id="modal-title">Nueva entrega</div>
        <div class="modal-subtitle">Registra los datos de la entrega</div>
      </div>
      <button class="modal-close" onclick="closeModal()">
        <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="edit-id"/>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Cliente *</label>
          <input type="text" class="form-input" id="f-cliente" placeholder="Nombre del cliente"/>
        </div>
        <div class="form-group">
          <label class="form-label">Teléfono</label>
          <input type="text" class="form-input" id="f-telefono" placeholder="70123456"/>
        </div>
      </div>
      <div class="form-row single">
        <div class="form-group">
          <label class="form-label">Dirección de entrega *</label>
          <input type="text" class="form-input" id="f-direccion" placeholder="Av. Arce 1234, Sopocachi"/>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Hora programada</label>
          <input type="time" class="form-input" id="f-hora"/>
        </div>
        <div class="form-group">
          <label class="form-label">Zona</label>
          <select class="form-select" id="f-zona">
            <option value="Sopocachi">Sopocachi</option>
            <option value="Miraflores">Miraflores</option>
            <option value="San Miguel">San Miguel</option>
            <option value="Calacoto">Calacoto</option>
            <option value="Centro">Centro</option>
            <option value="Obrajes">Obrajes</option>
            <option value="Otra">Otra zona</option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Producto</label>
          <input type="text" class="form-input" id="f-producto" placeholder="Ej: Ramo de rosas rojas"/>
        </div>
        <div class="form-group">
          <label class="form-label">Estado</label>
          <select class="form-select" id="f-estado">
            <option value="pendiente">Pendiente</option>
            <option value="en-camino">En camino</option>
            <option value="entregado">Entregado</option>
          </select>
        </div>
      </div>
      <div class="form-row single">
        <div class="form-group">
          <label class="form-label">Notas de entrega</label>
          <input type="text" class="form-input" id="f-notas" placeholder="Ej: Tocar timbre, dejar con portero..."/>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-outline" onclick="closeModal()">Cancelar</button>
      <button class="btn-primary" onclick="saveEntrega()">
        <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
        Guardar entrega
      </button>
    </div>
  </div>
</div>

<script src="../assets/js/main.js"></script>
<script src="../assets/js/entregas.js"></script>
<script>
  
  API.cargar(API.entregas.bind(API), function(data) {
    window.ENTREGAS = data;
    if (typeof renderEntregas === 'function') renderEntregas();
  }, 'ENTREGAS');
</script>
<script src="../assets/js/petalos-global.js"></script>
</body>
</html>