<?php
session_start();
if (empty($_SESSION["id"]) || empty($_SESSION["rol"]) || $_SESSION["tipo"] !== "empleado") {
    $root = preg_replace('/\/public\/empleado\/[^\/]+$/', '', $_SERVER['SCRIPT_NAME']);
    header("Location: " . $root . "/public/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="../assets/css/fonts-panel.css">
    <link rel="stylesheet" href="../assets/css/styles-empleado.css"/>
  <title>Caja / Ventas — Florería Alesli</title>
  
  
  
</head>
<body>
<script src="../assets/js/api.js"></script>
<script>
  API.requireAuth('login.php');
  document.addEventListener('DOMContentLoaded', () => API.injectUserInfo());
</script>

<div id="sidebar-overlay"
     style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.3); z-index:99;"
     onclick="this.style.display='none'; document.querySelector('.sidebar').classList.remove('open')">
</div>

<div class="app-layout">

  <!-- ══════════════════ SIDEBAR ══════════════════ -->
  <aside class="sidebar">
    <a class="sidebar-logo" href="dashboard.php">
      <div class="sidebar-logo-icon">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
      </div>
      <div>
        <div class="sidebar-logo-text">Florería <span>Alesli</span></div>
        <span class="sidebar-logo-badge">Empleado</span>
      </div>
    </a>

    <nav class="sidebar-nav">
      <p class="sidebar-section-label">Principal</p>

      <a class="nav-item" href="dashboard.php">
        <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        Dashboard
      </a>
      <a class="nav-item" href="pedidos.php">
        <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        Pedidos
        <span class="nav-badge">5</span>
      </a>
      <a class="nav-item" href="catalogo.php">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
        Catálogo / Stock
        <span class="nav-badge warning">2</span>
      </a>
      <a class="nav-item" href="clientes.php">
        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
        Clientes
      </a>

      <p class="sidebar-section-label">Ventas</p>

      <a class="nav-item active" href="ventas.php">
        <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        Caja / Ventas
      </a>

      <p class="sidebar-section-label">Otros</p>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        Notificaciones
        <span class="nav-badge">3</span>
      </a>
      <a class="nav-item" href="configuracion.php">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 4.93l1.41 1.41M12 2v2M12 20v2M20 12h2M2 12h2M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41"/></svg>
        Configuración
      </a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-card" onclick="logout()">
        <div class="user-avatar">MG</div>
        <div class="user-info">
          <div class="user-name">María González</div>
          <div class="user-role">Empleada</div>
        </div>
        <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      </div>
    </div>
  </aside>

  <!-- ══════════════════ TOPBAR ══════════════════ -->
  <header class="topbar">
    <button id="menu-btn"
            style="display:none; background:none; border:none; cursor:pointer; padding:4px;"
            aria-label="Menú"
            onclick="toggleSidebar()">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6b3a4a" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/>
        <line x1="3" y1="12" x2="21" y2="12"/>
        <line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>

    <h1 class="topbar-title">Caja / <span>Ventas</span> 💰</h1>

    <div class="topbar-search">
      <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5l4 4"/></svg>
      <input type="text" id="search-input" placeholder="Buscar venta, cliente..." oninput="filterVentas()"/>
    </div>

    <div class="topbar-actions">
      <div class="topbar-btn" title="Notificaciones">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        <span class="topbar-notif-dot"></span>
      </div>
      <div class="topbar-btn" title="Exportar reporte" onclick="exportarReporte()">
        <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      </div>
    </div>

    <div class="topbar-date">
      <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      <span id="live-date">Cargando fecha...</span>
    </div>
  </header>

  <!-- ══════════════════ CONTENIDO ══════════════════ -->
  <main class="main-content">

    <!-- STATS -->
    <div class="stats-strip">
      <div class="stat-card">
        <div class="stat-icon green">
          <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-ventas-hoy">Bs. —</div>
          <div class="stat-label">Ventas de hoy</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon pink">
          <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-transacciones">—</div>
          <div class="stat-label">Transacciones hoy</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon amber">
          <svg viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="stat-ticket-prom">Bs. —</div>
          <div class="stat-label">Ticket promedio</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon blue">
          <svg viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
        </div>
        <div class="stat-info">
          <div class="stat-value">Bs. 38,420</div>
          <div class="stat-label">Ventas del mes</div>
        </div>
      </div>
    </div>

    <!-- LAYOUT DOS COLUMNAS -->
    <div class="ventas-layout">

      <!-- COLUMNA IZQUIERDA: historial de ventas -->
      <div class="ventas-main">
        <div class="toolbar">
          <div class="filter-tabs">
            <button class="filter-tab active" data-periodo="hoy" onclick="setFilter(this)">Hoy</button>
            <button class="filter-tab" data-periodo="semana" onclick="setFilter(this)">Esta semana</button>
            <button class="filter-tab" data-periodo="mes" onclick="setFilter(this)">Este mes</button>
          </div>
          <div class="toolbar-right">
            <button class="btn-outline" onclick="exportarReporte()">
              <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Exportar
            </button>
          </div>
        </div>

        <div class="table-card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Cliente</th>
                  <th>Producto</th>
                  <th>Monto</th>
                  <th>Método</th>
                  <th>Hora</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody id="table-body">
                <!-- Renderizado por JS -->
              </tbody>
            </table>
          </div>
          <div class="pagination">
            <span id="pagination-info">Mostrando 0 de 0 ventas</span>
            <div class="page-btns">
              <button class="page-btn">
                <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
              </button>
              <button class="page-btn active">1</button>
              <button class="page-btn">2</button>
              <button class="page-btn">
                <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- COLUMNA DERECHA: caja rápida -->
      <div class="caja-panel">
        <div class="caja-header">
          <div class="caja-title">
            <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/></svg>
            Nueva venta
          </div>
        </div>

        <div class="caja-body">
          <div class="form-group">
            <label class="form-label">Cliente</label>
            <input type="text" class="form-input" id="caja-cliente" placeholder="Nombre del cliente"/>
          </div>
          <div class="form-group">
            <label class="form-label">Producto / Descripción</label>
            <input type="text" class="form-input" id="caja-producto" placeholder="Ej: Ramo de rosas rojas"/>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Monto (Bs.)</label>
              <input type="number" class="form-input" id="caja-monto" placeholder="0.00" min="0" step="0.5"/>
            </div>
            <div class="form-group">
              <label class="form-label">Método de pago</label>
              <select class="form-select" id="caja-metodo">
                <option value="efectivo">💵 Efectivo</option>
                <option value="qr">📱 QR / Tigo Money</option>
                <option value="transferencia">🏦 Transferencia</option>
                <option value="tarjeta">💳 Tarjeta</option>
              </select>
            </div>
          </div>

          <!-- Calculadora de vuelto -->
          <div class="vuelto-box" id="vuelto-box">
            <div class="form-group">
              <label class="form-label">Efectivo recibido (Bs.)</label>
              <input type="number" class="form-input" id="caja-recibido" placeholder="0.00" oninput="calcularVuelto()"/>
            </div>
            <div class="vuelto-result" id="vuelto-result">
              <span class="vuelto-label">Vuelto:</span>
              <span class="vuelto-valor" id="vuelto-valor">Bs. 0.00</span>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Notas</label>
            <input type="text" class="form-input" id="caja-notas" placeholder="Opcional..."/>
          </div>
        </div>

        <div class="caja-footer">
          <button class="btn-outline" onclick="limpiarCaja()">Limpiar</button>
          <button class="btn-primary" onclick="registrarVenta()">
            <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
            Registrar venta
          </button>
        </div>
      </div>

    </div>
  </main>
</div>

<script src="../assets/js/main.js"></script>
<script src="../assets/js/ventas.js"></script>
<script>
  // Carga de datos con API.js — sin condición de carrera
  API.cargar(API.ventas.bind(API), function(data) {
    window.VENTAS = data;
    if (typeof renderVentas === 'function') renderVentas();
  }, 'VENTAS');
</script>
<script src="../assets/js/petalos-global.js"></script>
</body>
</html>