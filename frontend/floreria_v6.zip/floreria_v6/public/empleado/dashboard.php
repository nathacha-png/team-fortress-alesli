<?php
session_start();
if (empty($_SESSION["id"]) || empty($_SESSION["rol"]) || $_SESSION["tipo"] !== "empleado") {
    $root = preg_replace('/\/public\/empleado\/[^\/]+$/', '', $_SERVER['SCRIPT_NAME']);
    header("Location: " . $root . "/public/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="../assets/css/fonts-panel.css">
    <link rel="stylesheet" href="../assets/css/styles-empleado.css"/>
  <title>Dashboard — Florería Alesli</title>
  
  
  
</head>
<body>
<script src="../assets/js/api.js"></script>
<script>
  
  API.requireAuth('login.php');
  document.addEventListener('DOMContentLoaded', () => API.injectUserInfo());
</script>

<div id="sidebar-overlay"
     style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.3); z-index:99;"
     onclick="this.style.display='none'; document.querySelector('.sidebar').classList.remove('open')">
</div>

<div class="app-layout">

  
  <aside class="sidebar">

    <a class="sidebar-logo" href="dashboard.php">
      <div class="sidebar-logo-icon">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
      </div>
      <div>
        <div class="sidebar-logo-text">Florería <span>Alesli</span></div>
        <span class="sidebar-logo-badge">Empleado</span>
      </div>
    </a>

    <nav class="sidebar-nav">

      <p class="sidebar-section-label">Principal</p>

      <a class="nav-item active" href="dashboard.php">
        <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        Dashboard
      </a>

      <a class="nav-item" href="pedidos.php">
        <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        Pedidos
        <span class="nav-badge">5</span>
      </a>

      <a class="nav-item" href="catalogo.php">
        <svg viewBox="0 0 24 24"><path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/></svg>
        Catálogo / Stock
        <span class="nav-badge warning">2</span>
      </a>

      <a class="nav-item" href="clientes.php">
        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
        Clientes
      </a>

      <p class="sidebar-section-label">Ventas</p>

      <a class="nav-item" href="ventas.php">
        <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        Caja / Ventas
      </a>

      <p class="sidebar-section-label">Otros</p>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        Notificaciones
        <span class="nav-badge">3</span>
      </a>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 4.93l1.41 1.41M12 2v2M12 20v2M20 12h2M2 12h2M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41"/></svg>
        Configuración
      </a>

    </nav>

    <div class="sidebar-footer">
      <div class="user-card" onclick="logout()">
        <div class="user-avatar" data-usuario-iniciales>MG</div>
        <div class="user-info">
          <div class="user-name" data-usuario-nombre>Cargando…</div>
          <div class="user-role" data-usuario-rol>—</div>
        </div>
        <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      </div>
    </div>

  </aside>

  
  <header class="topbar">
    <button id="menu-btn"
            style="display:none; background:none; border:none; cursor:pointer; padding:4px;"
            aria-label="Menú">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6b3a4a" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/>
        <line x1="3" y1="12" x2="21" y2="12"/>
        <line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>

    <h1 class="topbar-title">Buenos días, <span>María</span> 🌸</h1>

    <div class="topbar-search">
      <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5l4 4"/></svg>
      <input type="text" id="table-search" placeholder="Buscar pedido, cliente..."/>
    </div>

    <div class="topbar-actions">
      <div class="topbar-btn" title="Notificaciones">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        <span class="topbar-notif-dot"></span>
      </div>
      <div class="topbar-btn" title="Imprimir resumen">
        <svg viewBox="0 0 24 24"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
      </div>
    </div>

    <div class="topbar-date">
      <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      <span id="live-date">Cargando fecha...</span>
    </div>
  </header>

  
  <main class="main-content">

    
    <div class="section-header">
      <span class="section-title">
        <svg viewBox="0 0 24 24"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
        Acciones rápidas
      </span>
    </div>

    <div class="quick-actions">
      <a class="quick-btn" href="pedidos.php">
        <div class="quick-btn-icon" style="background:#fce8f0;">
          <svg viewBox="0 0 24 24" style="stroke:#be3a6e;"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        </div>
        <span class="quick-btn-label">Nuevo pedido</span>
        <span class="quick-btn-sub">Crear manual</span>
      </a>
      <a class="quick-btn" href="catalogo.php">
        <div class="quick-btn-icon" style="background:#e6f7f1;">
          <svg viewBox="0 0 24 24" style="stroke:#1a7f5a;"><path d="M20 7H4a2 2 0 00-2 2v6a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
        </div>
        <span class="quick-btn-label">Actualizar stock</span>
        <span class="quick-btn-sub">Flores / arreglos</span>
      </a>
      <a class="quick-btn" href="ventas.php">
        <div class="quick-btn-icon" style="background:#eff6ff;">
          <svg viewBox="0 0 24 24" style="stroke:#1d4ed8;"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        </div>
        <span class="quick-btn-label">Registrar venta</span>
        <span class="quick-btn-sub">Caja del día</span>
      </a>
      <a class="quick-btn" href="clientes.php">
        <div class="quick-btn-icon" style="background:#f3e8ff;">
          <svg viewBox="0 0 24 24" style="stroke:#7c3aed;"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
        </div>
        <span class="quick-btn-label">Buscar cliente</span>
        <span class="quick-btn-sub">Historial</span>
      </a>
    </div>

    
    <div class="section-header">
      <span class="section-title">
        <svg viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
        Resumen del día
      </span>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon pink">
          <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
        </div>
        <div class="stat-value" id="stat-pedidos-hoy">18</div>
        <div class="stat-label">Pedidos hoy</div>
        <div class="stat-trend up">
          <svg viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
          +4 vs ayer
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon amber">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        </div>
        <div class="stat-value" id="stat-pendientes">5</div>
        <div class="stat-label">Pendientes</div>
        <div class="stat-trend warn">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          Requieren atención
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon blue">
          <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
        </div>
        <div class="stat-value" id="stat-ventas">Bs. 2,340</div>
        <div class="stat-label">Ventas del día</div>
        <div class="stat-trend up">
          <svg viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
          +12% esta semana
        </div>
      </div>
    </div>

    
    <div class="two-col">

      
      <div class="card">
        <div class="section-header" style="margin-bottom:0;">
          <span class="section-title">
            <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
            Pedidos recientes
          </span>
          <a class="section-link" href="pedidos.php">
            Ver todos
            <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
          </a>
        </div>

        
        <div style="display:flex; gap:6px; margin:12px 0; flex-wrap:wrap;">
          <button class="filter-btn active" data-filter="todos">Todos</button>
          <button class="filter-btn" data-filter="pendiente" style="color:#92400e;">Pendientes</button>
          <button class="filter-btn" data-filter="preparando" style="color:#1e40af;">Preparando</button>
          <button class="filter-btn" data-filter="listo" style="color:#065f46;">Listos</button>
        </div>

        <div class="table-wrap">
          <table id="pedidos-table">
            <thead>
              <tr>
                <th>
                <th>Cliente</th>
                <th>Producto</th>
                <th>Total</th>
                <th>Estado</th>
                <th>Acción</th>
              </tr>
            </thead>
            <tbody id="pedidos-tbody">
              
            </tbody>
          </table>
        </div>
      </div>

      
      <div style="display:flex; flex-direction:column; gap:18px;">

        
        <div class="card">
          <div class="section-header" style="margin-bottom:0;">
            <span class="section-title">
              <svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              Stock de flores
            </span>
            <a class="section-link" href="catalogo.php">
              Gestionar
              <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
            </a>
          </div>
          <div style="margin-top:12px;" class="stock-items-list">
            
          </div>
        </div>

      </div>
    </div>

    
    <div class="card" style="margin-bottom:20px;">
      <div class="section-header" style="margin-bottom:0;">
        <span class="section-title">
          <svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
          Ventas de la semana
        </span>
        <span style="font-size:0.78rem; color:var(--text-light);">
          Total: <strong style="color:var(--rose);">Bs. 14,820</strong>
        </span>
      </div>
      <div class="chart-wrap">
        <div class="chart-col"><div class="chart-bar" style="height:45%;"></div><span class="chart-day">Lun</span></div>
        <div class="chart-col"><div class="chart-bar" style="height:65%;"></div><span class="chart-day">Mar</span></div>
        <div class="chart-col"><div class="chart-bar" style="height:40%;"></div><span class="chart-day">Mié</span></div>
        <div class="chart-col"><div class="chart-bar" style="height:80%;"></div><span class="chart-day">Jue</span></div>
        <div class="chart-col"><div class="chart-bar" style="height:55%;"></div><span class="chart-day">Vie</span></div>
        <div class="chart-col"><div class="chart-bar" style="height:90%;"></div><span class="chart-day">Sáb</span></div>
        <div class="chart-col">
          <div class="chart-bar today" style="height:60%;"></div>
          <span class="chart-day" style="color:var(--rose); font-weight:600;">Hoy</span>
        </div>
      </div>
    </div>

  </main>
</div>

<script src="../assets/js/main.js"></script>
<script src="../assets/js/dashboard.js"></script>
<script>
  
  API.cargar(API.dashboard.bind(API), function(data) {
    window.DASHBOARD = data;
    window.PEDIDOS   = data.pedidos_recientes || [];
    if (typeof initDashboard === 'function') initDashboard(data);
  }, 'DASHBOARD');
</script>
<script src="../assets/js/petalos-global.js"></script>
</body>
</html>