<?php
session_start();
if (empty($_SESSION["id"]) || empty($_SESSION["rol"]) || $_SESSION["tipo"] !== "empleado") {
    $root = preg_replace('/\/public\/empleado\/[^\/]+$/', '', $_SERVER['SCRIPT_NAME']);
    header("Location: " . $root . "/public/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" href="../assets/css/fonts-panel.css">
    <link rel="stylesheet" href="../assets/css/styles-empleado.css"/>
  <title>Clientes — Florería Alesli</title>
  <style>
    html { overflow-x: hidden; }
    body { overflow-x: hidden; width: 100%; }
    .app-layout { width: 100%; max-width: 100vw; overflow-x: hidden; }
    .topbar { min-width: 0; box-sizing: border-box; }
    .main-content { min-width: 0; width: 100%; box-sizing: border-box; overflow-x: hidden; }
    .stats-strip { width: 100%; box-sizing: border-box; }
    .table-card { min-width: 0; box-sizing: border-box; width: 100%; }
    .table-wrap { overflow-x: auto; }
  </style>
</head>
<body>
<script src="../assets/js/api.js"></script>
<script>
  API.requireAuth('login.php');
  document.addEventListener('DOMContentLoaded', () => API.injectUserInfo());
</script>

<!-- Overlay mobile sidebar -->
<div id="sidebar-overlay"
     style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.3);z-index:99;"
     onclick="this.style.display='none';document.querySelector('.sidebar').classList.remove('open')">
</div>

<!-- Toast container -->
<div id="toast-container"></div>

<!-- Panel backdrop -->
<div id="panel-overlay"
     style="display:none;position:fixed;inset:0;z-index:140;background:rgba(45,26,34,0.3);"
     onclick="closePanel()">
</div>

<!-- ══════════════════ DETAIL PANEL ══════════════════ -->
<div id="detail-panel" class="detail-panel" style="display:none;">
  <div class="detail-panel-header">
    <span class="section-title">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
        <circle cx="12" cy="7" r="4"/>
      </svg>
      Detalle del cliente
    </span>
    <button class="modal-close" onclick="closePanel()" aria-label="Cerrar panel">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="18" y1="6" x2="6" y2="18"/>
        <line x1="6" y1="6" x2="18" y2="18"/>
      </svg>
    </button>
  </div>
  <div class="detail-panel-body" id="panel-content"></div>
</div>

<!-- ══════════════════ MODAL CREAR / EDITAR ══════════════════ -->
<div id="modal-overlay" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="modal-title">
  <div class="modal">
    <div class="modal-header">
      <div>
        <div class="modal-title" id="modal-title">Nuevo cliente</div>
        <div class="modal-subtitle">Completa los datos del cliente</div>
      </div>
      <button class="modal-close" onclick="closeModal()" aria-label="Cerrar">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"/>
          <line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>

    <div class="modal-body">
      <input type="hidden" id="edit-id"/>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" for="f-nombre">Nombre *</label>
          <input class="form-input" id="f-nombre" placeholder="Ej. Ana Quispe" required autocomplete="given-name"/>
        </div>
        <div class="form-group">
          <label class="form-label" for="f-apellido">Apellido *</label>
          <input class="form-input" id="f-apellido" placeholder="Ej. Mamani" autocomplete="family-name"/>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" for="f-telefono">Teléfono *</label>
          <input class="form-input" id="f-telefono" placeholder="Ej. 70012345" type="tel" autocomplete="tel"/>
        </div>
        <div class="form-group">
          <label class="form-label" for="f-email">Email</label>
          <input class="form-input" id="f-email" type="email" placeholder="correo@ejemplo.com" autocomplete="email"/>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="f-direccion">Dirección</label>
        <input class="form-input" id="f-direccion" placeholder="Ej. Av. Arce 1234, Sopocachi" autocomplete="street-address"/>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" for="f-tipo">Tipo de cliente</label>
          <select class="form-select" id="f-tipo">
            <option value="nuevo">🌱 Nuevo</option>
            <option value="frecuente">💛 Frecuente</option>
            <option value="vip">⭐ VIP</option>
            <option value="inactivo">😴 Inactivo</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="f-cumple">Fecha de cumpleaños</label>
          <input class="form-input" id="f-cumple" type="date"/>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="f-notas">Notas / Preferencias</label>
        <textarea class="form-textarea" id="f-notas" placeholder="Flores favoritas, alergias, preferencias de entrega..."></textarea>
      </div>
    </div>

    <div class="modal-footer">
      <button class="btn-outline" onclick="closeModal()">Cancelar</button>
      <button class="btn-primary" onclick="saveCliente()">
        <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" width="15" height="15">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
        Guardar cliente
      </button>
    </div>
  </div>
</div>

<!-- ══════════════════ MODAL ELIMINAR ══════════════════ -->
<div id="confirm-overlay" class="modal-overlay" role="alertdialog" aria-modal="true">
  <div class="modal" style="max-width:380px;">
    <div class="modal-header">
      <div>
        <div class="modal-title" style="color:#dc2626;">⚠️ Eliminar cliente</div>
        <div class="modal-subtitle">Esta acción es permanente</div>
      </div>
      <button class="modal-close" onclick="closeConfirm()" aria-label="Cerrar">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"/>
          <line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>
    <div class="modal-body">
      <p style="font-size:.9rem;color:var(--text-light);line-height:1.6;">
        ¿Seguro que deseas eliminar a <strong id="confirm-name" style="color:var(--text);"></strong>?
        Esta acción no se puede deshacer y se perderán todos sus datos.
      </p>
    </div>
    <div class="modal-footer">
      <button class="btn-outline" onclick="closeConfirm()">Cancelar</button>
      <button class="btn-primary" style="background:#dc2626;" onclick="confirmDelete()">
        <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" width="15" height="15">
          <polyline points="3 6 5 6 21 6"/>
          <path d="M19 6l-1 14H6L5 6"/>
          <path d="M10 11v6M14 11v6"/>
          <path d="M9 6V4h6v2"/>
        </svg>
        Sí, eliminar
      </button>
    </div>
  </div>
</div>

<!-- ══════════════════ APP LAYOUT ══════════════════ -->
<div class="app-layout">

  <!-- ─── SIDEBAR ─── -->
  <aside class="sidebar">
    <a class="sidebar-logo" href="dashboard.php">
      <div class="sidebar-logo-icon">
        <svg viewBox="0 0 24 24">
          <path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/>
        </svg>
      </div>
      <div>
        <div class="sidebar-logo-text">Florería <span>Alesli</span></div>
        <span class="sidebar-logo-badge">Empleado</span>
      </div>
    </a>

    <nav class="sidebar-nav" aria-label="Navegación principal">
      <p class="sidebar-section-label">Principal</p>

      <a class="nav-item" href="dashboard.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <rect x="3" y="3" width="7" height="7" rx="1"/>
          <rect x="14" y="3" width="7" height="7" rx="1"/>
          <rect x="3" y="14" width="7" height="7" rx="1"/>
          <rect x="14" y="14" width="7" height="7" rx="1"/>
        </svg>
        Dashboard
      </a>

      <a class="nav-item" href="pedidos.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>
          <line x1="3" y1="6" x2="21" y2="6"/>
          <path d="M16 10a4 4 0 01-8 0"/>
        </svg>
        Pedidos
        <span class="nav-badge">5</span>
      </a>

      <a class="nav-item" href="catalogo.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M12 2C8 6 4 8 4 13a8 8 0 0016 0c0-5-4-7-8-11z"/>
        </svg>
        Catálogo / Stock
        <span class="nav-badge warning">2</span>
      </a>

      <a class="nav-item active" href="clientes.php" aria-current="page">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
          <circle cx="9" cy="7" r="4"/>
          <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/>
        </svg>
        Clientes
      </a>

      <p class="sidebar-section-label">Ventas</p>

      <a class="nav-item" href="ventas.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <line x1="12" y1="1" x2="12" y2="23"/>
          <path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/>
        </svg>
        Caja / Ventas
      </a>

      <p class="sidebar-section-label">Otros</p>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 01-3.46 0"/>
        </svg>
        Notificaciones
        <span class="nav-badge">3</span>
      </a>

      <a class="nav-item" href="#">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <circle cx="12" cy="12" r="3"/>
          <path d="M19.07 4.93l-1.41 1.41M4.93 4.93l1.41 1.41M12 2v2M12 20v2M20 12h2M2 12h2M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41"/>
        </svg>
        Configuración
      </a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-card" onclick="logout()" role="button" tabindex="0" aria-label="Cerrar sesión">
        <div class="user-avatar">MG</div>
        <div class="user-info">
          <div class="user-name">María González</div>
          <div class="user-role">Empleada</div>
        </div>
        <svg viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="1.8">
          <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
          <polyline points="16 17 21 12 16 7"/>
          <line x1="21" y1="12" x2="9" y2="12"/>
        </svg>
      </div>
    </div>
  </aside>

  <!-- ─── TOPBAR ─── -->
  <header class="topbar">
    <button id="menu-btn"
            style="display:none;background:none;border:none;cursor:pointer;padding:4px;"
            aria-label="Abrir menú"
            onclick="document.querySelector('.sidebar').classList.toggle('open');document.getElementById('sidebar-overlay').style.display='block'">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--text)" stroke-width="2" stroke-linecap="round">
        <line x1="3" y1="6" x2="21" y2="6"/>
        <line x1="3" y1="12" x2="21" y2="12"/>
        <line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>

    <h1 class="topbar-title">
      Clientes <span>· Florería Alesli</span>
    </h1>

    <div class="topbar-search">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="11" cy="11" r="7"/>
        <path d="M16.5 16.5l4 4"/>
      </svg>
      <input
        type="search"
        id="search-input"
        placeholder="Buscar por nombre, teléfono…"
        oninput="renderTable()"
        autocomplete="off"
        aria-label="Buscar clientes"
      />
    </div>

    <div class="topbar-actions">
      <button class="topbar-btn" title="Notificaciones" aria-label="Notificaciones">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 01-3.46 0"/>
        </svg>
        <span class="topbar-notif-dot"></span>
      </button>

      <button class="topbar-btn" title="Exportar CSV" aria-label="Exportar como CSV" onclick="exportCSV()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
          <polyline points="7 10 12 15 17 10"/>
          <line x1="12" y1="15" x2="12" y2="3"/>
        </svg>
      </button>
    </div>

    <div class="topbar-date" aria-live="polite">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="3" y="4" width="18" height="18" rx="2"/>
        <line x1="16" y1="2" x2="16" y2="6"/>
        <line x1="8" y1="2" x2="8" y2="6"/>
        <line x1="3" y1="10" x2="21" y2="10"/>
      </svg>
      <span id="live-date">Cargando fecha...</span>
    </div>
  </header>

  <!-- ─── MAIN ─── -->
  <main class="main-content">

    <!-- ── KPIs ── -->
    <div class="stats-strip">

      <div class="stat-card">
        <div class="stat-icon pink">
          <svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke="currentColor">
            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
            <circle cx="9" cy="7" r="4"/>
            <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/>
          </svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="kpi-total">—</div>
          <div class="stat-label">Total clientes</div>
          <div class="stat-trend up">
            <svg viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
            +2 este mes
          </div>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon" style="background:#f3e8ff;">
          <svg viewBox="0 0 24 24" fill="none" stroke="#7e22ce" stroke-width="1.8">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="kpi-vip">—</div>
          <div class="stat-label">Clientes VIP</div>
          <div class="stat-trend up">
            <svg viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
            +1 este mes
          </div>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon pink">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
          </svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="kpi-frecuente">—</div>
          <div class="stat-label">Frecuentes</div>
          <div class="stat-trend up">
            <svg viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
            Activos
          </div>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon amber">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <rect x="3" y="4" width="18" height="18" rx="2"/>
            <line x1="16" y1="2" x2="16" y2="6"/>
            <line x1="8" y1="2" x2="8" y2="6"/>
            <line x1="3" y1="10" x2="21" y2="10"/>
          </svg>
        </div>
        <div class="stat-info">
          <div class="stat-value" id="kpi-cumple">—</div>
          <div class="stat-label">Cumpleaños este mes</div>
          <div class="stat-trend warn">
            <svg viewBox="0 0 24 24"><polyline points="18 9 12 15 6 9"/></svg>
            ¡No olvidar!
          </div>
        </div>
      </div>

    </div>
    <!-- ── fin KPIs ── -->

    <!-- ── TABLA CLIENTES ── -->
    <div class="table-card">

      <!-- Toolbar de la tabla -->
      <div class="toolbar" style="padding:18px 20px 0;">
        <span class="section-title">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
            <circle cx="9" cy="7" r="4"/>
            <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/>
          </svg>
          Lista de clientes
        </span>

        <div class="filter-tabs" role="group" aria-label="Filtrar por tipo">
          <button class="filter-tab active" onclick="setFilter('todos',this)">Todos</button>
          <button class="filter-tab" onclick="setFilter('vip',this)">⭐ VIP</button>
          <button class="filter-tab" onclick="setFilter('frecuente',this)">💛 Frecuentes</button>
          <button class="filter-tab" onclick="setFilter('nuevo',this)">🌱 Nuevos</button>
          <button class="filter-tab" onclick="setFilter('inactivo',this)">Inactivos</button>
        </div>

        <div class="toolbar-right">
          <span style="font-size:.78rem;color:var(--text-light);">
            <strong id="count-label">0</strong> clientes encontrados
          </span>
          <button class="btn-primary" onclick="openModal()">
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" width="15" height="15">
              <line x1="12" y1="5" x2="12" y2="19"/>
              <line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            Nuevo cliente
          </button>
        </div>
      </div>

      <!-- Tabla -->
      <div class="table-wrap" style="margin-top:14px;">
        <table>
          <thead>
            <tr>
              <th>Cliente</th>
              <th>Teléfono</th>
              <th>Dirección</th>
              <th>Tipo</th>
              <th style="text-align:center;">Pedidos</th>
              <th>Último pedido</th>
              <th>Cumpleaños</th>
              <th style="text-align:center;">Acciones</th>
            </tr>
          </thead>
          <tbody id="clientes-tbody">
            <!-- filas generadas por JS -->
          </tbody>
        </table>
      </div>

      <!-- Paginación -->
      <div class="pagination">
        <span id="pagination-info" style="font-size:.78rem;color:var(--text-light);">
          Página 1 de 1
        </span>
        <div class="page-btns" id="pagination-btns" role="navigation" aria-label="Paginación">
          <!-- botones generados por JS -->
        </div>
      </div>

    </div>
    <!-- ── fin TABLA ── -->

  </main>
</div>

<script src="../assets/js/clientes.js"></script>
<script src="../assets/js/petalos-global.js"></script>
</body>
</html>