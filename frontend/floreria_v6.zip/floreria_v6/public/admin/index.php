<?php  ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Admin — Florería Alesli</title>
    <link rel="stylesheet" href="../assets/css/fonts-panel.css">
        <link rel="stylesheet" href="../assets/css/estilo-panel.css">
</head>
<body>
<script src="../assets/js/api.js"></script>
<script>
  
  (function() {
    const u = API.requireAuth('../empleado/login.php');
    if (u && u.rol !== 'admin') {
      window.location.replace('../empleado/dashboard.php');
    }
  })();
</script>
    <section>
        <div class="nav" id="nav">
            <ul>
                <li>
                    <a href="">
                        <span class="icono"><ion-icon name="flower-outline"></ion-icon></span>
                        <span class="titulo">Logo</span>
                    </a>
                </li>

                <li data-seccion="dashboard">
                    <a href="">
                        <span class="icono"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="titulo">Dashboard</span>
                    </a>
                </li>

                <li data-seccion="clientes">
                    <a href="">
                        <span class="icono"><ion-icon name="people-outline"></ion-icon></span>
                        <span class="titulo">Clientes</span>
                    </a>
                </li>

                <li data-seccion="ventas">
                    <a href="">
                        <span class="icono"><ion-icon name="cart-outline"></ion-icon></span>
                        <span class="titulo">Ventas</span>
                    </a>
                </li>

                <li>
                    <a href="">
                        <span class="icono"><ion-icon name="pricetags-outline"></ion-icon></span>
                        <span class="titulo">Productos /catalogo</span>
                    </a>
                </li>

                <li>
                    <a href="">
                        <span class="icono"><ion-icon name="help-circle-outline"></ion-icon></span>
                        <span class="titulo">Ayuda</span>
                    </a>
                </li>

                <li>
                    <a href="">
                        <span class="icono"><ion-icon name="settings-outline"></ion-icon></span>
                        <span class="titulo">Configuracion</span>
                    </a>
                </li>

                <li>
                    <a href="">
                        <span class="icono"><ion-icon name="log-in-outline"></ion-icon></span>
                        <span class="titulo">Cerrar sesion</span>
                    </a>
                </li>

                

                
            </ul>

            
        </div>

        
        <div class="container" id="container">

            
            <div class="top-bar">
                <div class="toggle" id="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <div class="buscar">
                    <label for="">
                        <input type="text" placeholder="Buscar" name="" id="">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>
                <div class="perfil-usuario">
                    <img src="../assets/img/profile-admin.jpg" alt="Admin" onerror="this.style.display='none'">
                </div>
            </div>
            

            
            
            <div class="vista activa" id="vista-dashboard">
                <h1 class="seccion-titulo">Dashboard</h1>

                <div class="cards">
                    <div class="card">
                        <div>
                            <span class="card-numeros" id="admin-card-pedidos">—</span>
                            <span class="card-nombre">Pedidos hoy</span>
                        </div>
                        <div class="card-icono">
                            <ion-icon name="eye-outline"></ion-icon>
                        </div>
                    </div>
                    <div class="card">
                        <div>
                            <span class="card-numeros" id="admin-card-ventas">—</span>
                            <span class="card-nombre">Ventas hoy (Bs.)</span>
                        </div>
                        <div class="card-icono">
                            <ion-icon name="card-outline"></ion-icon>
                        </div>
                    </div>
                    <div class="card">
                        <div>
                            <span class="card-numeros" id="admin-card-pendientes">—</span>
                            <span class="card-nombre">Pendientes</span>
                        </div>
                        <div class="card-icono">
                            <ion-icon name="mail-open-outline"></ion-icon>
                        </div>
                    </div>
                    <div class="card">
                        <div>
                            <span class="card-numeros" id="admin-card-clientes">—</span>
                            <span class="card-nombre">Clientes activos</span>
                        </div>
                        <div class="card-icono">
                            <ion-icon name="rose-outline"></ion-icon>
                        </div>
                    </div>
                </div>

                <div class="detalles">
                    <div class="ordenes-recientes">
                        <div class="header">
                            <h2>Ordenes recientes</h2>
                            <a href="" class="boton">Ver todos</a>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Precio</th>
                                    <th>Pago</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Ramo de rosas</td>
                                    <td>precio 120</td>
                                    <td>estado</td>
                                    <td><span class="estatus pendiente">pendiente</span></td>
                                </tr>
                                <tr>
                                    <td>Ramo de rosas</td>
                                    <td>precio 120</td>
                                    <td>estado</td>
                                    <td><span class="estatus pendiente">pendiente</span></td>
                                </tr>
                                <tr>
                                    <td>Ramo de rosas</td>
                                    <td>precio 120</td>
                                    <td>estado</td>
                                    <td><span class="estatus entregado">Entregado</span></td>
                                </tr>
                                <tr>
                                    <td>Ramo de rosas</td>
                                    <td>precio 120</td>
                                    <td>estado</td>
                                    <td><span class="estatus cancelado">cancelado</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="vista" id="vista-clientes">
                <h1 class="seccion-titulo">Clientes</h1>

                <div class="detalles">
                    <div class="ordenes-recientes">
                        <div class="header">
                            <h2>Lista de clientes</h2>
                            <button class="boton">+ Nuevo cliente</button>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Cliente</th>
                                    <th>Correo</th>
                                    <th>Pedidos</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><span class="avatar">AM</span>Ana María</td>
                                    <td>ana@correo.com</td>
                                    <td>12</td>
                                    <td><span class="estatus entregado">Activo</span></td>
                                </tr>
                                <tr>
                                    <td><span class="avatar">JR</span>Juan Ríos</td>
                                    <td>juan@correo.com</td>
                                    <td>5</td>
                                    <td><span class="estatus entregado">Activo</span></td>
                                </tr>
                                <tr>
                                    <td><span class="avatar">LP</span>Lucía Pérez</td>
                                    <td>lucia@correo.com</td>
                                    <td>3</td>
                                    <td><span class="estatus cancelado">Inactivo</span></td>
                                </tr>
                                <tr>
                                    <td><span class="avatar">CM</span>Carlos Mamani</td>
                                    <td>carlos@correo.com</td>
                                    <td>8</td>
                                    <td><span class="estatus pendiente">Pendiente</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            

            
                <div class="vista" id="vista-ventas">
    <h1 class="seccion-titulo">Ventas</h1>

    <div class="detalles">
        <div class="ordenes-recientes">
            <div class="header">
                <h2>Pedidos realizados</h2>
                <button class="boton">+ Nuevo pedido</button>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th>Producto</th>
                        <th>Total</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><span class="avatar">AM</span>Ana María</td>
                        <td>Ramo de rosas</td>
                        <td>Bs. 120</td>
                        <td>13/05/2026</td>
                        <td><span class="estatus entregado">Entregado</span></td>
                    </tr>
                    <tr>
                        <td><span class="avatar">JR</span>Juan Ríos</td>
                        <td>Arreglo floral</td>
                        <td>Bs. 250</td>
                        <td>12/05/2026</td>
                        <td><span class="estatus pendiente">Pendiente</span></td>
                    </tr>
                    <tr>
                        <td><span class="avatar">LP</span>Lucía Pérez</td>
                        <td>Girasoles x12</td>
                        <td>Bs. 90</td>
                        <td>11/05/2026</td>
                        <td><span class="estatus cancelado">Cancelado</span></td>
                    </tr>
                    <tr>
                        <td><span class="avatar">CM</span>Carlos Mamani</td>
                        <td>Ramo mixto</td>
                        <td>Bs. 180</td>
                        <td>10/05/2026</td>
                        <td><span class="estatus entregado">Entregado</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
            

        </div>
        
    </section>

    

    <script src="../assets/js/panel.js"></script>
    <script>
      API.cargar(API.dashboard.bind(API), function(data) {
        var fmt = function(n) { return n !== undefined && n !== null ? n : '—'; };
        document.getElementById('admin-card-pedidos').textContent    = fmt(data.pedidos_hoy);
        document.getElementById('admin-card-ventas').textContent     = parseFloat(data.ventas_hoy || 0).toFixed(2);
        document.getElementById('admin-card-pendientes').textContent = fmt(data.pendientes);
        document.getElementById('admin-card-clientes').textContent   = fmt(data.clientes);
      }, 'DASHBOARD');
    </script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="../assets/js/petalos-global.js"></script>
</body>
</html>
