<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Catálogo — Florería Alesli</title>
  <link rel="stylesheet" href="assets/css/estilo.css">
  <link rel="stylesheet" href="assets/css/fonts-cliente.css">
  <link rel="stylesheet" href="assets/css/fonts-catalogo.css">
    <link rel="stylesheet" href="assets/css/catalogo-page.css">
</head>
<body>
  <header class="nav-bar">
    <div class="logo"><a href="index.php" style="text-decoration:none;color:inherit;">Floreria <span>alesli</span></a></div>
    <nav>
      <a href="index.php">Inicio</a>
      <a href="catalogo.php" class="active">Catálogo</a>
      <a href="personalizar.php">Personalizar</a>
      <a href="nosotros.php">Nosotros</a>
      <a href="nosotros.php#contacto">Contacto</a>
    </nav>
    <div class="action" id="nav-action">
      <button class="btn-login" onclick="AuthModal.open()">Entrar</button>
    </div>
  </header>

  <!-- Hero del catálogo -->
  <div class="catalogo-hero">
    <p class="tag-line">🌸 Nuestras flores</p>
    <h1>Elige tu <span>ramo perfecto</span></h1>
    <p id="catalogo-saludo">Arreglos frescos, entrega el mismo día en La Paz. Filtra por categoría o busca tu flor favorita.</p>

    <!-- Búsqueda -->
    <div style="max-width:440px;margin:0 auto 1.5rem;position:relative;">
      <input id="busqueda" type="text" placeholder="Buscar producto…"
        style="width:100%;padding:.75rem 1.2rem .75rem 2.8rem;border:2px solid #f5d5e2;border-radius:2rem;font-size:.9rem;font-family:'Poppins',sans-serif;outline:none;box-sizing:border-box;color:#333;"
        oninput="filtrarProductos()">
      <span style="position:absolute;left:.95rem;top:50%;transform:translateY(-50%);color:#c24d77;font-size:1.05rem;">🔍</span>
    </div>

    <!-- Filtros de categoría -->
    <div class="filtros" id="filtros">
      <button class="filtro-btn activo" data-cat="todos" onclick="setCategoria('todos',this)">Todos</button>
    </div>
  </div>

  <!-- Grid de productos -->
  <div class="catalogo-grid" id="catalogo-grid">
    <!-- skeletons mientras carga -->
    <div class="skeleton-card"><div class="skeleton-img"></div><div class="skeleton-body"><div class="skeleton-line"></div><div class="skeleton-line short"></div></div></div>
    <div class="skeleton-card"><div class="skeleton-img"></div><div class="skeleton-body"><div class="skeleton-line"></div><div class="skeleton-line short"></div></div></div>
    <div class="skeleton-card"><div class="skeleton-img"></div><div class="skeleton-body"><div class="skeleton-line"></div><div class="skeleton-line short"></div></div></div>
    <div class="skeleton-card"><div class="skeleton-img"></div><div class="skeleton-body"><div class="skeleton-line"></div><div class="skeleton-line short"></div></div></div>
  </div>

  <!-- Modal detalle -->
  <div class="detalle-overlay" id="detalle-overlay" onclick="if(event.target===this)cerrarDetalle()">
    <div class="detalle-modal" id="detalle-modal">
      <button class="detalle-close" onclick="cerrarDetalle()">✕</button>
      <img id="det-img" class="detalle-img" src="assets/img/flores1.jpeg" alt="">
      <div class="detalle-body">
        <div class="detalle-categoria" id="det-cat"></div>
        <h2 class="detalle-nombre" id="det-nombre"></h2>
        <div class="detalle-precio" id="det-precio"></div>
        <p class="detalle-desc" id="det-desc"></p>
        <div class="detalle-stock" id="det-stock"></div>
        <div class="detalle-qty">
          <button onclick="cambiarQty(-1)">−</button>
          <span id="det-qty">1</span>
          <button onclick="cambiarQty(1)">+</button>
        </div>
        <button class="detalle-add" id="det-add" onclick="agregarDesdeDetalle()">🛒 Añadir al carrito</button>
      </div>
    </div>
  </div>

  <!-- Toast -->
  <div id="cat-toast"></div>

  <!-- FAB carrito -->
  <a href="carrito.php" class="fab-cart">
    <ion-icon name="cart-outline"></ion-icon>
    <span class="fab-badge" id="fab-badge">0</span>
  </a>

  <footer class="footer" style="margin-top:2rem;">
    <div class="footer-logo">🌸 Florería Alesli</div>
    <div class="copyright">© 2026 Florería Alesli. Hecho con ✨ para ti.</div>
  </footer>

  <script src="assets/js/cliente-auth.js"></script>
  <script src="assets/js/nav-perfil.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/tsparticles-confetti@2.12.0/tsparticles.confetti.bundle.min.js"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="assets/js/petalos-global.js"></script>
    <script src="assets/js/catalogo-page.js"></script>
</body>
</html>
