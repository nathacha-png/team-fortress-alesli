<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Florería Alesli</title>
    <link rel="stylesheet" href="assets/css/fonts-cliente.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/index-page.css">
</head>
<body>
    <header class="nav-bar">
        <div class="logo"><a href="index.php" style="text-decoration:none;color:inherit;">Floreria <span>alesli</span></a></div>
        <nav>
            <a href="index.php" class="active">Inicio</a>
            <a href="catalogo.php">Catálogo</a>
            <a href="personalizar.php">Personalizar</a>
            <a href="nosotros.php">Nosotros</a>
            <a href="nosotros.php#contacto">Contacto</a>
        </nav>
        <div class="action" id="nav-action">
            <!-- Reemplazado dinámicamente por nav-perfil.js -->
            <button class="btn-login" onclick="AuthModal.open()">Entrar</button>
        </div>
    </header>
    <!-- ══ HERO ══ -->
    <section class="hero">

      <!-- Izquierda: contenido -->
      <div class="hero-left">
        <div class="tag-line">
          <div class="tag-line-inner">
            <span class="tag-dot"></span>
            hecho con amor desde La Paz
          </div>
        </div>

        <h1>
          <span class="word-main">Flores que</span>
          <span class="word-italic">cuentan</span>
          <span class="word-fill">tu historia</span>
        </h1>

        <p class="descripcion" id="hero-descripcion">En Florería Alesli diseñamos arreglos únicos para cada momento especial. Frescura, elegancia y entrega a domicilio el mismo día.</p>

        <div class="cta-buttons">
          <button class="btn-primary" onclick="window.location.href='catalogo.php'">Ver Catálogo</button>
          <button class="btn-secundary" onclick="window.location.href='personalizar.php'">✦ Personalizar</button>
        </div>

        <div class="hero-separator"><span>Nuestros números</span></div>

        <div class="stats">
          <div class="stat-item">
            <span class="stat-number">1.2<sup>k</sup></span>
            <span class="stat-label">Clientes felices</span>
          </div>
          <div class="stat-item">
            <span class="stat-number">4.9<sup>★</sup></span>
            <span class="stat-label">Valoración</span>
          </div>
          <div class="stat-item">
            <span class="stat-number">24<sup>h</sup></span>
            <span class="stat-label">Entrega rápida</span>
          </div>
        </div>
      </div>

      <!-- Derecha: imagen full-height -->
      <div class="hero-right">
        <img src="assets/img/imagen-ini.jpeg" alt="Arreglo floral Alesli">

        <div class="hero-badge rating">
          <div>
            <div class="rating-stars">★★★★★</div>
            <div class="rating-label">Calificación</div>
          </div>
          <div class="rating-score">4.9</div>
        </div>

        <div class="hero-badge order">
          <div class="order-label">Pedido entregado</div>
          <div class="order-name">Ramo "Eterna"</div>
          <div class="order-meta">Hace 20 minutos · La Paz</div>
        </div>

        <div class="hero-badge flowers">🌸 +200 variedades</div>
      </div>

    </section>

    <!-- Scripts base -->
    <script src="https://cdn.jsdelivr.net/npm/tsparticles-confetti@2.12.0/tsparticles.confetti.bundle.min.js"></script>
    <script src="assets/js/efecto-petalos.js"></script>
    <script src="assets/js/cliente-auth.js"></script>

    <script src="assets/js/nav-perfil.js"></script>

    <!-- FRANJA -->
    <div class="sections-strip">
      <div class="strip-item">
        <span class="strip-tag">— Explora —</span>
        <div class="strip-title">Tu ramo perfecto</div>
      </div>
      <div class="strip-item">
        <span class="strip-tag">— Síguenos —</span>
        <div class="strip-title">Nuestros videos</div>
      </div>
      <div class="strip-item">
        <span class="strip-tag">— Reseñas —</span>
        <div class="strip-title">Clientes felices</div>
      </div>
    </div>

    <!-- EXPLORAR -->
    <section class="explore">
        <span class="seccion-tag">EXPLORA</span>
        <h2>Tu ramo perfecto te espera</h2>
        <p>Elige entre nuestro catálogo o personaliza un arreglo único pensado para ti.</p>
        <div class="product-grid">
            <div class="product-card">
                <div class="product-image"><img src="assets/img/flores1.jpeg" alt=""></div>
                <div class="product-info">
                    <h3>Ramo "Amanecer"</h3>
                    <p class="price">50bs</p>
                    <p class="product-desc">Combinación de rosas rosadas y follaje silvestre</p>
                    <div class="product-action">
                        <button class="btn-info">Ver detalles</button>
                        <button class="btn-cart">🛒 Añadir</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- MEDIA: YouTube + TikTok -->
    <section class="media-section">
      <span class="section-tag">SÍGUENOS</span>
      <h2>Flores en <em>movimiento</em></h2>
      <p class="media-subtitle">Descubre nuestra florería, nuestros diseños y cómo llegar hasta nosotros a través de nuestros videos.</p>
      <div class="media-grid">
        <div class="media-card">
          <div class="media-card-header">
            <div class="media-icon youtube">▶</div>
            <div>
              <div class="media-card-title">Florería Alesli — Tour</div>
              <div class="media-card-platform">YouTube</div>
            </div>
          </div>
          <div class="media-embed-wrap">
            <iframe src="https://www.youtube.com/embed/6Vh3_WvMHKc?rel=0&modestbranding=1" height="260" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen title="Florería Alesli" style="border-radius:16px;"></iframe>
          </div>
        </div>
        <div class="media-card">
          <div class="media-card-header">
            <div class="media-icon tiktok">♪</div>
            <div>
              <div class="media-card-title">¿Cómo llegar a Alesli?</div>
              <div class="media-card-platform">TikTok · @alesli_floreria_lp</div>
            </div>
          </div>
          <div class="media-embed-wrap">
            <blockquote class="tiktok-embed" cite="https://www.tiktok.com/@alesli_floreria_lp/video/7633836103182601479" data-video-id="7633836103182601479" style="max-width:100%;min-width:unset;border-left:none;padding:0;margin:0;background:transparent;">
              <section><a target="_blank" href="https://www.tiktok.com/@alesli_floreria_lp?refer=embed">@alesli_floreria_lp</a> A veces el detalle perfecto sí existe 💖 Te mostramos cómo llegar a Aleslí 💐✨</section>
            </blockquote>
            <script async src="https://www.tiktok.com/embed.js"></script>
          </div>
        </div>
      </div>
      <div class="media-social-links">
        <a href="https://youtu.be/6Vh3_WvMHKc" target="_blank" class="social-pill yt">▶ &nbsp;Ver en YouTube</a>
        <a href="https://www.tiktok.com/@alesli_floreria_lp" target="_blank" class="social-pill tt">♪ &nbsp;Seguir en TikTok</a>
      </div>
    </section>

    <!-- FAQ -->
    <div class="faq">
        <span class="section-faq">AYUDA</span>
        <h2>Preguntas Frecuentes</h2>
        <div class="faq-container">
            <details class="faq-item">
                <summary>¿Hacen entregas el mismo día? <span class="icon">+</span></summary>
                <div class="faq-content"><p>Sí. Los pedidos realizados antes de las 14:00 se entregan el mismo día en toda la ciudad de La Paz.</p></div>
            </details>
            <details class="faq-item">
                <summary>¿Puedo personalizar mi ramo? <span class="icon">+</span></summary>
                <div class="faq-content"><p>¡Por supuesto! Cuéntanos los colores, tipo de flores y presupuesto. Puedes escribirnos por WhatsApp o dejar una nota en tu pedido.</p></div>
            </details>
            <details class="faq-item">
                <summary>¿Qué métodos de pago aceptan? <span class="icon">+</span></summary>
                <div class="faq-content"><p>Efectivo, QR (Tigo Money, Pago Fácil), transferencia bancaria y tarjeta de crédito/débito.</p></div>
            </details>
            <details class="faq-item">
                <summary>¿Qué pasa si las flores llegan en mal estado? <span class="icon">+</span></summary>
                <div class="faq-content"><p>Política de cambio dentro de las 12 horas. Envíanos una foto por WhatsApp y coordinamos el reemplazo sin costo.</p></div>
            </details>
            <details class="faq-item">
                <summary>¿Atienden los domingos? <span class="icon">+</span></summary>
                <div class="faq-content"><p>Sí, de 09:00 a 14:00 en tienda. Pedidos online con entrega el lunes.</p></div>
            </details>
        </div>
    </div>

    <!-- ABOUT -->
    <section class="about">
        <span class="section-tag">SOBRE NOSOTROS</span>
        <h2>La historia de <span>Alesli</span></h2>
        <p class="about-text">Florería Alesli nació en 2015 del sueño de transformar momentos en recuerdos inolvidables a través de las flores.</p>
        <div class="features-grid">
            <div class="feature-card"><div class="icon-box">❤️</div><h3>Hecho con amor</h3><p>Cada arreglo es una pieza única y artesanal</p></div>
            <div class="feature-card"><div class="icon-box">🍃</div><h3>Flores frescas</h3><p>Cosechadas de productores locales</p></div>
            <div class="feature-card"><div class="icon-box">🚚</div><h3>Envíos coordinados</h3><p>Entrega a domicilio el mismo día en la ciudad.</p></div>
            <div class="feature-card"><div class="icon-box">🏅</div><h3>Calidad premium</h3><p>Más de 1.200 clientes satisfechos lo respaldan.</p></div>
        </div>
    </section>

    <!-- TESTIMONIOS -->
    <section class="testimonials">
        <span class="section-tag">RESEÑAS</span>
        <h2>Lo que dicen nuestros clientes</h2>
        <div class="testimonial-grid">
            <div class="testi-card"><div class="testi-stars">★★★★★</div><p>El ramo llegó impecable y las flores duraron más de una semana. ¡El mejor regalo que he dado en años!</p><span>Andrés Flores Moya</span></div>
            <div class="testi-card"><div class="testi-stars">★★★★★</div><p>Pedí un arreglo personalizado para la boda de mi hermana y superaron todas mis expectativas.</p><span>Carla Romero</span></div>
            <div class="testi-card"><div class="testi-stars">★★★★★</div><p>Entregan rapidísimo y las flores siempre frescas. Ya les compré cuatro veces y nunca han fallado.</p><span>Roberto Quispe</span></div>
        </div>
    </section>

    <!-- FAB carrito -->
    <a href="carrito.php" class="boton-emergencia" id="fab-carrito" style="position:relative;">
      <span class="icono"><ion-icon name="cart-outline"></ion-icon></span>
      <span id="fab-badge" style="display:none;position:absolute;top:-4px;right:-4px;background:#333;color:#fff;font-size:.65rem;font-weight:700;width:20px;height:20px;border-radius:50%;align-items:center;justify-content:center;">0</span>
    </a>

    <footer class="footer">
        <div class="footer-logo">🌸 Florería Alesli</div>
        <div class="copyright">© 2026 Florería Alesli. Hecho con ✨ para ti.</div>
    </footer>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="assets/js/petalos-global.js"></script>
    <script src="assets/js/index-page.js"></script>
</body>
</html>
