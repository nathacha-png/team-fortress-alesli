<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Florería Alesli</title>
    <link rel="stylesheet" href="assets/css/fonts-cliente.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <style>
    
    .hero {
      display: grid;
      grid-template-columns: 55% 45%;
      min-height: 100vh;
      position: relative;
      overflow: hidden;
    }

    
    .hero-left {
      padding: 155px 6% 80px 8%;
      display: flex;
      flex-direction: column;
      justify-content: center;
      position: relative;
      z-index: 2;
    }

    
    .hero-left::after {
      content: '';
      position: absolute;
      top: 20%; right: 0;
      width: 1px;
      height: 60%;
      background: linear-gradient(to bottom, transparent, rgba(194,77,119,0.18), transparent);
    }

    
    .hero-right {
      position: relative;
      overflow: hidden;
    }

    .hero-right img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center 20%;
      animation: heroZoom 18s ease-in-out infinite alternate;
      filter: brightness(0.88) saturate(1.15);
    }

    @keyframes heroZoom {
      0%   { transform: scale(1) translateX(0); }
      100% { transform: scale(1.08) translateX(-12px); }
    }

    
    .hero-right::before {
      content: '';
      position: absolute;
      inset: 0;
      z-index: 1;
      background:
        linear-gradient(to right, var(--ivory) 0%, rgba(253,240,244,0.2) 20%, transparent 50%),
        linear-gradient(to top, rgba(26,16,24,0.35) 0%, transparent 55%);
      pointer-events: none;
    }

    
    .hero-right::after {
      content: '';
      position: absolute;
      inset: 0;
      z-index: 1;
      background-image: radial-gradient(circle, rgba(244,184,204,0.06) 1px, transparent 1px);
      background-size: 24px 24px;
      pointer-events: none;
    }

    
    .tag-line {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      width: fit-content;
      margin-bottom: 32px;
      animation: fadeSlideDown 0.9s ease both;
    }

    .tag-line-inner {
      background: linear-gradient(135deg, rgba(194,77,119,0.09), rgba(212,168,67,0.05));
      border: 1px solid rgba(194,77,119,0.22);
      color: var(--rose-deep);
      padding: 8px 20px 8px 14px;
      border-radius: 50px;
      font-size: 0.68rem;
      font-weight: 700;
      letter-spacing: 2.2px;
      text-transform: uppercase;
      display: flex;
      align-items: center;
      gap: 9px;
    }

    .tag-dot {
      width: 6px; height: 6px;
      border-radius: 50%;
      background: var(--rose);
      animation: pulse 2s ease-in-out infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); box-shadow: 0 0 0 0 rgba(194,77,119,0.4); }
      50%       { opacity: 0.7; transform: scale(0.9); box-shadow: 0 0 0 5px rgba(194,77,119,0); }
    }

    
    .hero-left h1 {
      font-family: var(--ff-display);
      font-size: 5.2rem;
      line-height: 1.01;
      color: var(--dark);
      letter-spacing: -2.5px;
      margin-bottom: 26px;
      animation: fadeSlideUp 0.9s 0.1s ease both;
    }

    .hero-left h1 .word-main { display: block; }

    .hero-left h1 .word-italic {
      display: block;
      color: transparent;
      -webkit-text-stroke: 1.5px var(--rose);
      font-style: italic;
      font-weight: 300;
      position: relative;
    }

    .hero-left h1 .word-fill {
      display: block;
      color: var(--rose);
      font-style: italic;
      font-weight: 300;
    }

    
    .hero-left .descripcion {
      color: var(--soft);
      line-height: 1.85;
      font-size: 0.95rem;
      font-weight: 300;
      margin: 0 0 40px;
      max-width: 420px;
      animation: fadeSlideUp 0.9s 0.2s ease both;
    }

    
    .cta-buttons {
      display: flex;
      gap: 14px;
      flex-wrap: wrap;
      animation: fadeSlideUp 0.9s 0.3s ease both;
    }

    
    .hero-separator {
      display: flex;
      align-items: center;
      gap: 14px;
      margin: 44px 0 28px;
      animation: fadeSlideUp 0.9s 0.38s ease both;
    }

    .hero-separator::before,
    .hero-separator::after {
      content: '';
      flex: 1;
      height: 1px;
      background: linear-gradient(to right, transparent, rgba(194,77,119,0.15), transparent);
    }

    .hero-separator span {
      font-size: 0.62rem;
      color: var(--soft);
      letter-spacing: 3px;
      text-transform: uppercase;
      font-weight: 600;
      white-space: nowrap;
    }

    
    .stats {
      display: flex;
      gap: 0;
      animation: fadeSlideUp 0.9s 0.42s ease both;
    }

    .stat-item {
      display: flex;
      flex-direction: column;
      gap: 3px;
      padding: 0 28px 0 0;
      position: relative;
    }

    .stat-item:not(:last-child)::after {
      content: '';
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
      width: 1px;
      height: 28px;
      background: rgba(194,77,119,0.14);
    }

    .stat-item:last-child { padding-right: 0; }

    .stat-number {
      font-family: var(--ff-display);
      font-size: 2rem;
      color: var(--dark);
      font-weight: 600;
      line-height: 1;
      letter-spacing: -1px;
    }

    .stat-number sup {
      font-size: 1rem;
      color: var(--rose);
      font-style: italic;
    }

    .stat-label {
      font-size: 0.68rem;
      color: var(--soft);
      letter-spacing: 0.5px;
      font-weight: 400;
      text-transform: uppercase;
    }

    
    .hero-badge {
      position: absolute;
      z-index: 3;
    }

    .hero-badge.rating {
      top: 28%;
      left: -40px;
      background: rgba(255,255,255,0.97);
      backdrop-filter: blur(24px);
      border: 1px solid rgba(212,168,67,0.22);
      padding: 16px 22px;
      border-radius: 60px;
      display: flex;
      align-items: center;
      gap: 14px;
      box-shadow: 0 20px 50px rgba(0,0,0,0.13);
      animation: float1 6s ease-in-out infinite;
    }

    .rating-stars { color: var(--gold); font-size: 0.72rem; letter-spacing: 2px; }
    .rating-score { font-family: var(--ff-display); font-size: 1.5rem; color: var(--rose-deep); font-weight: 600; }
    .rating-label { font-size: 0.65rem; color: var(--soft); font-weight: 400; }

    .hero-badge.order {
      bottom: 22%;
      left: -32px;
      background: rgba(255,255,255,0.94);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(194,77,119,0.12);
      padding: 18px 22px;
      border-radius: 22px;
      box-shadow: 0 16px 40px rgba(194,77,119,0.14);
      animation: float2 7s ease-in-out 1.2s infinite;
      min-width: 200px;
    }

    .order-label {
      font-size: 0.62rem;
      font-weight: 700;
      letter-spacing: 2.2px;
      text-transform: uppercase;
      color: 
      margin-bottom: 5px;
      display: flex;
      align-items: center;
      gap: 5px;
    }

    .order-label::before {
      content: '';
      width: 6px; height: 6px;
      border-radius: 50%;
      background: 
      animation: pulse 1.5s infinite;
    }

    .order-name {
      font-family: var(--ff-display);
      font-size: 1rem;
      color: var(--dark);
      font-weight: 600;
      margin-bottom: 3px;
    }

    .order-meta { font-size: 0.72rem; color: var(--soft); }

    
    .hero-badge.flowers {
      top: 12%;
      right: 8%;
      background: linear-gradient(135deg, var(--rose), var(--rose-deep));
      color: 
      padding: 12px 20px;
      border-radius: 50px;
      font-size: 0.75rem;
      font-weight: 700;
      letter-spacing: 0.5px;
      box-shadow: 0 12px 30px rgba(194,77,119,0.45);
      animation: float3 5.5s ease-in-out 0.5s infinite;
      white-space: nowrap;
    }

    @keyframes float1 {
      0%, 100% { transform: translateY(0) rotate(-1.5deg); }
      50%       { transform: translateY(-10px) rotate(1deg); }
    }
    @keyframes float2 {
      0%, 100% { transform: translateY(0) rotate(0.8deg); }
      50%       { transform: translateY(-8px) rotate(-0.8deg); }
    }
    @keyframes float3 {
      0%, 100% { transform: translateY(0) rotate(1deg); }
      50%       { transform: translateY(-6px) rotate(-1deg); }
    }

    
    .nav-user-wrapper {
      position: relative;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .btn-user-name {
      background: linear-gradient(135deg, rgba(194,77,119,0.10), rgba(212,168,67,0.06));
      border: 1.5px solid rgba(194,77,119,0.22);
      color: var(--rose-deep);
      padding: 9px 20px 9px 14px;
      border-radius: 50px;
      font-family: var(--ff-body);
      font-weight: 600;
      font-size: 0.85rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 9px;
      transition: all 0.28s ease;
      position: relative;
    }

    .btn-user-name:hover {
      background: rgba(194,77,119,0.13);
      border-color: var(--rose);
      transform: translateY(-1px);
      box-shadow: 0 6px 20px rgba(194,77,119,0.18);
    }

    .user-avatar {
      width: 28px; height: 28px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--rose), var(--rose-deep));
      display: flex;
      align-items: center;
      justify-content: center;
      color: 
      font-size: 0.75rem;
      font-weight: 700;
      flex-shrink: 0;
    }

    .user-chevron {
      font-size: 0.6rem;
      color: var(--rose);
      transition: transform 0.25s ease;
      margin-left: 2px;
    }

    .user-dropdown-open .user-chevron { transform: rotate(180deg); }

    
    .user-dropdown {
      position: absolute;
      top: calc(100% + 10px);
      right: 0;
      min-width: 240px;
      background: rgba(255,255,255,0.98);
      backdrop-filter: blur(24px);
      border: 1px solid rgba(194,77,119,0.12);
      border-radius: 20px;
      box-shadow: 0 24px 60px rgba(140,47,81,0.18), 0 4px 16px rgba(0,0,0,0.08);
      overflow: hidden;
      opacity: 0;
      transform: translateY(-8px) scale(0.97);
      pointer-events: none;
      transition: opacity 0.22s ease, transform 0.22s cubic-bezier(0.34,1.4,0.64,1);
      z-index: 9000;
    }

    .user-dropdown.open {
      opacity: 1;
      transform: translateY(0) scale(1);
      pointer-events: all;
    }

    
    .dropdown-header {
      padding: 20px 20px 14px;
      background: linear-gradient(135deg, var(--rose), var(--rose-deep));
      position: relative;
      overflow: hidden;
    }

    .dropdown-header::before {
      content: '🌸';
      position: absolute;
      right: -8px; top: -8px;
      font-size: 4rem;
      opacity: 0.12;
      transform: rotate(15deg);
    }

    .dropdown-avatar-big {
      width: 48px; height: 48px;
      border-radius: 50%;
      background: rgba(255,255,255,0.22);
      border: 2px solid rgba(255,255,255,0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      color: 
      font-family: var(--ff-display);
      font-size: 1.25rem;
      font-weight: 600;
      margin-bottom: 10px;
    }

    .dropdown-username {
      font-family: var(--ff-display);
      font-size: 1.1rem;
      color: 
      font-weight: 600;
      margin-bottom: 2px;
    }

    .dropdown-email {
      font-size: 0.72rem;
      color: rgba(255,255,255,0.68);
      font-weight: 400;
      letter-spacing: 0.2px;
    }

    
    .dropdown-items { padding: 8px; }

    .dropdown-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 11px 14px;
      border-radius: 12px;
      text-decoration: none;
      color: var(--mid);
      font-size: 0.88rem;
      font-weight: 500;
      transition: background 0.18s, color 0.18s;
      cursor: pointer;
      border: none;
      background: none;
      width: 100%;
      text-align: left;
      font-family: var(--ff-body);
    }

    .dropdown-item:hover {
      background: rgba(194,77,119,0.07);
      color: var(--rose-deep);
    }

    .dropdown-item .di-icon {
      width: 34px; height: 34px;
      border-radius: 10px;
      background: rgba(194,77,119,0.07);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1rem;
      flex-shrink: 0;
      transition: background 0.18s;
    }

    .dropdown-item:hover .di-icon {
      background: rgba(194,77,119,0.14);
    }

    .dropdown-item .di-text { display: flex; flex-direction: column; gap: 1px; }
    .dropdown-item .di-title { font-weight: 600; color: var(--dark); font-size: 0.85rem; }
    .dropdown-item .di-sub { font-size: 0.68rem; color: var(--soft); font-weight: 400; }

    .dropdown-divider {
      height: 1px;
      background: rgba(194,77,119,0.08);
      margin: 6px 8px;
    }

    .dropdown-item.logout { color: 
    .dropdown-item.logout .di-icon { background: rgba(229,62,62,0.07); }
    .dropdown-item.logout:hover { background: rgba(229,62,62,0.06); }
    .dropdown-item.logout:hover .di-icon { background: rgba(229,62,62,0.13); }

    
    
      display: none;
      position: fixed;
      inset: 0;
      z-index: 9998;
      background: rgba(26,8,20,0.60);
      backdrop-filter: blur(8px);
      align-items: center;
      justify-content: center;
      animation: authFadeIn .22s ease;
    }

    
      background: var(--ivory);
      border-radius: 28px;
      width: min(500px, 94vw);
      max-height: 90vh;
      overflow-y: auto;
      box-shadow: 0 36px 90px rgba(140,47,81,0.26);
      animation: authSlideUp .3s cubic-bezier(0.34,1.56,0.64,1);
      position: relative;
    }

    .perfil-header {
      background: linear-gradient(135deg, var(--rose) 0%, var(--rose-deep) 100%);
      padding: 36px 32px 42px;
      position: relative;
      overflow: hidden;
    }

    .perfil-header::before {
      content: '🌸';
      position: absolute;
      right: -10px; bottom: -20px;
      font-size: 9rem;
      opacity: 0.08;
      transform: rotate(-10deg);
    }

    .perfil-close {
      position: absolute;
      top: 14px; right: 14px;
      background: rgba(255,255,255,0.18);
      border: none;
      border-radius: 50%;
      width: 34px; height: 34px;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      color: 
      font-size: 1rem;
      transition: background .18s;
    }
    .perfil-close:hover { background: rgba(255,255,255,0.30); }

    .perfil-avatar {
      width: 72px; height: 72px;
      border-radius: 50%;
      background: rgba(255,255,255,0.22);
      border: 3px solid rgba(255,255,255,0.42);
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: var(--ff-display);
      font-size: 1.9rem;
      color: 
      font-weight: 600;
      margin-bottom: 14px;
    }

    .perfil-name {
      font-family: var(--ff-display);
      font-size: 1.7rem;
      color: 
      font-weight: 600;
      margin-bottom: 4px;
    }

    .perfil-email { font-size: 0.82rem; color: rgba(255,255,255,0.65); }

    .perfil-badge-row {
      display: flex;
      gap: 8px;
      margin-top: 14px;
    }

    .perfil-badge {
      background: rgba(255,255,255,0.14);
      border: 1px solid rgba(255,255,255,0.22);
      color: rgba(255,255,255,0.88);
      padding: 5px 14px;
      border-radius: 50px;
      font-size: 0.70rem;
      font-weight: 600;
      letter-spacing: 0.5px;
    }

    .perfil-body { padding: 32px; }

    .perfil-section-title {
      font-size: 0.65rem;
      font-weight: 700;
      letter-spacing: 3px;
      text-transform: uppercase;
      color: var(--rose);
      margin-bottom: 16px;
    }

    .perfil-info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 14px;
      margin-bottom: 28px;
    }

    .perfil-info-card {
      background: var(--white);
      border: 1px solid rgba(194,77,119,0.08);
      border-radius: 16px;
      padding: 16px 18px;
      transition: box-shadow 0.2s;
    }
    .perfil-info-card:hover { box-shadow: 0 6px 20px rgba(194,77,119,0.08); }

    .pic-label {
      font-size: 0.62rem;
      font-weight: 700;
      letter-spacing: 1.8px;
      text-transform: uppercase;
      color: var(--soft);
      margin-bottom: 5px;
    }

    .pic-value {
      font-size: 0.92rem;
      font-weight: 600;
      color: var(--dark);
      font-family: var(--ff-display);
    }

    .perfil-info-card.wide {
      grid-column: span 2;
    }

    .perfil-actions {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .perfil-action-btn {
      display: flex;
      align-items: center;
      gap: 14px;
      padding: 14px 18px;
      background: var(--white);
      border: 1px solid rgba(194,77,119,0.08);
      border-radius: 16px;
      text-decoration: none;
      color: var(--mid);
      font-size: 0.88rem;
      font-weight: 500;
      font-family: var(--ff-body);
      cursor: pointer;
      transition: all 0.2s ease;
      text-align: left;
      width: 100%;
    }

    .perfil-action-btn:hover {
      background: rgba(194,77,119,0.04);
      border-color: rgba(194,77,119,0.18);
      transform: translateX(4px);
    }

    .perfil-action-icon {
      width: 38px; height: 38px;
      border-radius: 12px;
      background: rgba(194,77,119,0.07);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.05rem;
      flex-shrink: 0;
    }

    .perfil-action-text .pat-title { font-weight: 600; color: var(--dark); font-size: 0.88rem; }
    .perfil-action-text .pat-sub   { font-size: 0.70rem; color: var(--soft); }

    .perfil-logout-btn {
      width: 100%;
      margin-top: 6px;
      padding: 13px;
      background: rgba(229,62,62,0.05);
      border: 1.5px solid rgba(229,62,62,0.15);
      border-radius: 14px;
      color: 
      font-family: var(--ff-body);
      font-size: 0.88rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s, border-color 0.2s;
    }
    .perfil-logout-btn:hover { background: rgba(229,62,62,0.09); border-color: rgba(229,62,62,0.3); }

    
    .media-section {
      padding: 100px 6%;
      background: linear-gradient(160deg, var(--dark) 0%, 
      position: relative;
      overflow: hidden;
      text-align: center;
    }
    .media-section::before {
      content: '';
      position: absolute;
      inset: 0;
      background-image: radial-gradient(circle, rgba(194,77,119,0.07) 1px, transparent 1px);
      background-size: 36px 36px;
      pointer-events: none;
    }
    .media-section .section-tag {
      color: var(--rose-light);
      letter-spacing: 3.5px;
    }
    .media-section h2 { color: 
    .media-section h2 em { color: var(--rose-light); font-style: italic; font-weight: 300; }
    .media-subtitle {
      color: rgba(255,255,255,0.42);
      font-size: 0.92rem;
      font-weight: 300;
      max-width: 480px;
      margin: 0 auto 58px;
      line-height: 1.8;
    }
    .media-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 32px;
      max-width: 1020px;
      margin: 0 auto;
      align-items: start;
    }
    .media-card {
      border-radius: 26px;
      overflow: hidden;
      background: rgba(255,255,255,0.04);
      border: 1px solid rgba(194,77,119,0.16);
      box-shadow: 0 24px 70px rgba(0,0,0,0.35);
      transition: transform 0.4s ease, box-shadow 0.4s ease;
    }
    .media-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 36px 90px rgba(194,77,119,0.18);
    }
    .media-card-header {
      padding: 20px 24px 14px;
      display: flex;
      align-items: center;
      gap: 12px;
      border-bottom: 1px solid rgba(255,255,255,0.05);
    }
    .media-icon {
      width: 38px; height: 38px;
      border-radius: 11px;
      display: flex; align-items: center; justify-content: center;
      font-size: 1.1rem;
      flex-shrink: 0;
      color: 
      font-weight: 700;
    }
    .media-icon.youtube { background: linear-gradient(135deg, 
    .media-icon.tiktok  { background: 
    .media-card-title  { font-family: var(--ff-display); font-size: 0.98rem; color: rgba(255,255,255,0.9); font-weight: 600; text-align: left; }
    .media-card-platform { font-size: 0.65rem; color: rgba(255,255,255,0.32); letter-spacing: 1.5px; text-transform: uppercase; text-align: left; }
    .media-embed-wrap { padding: 16px 18px 18px; }
    .media-embed-wrap iframe { width: 100%; border-radius: 16px; display: block; }
    .media-social-links { display: flex; justify-content: center; gap: 18px; margin-top: 50px; flex-wrap: wrap; }
    .social-pill {
      display: inline-flex; align-items: center; gap: 8px;
      padding: 12px 28px; border-radius: 50px;
      font-size: 0.82rem; font-weight: 600;
      text-decoration: none; letter-spacing: 0.3px;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .social-pill.yt { background: linear-gradient(135deg, 
    .social-pill.tt { background: rgba(255,255,255,0.07); color: rgba(255,255,255,0.8); border: 1px solid rgba(255,255,255,0.14); }
    .social-pill:hover { transform: translateY(-3px); }

    
    @media (max-width: 960px) {
      .hero { grid-template-columns: 1fr; }
      .hero-right { height: 60vw; min-height: 300px; }
      .hero-left  { padding: 130px 7% 60px; text-align: center; }
      .hero-left::after { display: none; }
      .hero-left h1 { font-size: 3.6rem; }
      .hero-left .descripcion { max-width: 100%; }
      .tag-line { margin: 0 auto 28px; }
      .cta-buttons { justify-content: center; }
      .stats { justify-content: center; }
      .hero-right::before {
        background: linear-gradient(to bottom, var(--ivory) 0%, transparent 28%),
                    linear-gradient(to top, rgba(26,16,24,0.35) 0%, transparent 55%);
      }
      .hero-badge.rating { left: auto; right: 16px; top: 10%; }
      .hero-badge.order  { left: 14px; bottom: 8%; }
      .hero-badge.flowers { top: 6%; right: 12%; }
    }
    @media (max-width: 640px) {
      .hero-left h1 { font-size: 2.7rem; letter-spacing: -1.5px; }
      .media-grid { grid-template-columns: 1fr; }
      .media-section { padding: 68px 5%; }
      .media-section h2 { font-size: 2rem; }
      .stats { gap: 12px; flex-wrap: wrap; }
      .stat-item { padding-right: 16px; }
      .user-dropdown { right: auto; left: 0; }
      .perfil-info-grid { grid-template-columns: 1fr; }
      .perfil-info-card.wide { grid-column: span 1; }
    }
    </style>
</head>
<body>
    <header class="nav-bar">
        <div class="logo"><a href="index.php" style="text-decoration:none;color:inherit;">Floreria <span>alesli</span></a></div>
        <nav>
            <a href="index.php" class="active">Inicio</a>
            <a href="catalogo.php">Catálogo</a>
            <a href="personalizar.php">Personalizar</a>
            <a href="nosotros.php">Nosotros</a>
            <a href="nosotros.php#contacto">Contacto</a>
        </nav>
        <div class="action" id="nav-action">
            
            <button class="btn-login" onclick="AuthModal.open()">Entrar</button>
        </div>
    </header>
    
    <section class="hero">

      
      <div class="hero-left">
        <div class="tag-line">
          <div class="tag-line-inner">
            <span class="tag-dot"></span>
            hecho con amor desde La Paz
          </div>
        </div>

        <h1>
          <span class="word-main">Flores que</span>
          <span class="word-italic">cuentan</span>
          <span class="word-fill">tu historia</span>
        </h1>

        <p class="descripcion" id="hero-descripcion">En Florería Alesli diseñamos arreglos únicos para cada momento especial. Frescura, elegancia y entrega a domicilio el mismo día.</p>
        <script>
        (function(){
          try {
            const s = JSON.parse(localStorage.getItem('alesli_cliente'));
            if (s && s.nombre) {
              document.getElementById('hero-descripcion').innerHTML =
                'Bienvenida de nuevo, <strong>' + s.nombre + '</strong>. Diseñamos arreglos únicos para cada momento especial. Frescura, elegancia y entrega a domicilio el mismo día.';
            }
          } catch(e){}
        })();
        </script>

        <div class="cta-buttons">
          <button class="btn-primary" onclick="window.location.href='catalogo.php'">Ver Catálogo</button>
          <button class="btn-secundary" onclick="window.location.href='personalizar.php'">✦ Personalizar</button>
        </div>

        <div class="hero-separator"><span>Nuestros números</span></div>

        <div class="stats">
          <div class="stat-item">
            <span class="stat-number">1.2<sup>k</sup></span>
            <span class="stat-label">Clientes felices</span>
          </div>
          <div class="stat-item">
            <span class="stat-number">4.9<sup>★</sup></span>
            <span class="stat-label">Valoración</span>
          </div>
          <div class="stat-item">
            <span class="stat-number">24<sup>h</sup></span>
            <span class="stat-label">Entrega rápida</span>
          </div>
        </div>
      </div>

      
      <div class="hero-right">
        <img src="assets/img/imagen-ini.jpeg" alt="Arreglo floral Alesli">

        <div class="hero-badge rating">
          <div>
            <div class="rating-stars">★★★★★</div>
            <div class="rating-label">Calificación</div>
          </div>
          <div class="rating-score">4.9</div>
        </div>

        <div class="hero-badge order">
          <div class="order-label">Pedido entregado</div>
          <div class="order-name">Ramo "Eterna"</div>
          <div class="order-meta">Hace 20 minutos · La Paz</div>
        </div>

        <div class="hero-badge flowers">🌸 +200 variedades</div>
      </div>

    </section>

    
    <script src="https://cdn.jsdelivr.net/npm/tsparticles-confetti@2.12.0/tsparticles.confetti.bundle.min.js"></script>
    <script>
    window.addEventListener('scroll', () => {
        document.querySelector('.nav-bar').classList.toggle('scrolled', window.scrollY > 40);
    });
    </script>
    <script src="assets/js/efecto-petalos.js"></script>
    <script src="assets/js/cliente-auth.js"></script>

    <script src="assets/js/nav-perfil.js"></script>

    <script>
    document.addEventListener('DOMContentLoaded', async () => {
        const grid = document.querySelector('.product-grid');
        if (!grid) return;
        try {
            const productos = await fetch('../api/productos.php').then(r => r.json());
            const activos = Array.isArray(productos) ? productos.filter(p => p.estado === 'activo').slice(0, 4) : [];
            if (!activos.length) return;
            grid.innerHTML = activos.map(p => `
                <div class="product-card">
                    <div class="product-image">
                        <img src="../uploads/${p.foto||''}" alt="${p.nombre}" onerror="this.src='assets/img/flores1.jpeg'" style="width:100%;height:100%;object-fit:cover;">
                    </div>
                    <div class="product-info">
                        <h3>${p.nombre}</h3>
                        <p class="price">${parseFloat(p.precio).toFixed(2)}bs</p>
                        <p class="product-desc">${p.descripcion||''}</p>
                        <div class="product-action">
                            <button class="btn-info" onclick="verDetalle(${p.id})">Ver detalles</button>
                            <button class="btn-cart" onclick="agregarAlCarrito(${p.id})">🛒 Añadir</button>
                        </div>
                    </div>
                </div>`).join('');
        } catch {}
    });

    function verDetalle(id) { window.location.href = 'catalogo.php'; }

    async function actualizarFAB() {
        const sesion = typeof AuthModal !== 'undefined' ? AuthModal.getSession() : null;
        if (!sesion) return;
        try {
            const res = await fetch('../api/carrito.php?id_usuario=' + sesion.id);
            const items = await res.json();
            const count = Array.isArray(items) ? items.reduce((s,i) => s + i.cantidad, 0) : 0;
            const badge = document.getElementById('fab-badge');
            if (badge) { badge.textContent = count; badge.style.display = count > 0 ? 'flex' : 'none'; }
        } catch {}
    }
    document.addEventListener('DOMContentLoaded', () => setTimeout(actualizarFAB, 800));

    async function agregarAlCarrito(idProducto) {
        const sesion = AuthModal.getSession();
        if (!sesion) { AuthModal.open('login'); return; }
        try {
            const res = await fetch('../api/carrito.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id_usuario: sesion.id, id_producto: idProducto, cantidad: 1 }),
            });
            const json = await res.json();
            if (!res.ok) throw new Error(json.error || 'Error');
            const t = document.createElement('div');
            t.textContent = '🛒 Agregado al carrito';
            Object.assign(t.style, {position:'fixed',bottom:'1.5rem',right:'1.5rem',background:'#10b981',color:'#fff',padding:'.7rem 1.2rem',borderRadius:'.6rem',fontFamily:'Poppins,sans-serif',fontSize:'.88rem',zIndex:'8000',boxShadow:'0 4px 14px rgba(0,0,0,.15)'});
            document.body.appendChild(t);
            setTimeout(() => t.remove(), 3000);
        } catch(e) { alert('❌ ' + e.message); }
    }
    </script>

    <div class="sections-strip">
      <div class="strip-item">
        <span class="strip-tag">— Explora —</span>
        <div class="strip-title">Tu ramo perfecto</div>
      </div>
      <div class="strip-item">
        <span class="strip-tag">— Síguenos —</span>
        <div class="strip-title">Nuestros videos</div>
      </div>
      <div class="strip-item">
        <span class="strip-tag">— Reseñas —</span>
        <div class="strip-title">Clientes felices</div>
      </div>
    </div>

    <section class="explore">
        <span class="seccion-tag">EXPLORA</span>
        <h2>Tu ramo perfecto te espera</h2>
        <p>Elige entre nuestro catálogo o personaliza un arreglo único pensado para ti.</p>
        <div class="product-grid">
            <div class="product-card">
                <div class="product-image"><img src="assets/img/flores1.jpeg" alt=""></div>
                <div class="product-info">
                    <h3>Ramo "Amanecer"</h3>
                    <p class="price">50bs</p>
                    <p class="product-desc">Combinación de rosas rosadas y follaje silvestre</p>
                    <div class="product-action">
                        <button class="btn-info">Ver detalles</button>
                        <button class="btn-cart">🛒 Añadir</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="media-section">
      <span class="section-tag">SÍGUENOS</span>
      <h2>Flores en <em>movimiento</em></h2>
      <p class="media-subtitle">Descubre nuestra florería, nuestros diseños y cómo llegar hasta nosotros a través de nuestros videos.</p>
      <div class="media-grid">
        <div class="media-card">
          <div class="media-card-header">
            <div class="media-icon youtube">▶</div>
            <div>
              <div class="media-card-title">Florería Alesli — Tour</div>
              <div class="media-card-platform">YouTube</div>
            </div>
          </div>
          <div class="media-embed-wrap">
            <iframe src="https:
          </div>
        </div>
        <div class="media-card">
          <div class="media-card-header">
            <div class="media-icon tiktok">♪</div>
            <div>
              <div class="media-card-title">¿Cómo llegar a Alesli?</div>
              <div class="media-card-platform">TikTok · @alesli_floreria_lp</div>
            </div>
          </div>
          <div class="media-embed-wrap">
            <blockquote class="tiktok-embed" cite="https://www.tiktok.com/@alesli_floreria_lp/video/7633836103182601479" data-video-id="7633836103182601479" style="max-width:100%;min-width:unset;border-left:none;padding:0;margin:0;background:transparent;">
              <section><a target="_blank" href="https://www.tiktok.com/@alesli_floreria_lp?refer=embed">@alesli_floreria_lp</a> A veces el detalle perfecto sí existe 💖 Te mostramos cómo llegar a Aleslí 💐✨</section>
            </blockquote>
            <script async src="https://www.tiktok.com/embed.js"></script>
          </div>
        </div>
      </div>
      <div class="media-social-links">
        <a href="https://youtu.be/6Vh3_WvMHKc" target="_blank" class="social-pill yt">▶ &nbsp;Ver en YouTube</a>
        <a href="https://www.tiktok.com/@alesli_floreria_lp" target="_blank" class="social-pill tt">♪ &nbsp;Seguir en TikTok</a>
      </div>
    </section>

    
    <div class="faq">
        <span class="section-faq">AYUDA</span>
        <h2>Preguntas Frecuentes</h2>
        <div class="faq-container">
            <details class="faq-item">
                <summary>¿Hacen entregas el mismo día? <span class="icon">+</span></summary>
                <div class="faq-content"><p>Sí. Los pedidos realizados antes de las 14:00 se entregan el mismo día en toda la ciudad de La Paz.</p></div>
            </details>
            <details class="faq-item">
                <summary>¿Puedo personalizar mi ramo? <span class="icon">+</span></summary>
                <div class="faq-content"><p>¡Por supuesto! Cuéntanos los colores, tipo de flores y presupuesto. Puedes escribirnos por WhatsApp o dejar una nota en tu pedido.</p></div>
            </details>
            <details class="faq-item">
                <summary>¿Qué métodos de pago aceptan? <span class="icon">+</span></summary>
                <div class="faq-content"><p>Efectivo, QR (Tigo Money, Pago Fácil), transferencia bancaria y tarjeta de crédito/débito.</p></div>
            </details>
            <details class="faq-item">
                <summary>¿Qué pasa si las flores llegan en mal estado? <span class="icon">+</span></summary>
                <div class="faq-content"><p>Política de cambio dentro de las 12 horas. Envíanos una foto por WhatsApp y coordinamos el reemplazo sin costo.</p></div>
            </details>
            <details class="faq-item">
                <summary>¿Atienden los domingos? <span class="icon">+</span></summary>
                <div class="faq-content"><p>Sí, de 09:00 a 14:00 en tienda. Pedidos online con entrega el lunes.</p></div>
            </details>
        </div>
    </div>

    
    <section class="about">
        <span class="section-tag">SOBRE NOSOTROS</span>
        <h2>La historia de <span>Alesli</span></h2>
        <p class="about-text">Florería Alesli nació en 2015 del sueño de transformar momentos en recuerdos inolvidables a través de las flores.</p>
        <div class="features-grid">
            <div class="feature-card"><div class="icon-box">❤️</div><h3>Hecho con amor</h3><p>Cada arreglo es una pieza única y artesanal</p></div>
            <div class="feature-card"><div class="icon-box">🍃</div><h3>Flores frescas</h3><p>Cosechadas de productores locales</p></div>
            <div class="feature-card"><div class="icon-box">🚚</div><h3>Envíos coordinados</h3><p>Entrega a domicilio el mismo día en la ciudad.</p></div>
            <div class="feature-card"><div class="icon-box">🏅</div><h3>Calidad premium</h3><p>Más de 1.200 clientes satisfechos lo respaldan.</p></div>
        </div>
    </section>

    
    <section class="testimonials">
        <span class="section-tag">RESEÑAS</span>
        <h2>Lo que dicen nuestros clientes</h2>
        <div class="testimonial-grid">
            <div class="testi-card"><div class="testi-stars">★★★★★</div><p>El ramo llegó impecable y las flores duraron más de una semana. ¡El mejor regalo que he dado en años!</p><span>Andrés Flores Moya</span></div>
            <div class="testi-card"><div class="testi-stars">★★★★★</div><p>Pedí un arreglo personalizado para la boda de mi hermana y superaron todas mis expectativas.</p><span>Carla Romero</span></div>
            <div class="testi-card"><div class="testi-stars">★★★★★</div><p>Entregan rapidísimo y las flores siempre frescas. Ya les compré cuatro veces y nunca han fallado.</p><span>Roberto Quispe</span></div>
        </div>
    </section>

    
    <a href="carrito.php" class="boton-emergencia" id="fab-carrito" style="position:relative;">
      <span class="icono"><ion-icon name="cart-outline"></ion-icon></span>
      <span id="fab-badge" style="display:none;position:absolute;top:-4px;right:-4px;background:#333;color:#fff;font-size:.65rem;font-weight:700;width:20px;height:20px;border-radius:50%;align-items:center;justify-content:center;">0</span>
    </a>

    <footer class="footer">
        <div class="footer-logo">🌸 Florería Alesli</div>
        <div class="copyright">© 2026 Florería Alesli. Hecho con ✨ para ti.</div>
    </footer>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <script src="assets/js/petalos-global.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const targets = document.querySelectorAll('.product-card, .feature-card, .testi-card, .faq-item, .explore h2, .about h2, .testimonials h2, .media-card');
        targets.forEach(el => el.classList.add('fade-up'));
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); }});
        }, { threshold: 0.12 });
        document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
    });
    </script>
</body>
</html>
