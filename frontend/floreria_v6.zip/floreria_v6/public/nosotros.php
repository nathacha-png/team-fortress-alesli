<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nosotros — Florería Alesli</title>
  <link rel="stylesheet" href="assets/css/estilo.css">
  <link rel="stylesheet" href="assets/css/fonts-cliente.css">
  <link rel="stylesheet" href="assets/css/fonts-catalogo.css">
    <link rel="stylesheet" href="assets/css/nosotros.css">
</head>
<body>
  <header class="nav-bar">
    <div class="logo">Floreria <span>alesli</span></div>
    <nav>
      <a href="index.php">Inicio</a>
      <a href="catalogo.php">Catálogo</a>
            <a href="personalizar.php">Personalizar</a>
      <a href="nosotros.php" class="active">Nosotros</a>
      <a href="#contacto">Contacto</a>
    </nav>
    <div class="action">
      <button class="btn-login">Entrar</button>
    </div>
  </header>

  <main class="hero-nosotros">

    <div class="about-hero">
      <div class="hero-overlay"></div>
      <div class="about-hero-content">
        <h1>Nuestra Historia</h1>
        <p>Cultivando momentos, diseñando emociones desde 2015.</p>
      </div>
    </div>

    <section class="quienes">
      <div>
        <span class="seccion-tag">Desde el corazón</span>
        <h2>Quiénes Somos</h2>
        <p>En Florería Alesli creemos que cada flor lleva un mensaje que transmitir. Nacimos del amor por la naturaleza y el arte del diseño floral, con el sueño de transformar momentos en recuerdos inolvidables.</p>
        <p>Nuestros artesanos florales combinan técnicas tradicionales con tendencias modernas para ofrecerte piezas que no solo adornan espacios, sino que tocan corazones. Trabajamos con productores locales de La Paz para garantizar la frescura de cada arreglo.</p>
        <p>Lo que comenzó como un pequeño taller en Sopocachi hoy es la florería de confianza de más de 1.200 familias paceñas.</p>
      </div>
      <div id="contacto">
        <div class="info-card">
          <h4>📍 Ubicación y Contacto</h4>
          <div class="info-item">
            <span class="ico">🏢</span>
            <div><strong>Dirección</strong><span>Av. Las Flores #123, Sopocachi, La Paz.</span></div>
          </div>
          <div class="info-item">
            <span class="ico">📞</span>
            <div><strong>WhatsApp</strong><span>+591 70 000 000</span></div>
          </div>
          <div class="info-item">
            <span class="ico">📧</span>
            <div><strong>Correo</strong><span>info@floreria-alesli.com</span></div>
          </div>
          <div class="info-item">
            <span class="ico">🕒</span>
            <div><strong>Horario</strong><span>Lun – Sáb: 08:00 – 20:00<br>Dom: 09:00 – 14:00</span></div>
          </div>
        </div>
      </div>
    </section>

    <div class="stats-band">
      <div class="stat-item"><strong>1,200+</strong><span>Clientes felices</span></div>
      <div class="stat-item"><strong>10</strong><span>Años de experiencia</span></div>
      <div class="stat-item"><strong>98%</strong><span>Satisfacción</span></div>
      <div class="stat-item"><strong>Mismo día</strong><span>Entrega en La Paz</span></div>
    </div>

    <section class="servicios">
      <span class="seccion-tag">SERVICIOS</span>
      <h2>¿Qué ofrecemos?</h2>
      <div class="servicios-grid">
        <div class="servicio-box">
          <div class="icon-box-circle">🚚</div>
          <h3>Entregas a Domicilio</h3>
          <p>Envíos en toda La Paz. Pedidos antes de las 14:00 se entregan el mismo día con garantía de frescura total.</p>
        </div>
        <div class="servicio-box">
          <div class="icon-box-circle">✏️</div>
          <h3>Arreglos Personalizados</h3>
          <p>Diseñamos el ramo de tus sueños. Cuéntanos la ocasión, los colores y el presupuesto; nosotros hacemos el resto.</p>
        </div>
        <div class="servicio-box">
          <div class="icon-box-circle">🎉</div>
          <h3>Eventos y Bodas</h3>
          <p>Decoración floral completa para bodas, quinceañeras, cumpleaños y eventos corporativos. Presupuesto sin costo.</p>
        </div>
        <div class="servicio-box">
          <div class="icon-box-circle">🔄</div>
          <h3>Política de Devolución</h3>
          <p>Aceptamos cambios dentro de las 12 horas si hay defectos de calidad. Tu satisfacción es nuestra prioridad.</p>
        </div>
      </div>
    </section>

    <section class="equipo">
      <span class="seccion-tag">EQUIPO</span>
      <h2>Las personas detrás de cada ramo</h2>
      <div class="equipo-grid">
        <div class="equipo-card">
          <div class="avatar-circle">👩</div>
          <h4>Alesli Mamani</h4>
          <span>Fundadora &amp; Diseñadora</span>
        </div>
        <div class="equipo-card">
          <div class="avatar-circle">👩‍🌾</div>
          <h4>María Quispe</h4>
          <span>Florista Senior</span>
        </div>
        <div class="equipo-card">
          <div class="avatar-circle">👨</div>
          <h4>Carlos Flores</h4>
          <span>Repartidor</span>
        </div>
        <div class="equipo-card">
          <div class="avatar-circle">👩‍💼</div>
          <h4>Lucía Torres</h4>
          <span>Atención al cliente</span>
        </div>
      </div>
    </section>

    <section class="map-section">
      <h2>¿Dónde estamos?</h2>
      <div class="map-wrapper">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d402.08221787469876!2d-68.1223900721661!3d-16.512346366439825!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x915f21ee1f938795%3A0x71f9216e03298c64!2zQWxlc2zDrQ!5e0!3m2!1ses!2sbo!4v1778820795755!5m2!1ses!2sbo"
          width="100%" height="420" style="border:0;display:block;" allowfullscreen loading="lazy"></iframe>
      </div>
    </section>

    <section class="contacto-section">
      <span class="seccion-tag">CONTÁCTANOS</span>
      <h2>¿Listo para sorprender a alguien?</h2>
      <p style="color:#888;max-width:500px;margin:0 auto;">Escríbenos y creamos juntos el arreglo perfecto para tu ocasión especial.</p>
      <div class="contacto-grid">
        <div class="contacto-card"><div class="ico">📞</div><h4>Llámanos</h4><p>+591 70 000 000</p></div>
        <div class="contacto-card"><div class="ico">📧</div><h4>Escríbenos</h4><p>info@floreria-alesli.com</p></div>
        <div class="contacto-card"><div class="ico">📍</div><h4>Visítanos</h4><p>Av. Las Flores #123<br>Sopocachi, La Paz</p></div>
      </div>
      <a href="https://wa.me/59170000000?text=Hola%2C%20quiero%20un%20arreglo%20floral" target="_blank" class="wa-btn">
        <ion-icon name="logo-whatsapp"></ion-icon>
        Pedir por WhatsApp
      </a>
    </section>

  </main>

  <footer class="footer">
    <div class="footer-logo">🌸 Florería Alesli</div>
    <div class="copyright">© 2026 Florería Alesli. Hecho con ✨ para ti.</div>
  </footer>

  <script src="assets/js/cliente-auth.js"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="assets/js/petalos-global.js"></script>
</body>
</html>
