

const STATE = {
  clientes: [],
  filter: 'todos',
  page: 1,
  perPage: 8,
  editingId: null,
  deletingId: null,
};

const SEED = [
  {
    id: 1,
    nombre: 'Ana', apellido: 'Quispe',
    telefono: '70012345', email: 'ana.quispe@gmail.com',
    direccion: 'Av. Arce 1234, Sopocachi',
    tipo: 'vip',
    pedidos: 12, ultimoPedido: '2025-05-01',
    cumple: '1990-05-15',
    notas: 'Le encantan las rosas rojas y los arreglos grandes. Prefiere entregas en la mañana.',
    creado: '2024-01-10',
  },
  {
    id: 2,
    nombre: 'Carlos', apellido: 'Mamani',
    telefono: '71123456', email: 'c.mamani@hotmail.com',
    direccion: 'C. Sagárnaga 456, Centro',
    tipo: 'frecuente',
    pedidos: 7, ultimoPedido: '2025-04-28',
    cumple: '1985-11-20',
    notas: 'Compra flores para su esposa cada semana.',
    creado: '2024-03-05',
  },
  {
    id: 3,
    nombre: 'Lucía', apellido: 'Flores',
    telefono: '72234567', email: 'lucia.flores@yahoo.com',
    direccion: 'Av. 6 de Agosto 789, Miraflores',
    tipo: 'frecuente',
    pedidos: 5, ultimoPedido: '2025-04-20',
    cumple: '1995-08-03',
    notas: 'Prefiere girasoles y tulipanes. Alérgica a las azucenas.',
    creado: '2024-04-12',
  },
  {
    id: 4,
    nombre: 'Roberto', apellido: 'Soria',
    telefono: '73345678', email: 'roberto.soria@empresa.bo',
    direccion: 'Av. Camacho 321, Centro',
    tipo: 'nuevo',
    pedidos: 1, ultimoPedido: '2025-04-18',
    cumple: '1978-03-30',
    notas: 'Empresa. Suele comprar coronas fúnebres.',
    creado: '2025-04-18',
  },
  {
    id: 5,
    nombre: 'María', apellido: 'Condori',
    telefono: '74456789', email: 'mcondori@gmail.com',
    direccion: 'C. Murillo 321, San Pedro',
    tipo: 'frecuente',
    pedidos: 9, ultimoPedido: '2025-05-10',
    cumple: '1992-05-22',
    notas: 'Fan de los tulipanes rosados. Prefiere ramos pequeños.',
    creado: '2023-12-01',
  },
  {
    id: 6,
    nombre: 'Jorge', apellido: 'Vargas',
    telefono: '75567890', email: 'jvargas@live.com',
    direccion: 'Av. Ballivián 555, Calacoto',
    tipo: 'vip',
    pedidos: 18, ultimoPedido: '2025-05-08',
    cumple: '1980-07-14',
    notas: 'Cliente VIP. Siempre pide arreglos premium para eventos.',
    creado: '2022-06-15',
  },
  {
    id: 7,
    nombre: 'Patricia', apellido: 'Rojas',
    telefono: '76678901', email: 'projas@correo.com',
    direccion: 'C. Comercio 100, Pura Pura',
    tipo: 'inactivo',
    pedidos: 2, ultimoPedido: '2024-10-05',
    cumple: '1988-12-10',
    notas: 'Sin pedidos recientes. Contactar para reactivar.',
    creado: '2024-06-20',
  },
  {
    id: 8,
    nombre: 'Fernando', apellido: 'Choque',
    telefono: '77789012', email: 'fchoque@gmail.com',
    direccion: 'Av. Hernando Siles 200, Obrajes',
    tipo: 'nuevo',
    pedidos: 1, ultimoPedido: '2025-05-05',
    cumple: '2000-09-01',
    notas: 'Primera compra: ramo de aniversario.',
    creado: '2025-05-05',
  },
  {
    id: 9,
    nombre: 'Silvia', apellido: 'Gutiérrez',
    telefono: '78890123', email: 'silvia.g@hotmail.com',
    direccion: 'C. Potosí 80, Villa Fátima',
    tipo: 'frecuente',
    pedidos: 4, ultimoPedido: '2025-04-15',
    cumple: '1993-05-30',
    notas: 'Prefiere flores silvestres y naturales.',
    creado: '2024-08-10',
  },
  {
    id: 10,
    nombre: 'David', apellido: 'Pinto',
    telefono: '79901234', email: 'dpinto@empresa.com',
    direccion: 'Av. Montes 900, Zona Norte',
    tipo: 'vip',
    pedidos: 21, ultimoPedido: '2025-05-11',
    cumple: '1975-02-18',
    notas: 'Representante de eventos corporativos. Pedidos grandes.',
    creado: '2022-01-20',
  },
];

document.addEventListener('DOMContentLoaded', async () => {
  
  try {
    const data = await API.clientes();
    if (Array.isArray(data)) STATE.clientes = data;
    else STATE.clientes = [];
  } catch {
    STATE.clientes = []; 
  }
  updateKPIs();
  renderTable();
  renderDate();

  
  document.getElementById('menu-btn').addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('open');
    document.getElementById('sidebar-overlay').style.display = 'block';
  });
});

function loadFromStorage() {
  try {
    const raw = localStorage.getItem('alesli_clientes');
    return raw ? JSON.parse(raw) : [...SEED];
  } catch { return [...SEED]; }
}

function saveToStorage() {
  localStorage.setItem('alesli_clientes', JSON.stringify(STATE.clientes));
}

function renderDate() {
  const el = document.getElementById('live-date');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleDateString('es-BO', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });
}

function updateKPIs() {
  const mesActual = new Date().getMonth() + 1; 

  const total     = STATE.clientes.length;
  const vip       = STATE.clientes.filter(c => c.tipo === 'vip').length;
  const frecuente = STATE.clientes.filter(c => c.tipo === 'frecuente').length;
  const cumple    = STATE.clientes.filter(c => {
    if (!c.cumple) return false;
    const mes = parseInt(c.cumple.split('-')[1], 10);
    return mes === mesActual;
  }).length;

  document.getElementById('kpi-total').textContent     = total;
  document.getElementById('kpi-vip').textContent       = vip;
  document.getElementById('kpi-frecuente').textContent = frecuente;
  document.getElementById('kpi-cumple').textContent    = cumple;
}

function setFilter(filter, btn) {
  STATE.filter = filter;
  STATE.page   = 1;
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderTable();
}

function getFiltered() {
  const q = (document.getElementById('search-input')?.value || '').toLowerCase().trim();
  return STATE.clientes.filter(c => {
    const matchFilter = STATE.filter === 'todos' || c.tipo === STATE.filter;
    if (!matchFilter) return false;
    if (!q) return true;
    const hay = `${c.nombre} ${c.apellido} ${c.telefono} ${c.email} ${c.direccion}`.toLowerCase();
    return hay.includes(q);
  });
}

function renderTable() {
  const filtered = getFiltered();
  const total    = filtered.length;
  const pages    = Math.max(1, Math.ceil(total / STATE.perPage));
  if (STATE.page > pages) STATE.page = pages;

  const start = (STATE.page - 1) * STATE.perPage;
  const slice = filtered.slice(start, start + STATE.perPage);

  document.getElementById('count-label').textContent = total;

  const tbody = document.getElementById('clientes-tbody');

  if (slice.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8">
          <div class="empty-state">
            <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
            <p>No se encontraron clientes</p>
          </div>
        </td>
      </tr>`;
    renderPagination(total, pages);
    return;
  }

  tbody.innerHTML = slice.map(c => `
    <tr>
      <td>
        <div class="client-info-cell">
          <div class="client-avatar">${initials(c.nombre, c.apellido)}</div>
          <div>
            <div class="client-name">${esc(c.nombre)} ${esc(c.apellido)}</div>
            <div class="client-email">${esc(c.email || '—')}</div>
          </div>
        </div>
      </td>
      <td>${esc(c.telefono)}</td>
      <td style="max-width:180px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"
          title="${esc(c.direccion || '')}">
        ${esc(c.direccion || '—')}
      </td>
      <td><span class="badge ${c.tipo}">${capitalize(c.tipo)}</span></td>
      <td style="text-align:center; font-weight:700; color:var(--rose);">${c.pedidos}</td>
      <td>${formatDate(c.ultimoPedido)}</td>
      <td>${formatBirthday(c.cumple)}</td>
      <td>
        <div style="display:flex; gap:4px;">
          <button class="btn-icon" onclick="openPanel(${c.id})" title="Ver detalle">
            <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
          <button class="btn-icon" onclick="openModal(${c.id})" title="Editar cliente">
            <svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          <button class="btn-icon danger" onclick="askDelete(${c.id})" title="Eliminar cliente">
            <svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>
          </button>
        </div>
      </td>
    </tr>
  `).join('');

  renderPagination(total, pages);
}

function renderPagination(total, pages) {
  document.getElementById('pagination-info').textContent =
    `Página ${STATE.page} de ${pages} · ${total} registros`;

  const wrap = document.getElementById('pagination-btns');
  let html = '';

  
  html += `<button class="page-btn" onclick="goPage(${STATE.page - 1})"
    ${STATE.page <= 1 ? 'disabled' : ''}>
    <svg viewBox="0 0 24 24" width="12" height="12"><polyline points="15 18 9 12 15 6"/></svg>
  </button>`;

  for (let i = 1; i <= pages; i++) {
    if (pages > 7 && Math.abs(i - STATE.page) > 2 && i !== 1 && i !== pages) {
      if (i === 2 || i === pages - 1) html += `<span style="padding:0 4px;color:var(--text-light);">…</span>`;
      continue;
    }
    html += `<button class="page-btn ${i === STATE.page ? 'active' : ''}"
      onclick="goPage(${i})">${i}</button>`;
  }

  
  html += `<button class="page-btn" onclick="goPage(${STATE.page + 1})"
    ${STATE.page >= pages ? 'disabled' : ''}>
    <svg viewBox="0 0 24 24" width="12" height="12"><polyline points="9 18 15 12 9 6"/></svg>
  </button>`;

  wrap.innerHTML = html;
}

function goPage(p) {
  const pages = Math.max(1, Math.ceil(getFiltered().length / STATE.perPage));
  if (p < 1 || p > pages) return;
  STATE.page = p;
  renderTable();
}

function openModal(id = null) {
  STATE.editingId = id;
  const overlay = document.getElementById('modal-overlay');
  document.getElementById('modal-title').textContent = id ? 'Editar cliente' : 'Nuevo cliente';

  if (id) {
    const c = STATE.clientes.find(x => x.id === id);
    if (!c) return;
    document.getElementById('edit-id').value       = c.id;
    document.getElementById('f-nombre').value      = c.nombre;
    document.getElementById('f-apellido').value    = c.apellido;
    document.getElementById('f-telefono').value    = c.telefono;
    document.getElementById('f-email').value       = c.email || '';
    document.getElementById('f-direccion').value   = c.direccion || '';
    document.getElementById('f-tipo').value        = c.tipo;
    document.getElementById('f-cumple').value      = c.cumple || '';
    document.getElementById('f-notas').value       = c.notas || '';
  } else {
    clearForm();
  }

  overlay.classList.add('open');
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  STATE.editingId = null;
  clearForm();
}

function clearForm() {
  ['edit-id','f-nombre','f-apellido','f-telefono','f-email',
   'f-direccion','f-cumple','f-notas'].forEach(id => {
    document.getElementById(id).value = '';
  });
  document.getElementById('f-tipo').value = 'nuevo';
}

function saveCliente() {
  const nombre   = document.getElementById('f-nombre').value.trim();
  const apellido = document.getElementById('f-apellido').value.trim();
  const telefono = document.getElementById('f-telefono').value.trim();

  if (!nombre || !apellido || !telefono) {
    showToast('Por favor completa los campos obligatorios (*)','warning');
    return;
  }

  const data = {
    nombre,
    apellido,
    telefono,
    correo:    document.getElementById('f-email').value.trim(),
    direccion: document.getElementById('f-direccion').value.trim(),
    tipo:      document.getElementById('f-tipo').value,
    cumpleanos:document.getElementById('f-cumple').value,
    notas:     document.getElementById('f-notas').value.trim(),
  };

  const isEdit = !!STATE.editingId;
  const url    = '../../api/clientes.php' + (isEdit ? `?id=${STATE.editingId}` : '');
  const method = isEdit ? 'PUT' : 'POST';
  const body   = isEdit ? JSON.stringify({ id: STATE.editingId, ...data }) : JSON.stringify(data);

  fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body })
    .then(async res => {
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Error al guardar');
      
      return API.clientes();
    })
    .then(lista => {
      if (Array.isArray(lista)) STATE.clientes = lista;
      updateKPIs();
      renderTable();
      closeModal();
      showToast(`Cliente ${nombre} ${apellido} ${isEdit ? 'actualizado' : 'registrado'}`, 'success');
    })
    .catch(e => showToast('❌ ' + e.message, 'error'));
}

function askDelete(id) {
  STATE.deletingId = id;
  const c = STATE.clientes.find(x => x.id === id);
  if (!c) return;
  document.getElementById('confirm-name').textContent = `${c.nombre} ${c.apellido}`;
  document.getElementById('confirm-overlay').classList.add('open');
}

function closeConfirm() {
  document.getElementById('confirm-overlay').classList.remove('open');
  STATE.deletingId = null;
}

function confirmDelete() {
  if (!STATE.deletingId) return;
  const c = STATE.clientes.find(x => x.id === STATE.deletingId);
  const id = STATE.deletingId;

  fetch(`../../api/clientes.php?id=${id}`, { method: 'DELETE' })
    .then(async res => {
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Error al eliminar');
      STATE.clientes = STATE.clientes.filter(x => x.id !== id);
      updateKPIs();
      renderTable();
      closeConfirm();
      if (c) showToast(`Cliente ${c.nombre} eliminado`, 'error');
    })
    .catch(e => { closeConfirm(); showToast('❌ ' + e.message, 'error'); });
}

function openPanel(id) {
  const c = STATE.clientes.find(x => x.id === id);
  if (!c) return;

  const mesActual = new Date().getMonth() + 1;
  const esCumple  = c.cumple && parseInt(c.cumple.split('-')[1], 10) === mesActual;

  document.getElementById('panel-content').innerHTML = `
    
    <div style="display:flex; flex-direction:column; align-items:center; padding:20px 0 18px; border-bottom:1px solid var(--border);">
      <div style="width:72px;height:72px;border-radius:50%;
        background:linear-gradient(135deg,var(--rose-light),var(--rose));
        color:var(--rose-dark);font-size:1.4rem;font-weight:800;
        display:flex;align-items:center;justify-content:center;
        box-shadow:0 4px 18px rgba(190,58,110,0.2);">
        ${initials(c.nombre, c.apellido)}
      </div>
      <div style="margin-top:10px;font-size:1.1rem;font-weight:800;color:var(--text);">
        ${esc(c.nombre)} ${esc(c.apellido)}
      </div>
      <div style="margin-top:4px;">
        <span class="badge ${c.tipo}">${capitalize(c.tipo)}</span>
        ${esCumple ? '<span class="badge" style="background:#fce8f0;color:var(--rose);margin-left:6px;">🎂 Cumpleaños</span>' : ''}
      </div>
    </div>

    
    <div style="margin-top:14px;">
      <p style="font-size:0.72rem;font-weight:700;letter-spacing:.08em;
        text-transform:uppercase;color:var(--text-light);margin-bottom:10px;">
        Información de contacto
      </p>
      <div class="detail-row">
        <span class="detail-key">📞 Teléfono</span>
        <span class="detail-val">${esc(c.telefono)}</span>
      </div>
      <div class="detail-row">
        <span class="detail-key">✉️ Email</span>
        <span class="detail-val">${esc(c.email || '—')}</span>
      </div>
      <div class="detail-row">
        <span class="detail-key">📍 Dirección</span>
        <span class="detail-val">${esc(c.direccion || '—')}</span>
      </div>
      <div class="detail-row">
        <span class="detail-key">🎂 Cumpleaños</span>
        <span class="detail-val">${formatDate(c.cumple) || '—'}</span>
      </div>
      <div class="detail-row">
        <span class="detail-key">📅 Registrado</span>
        <span class="detail-val">${formatDate(c.creado) || '—'}</span>
      </div>
    </div>

    
    <div style="margin-top:18px;">
      <p style="font-size:0.72rem;font-weight:700;letter-spacing:.08em;
        text-transform:uppercase;color:var(--text-light);margin-bottom:10px;">
        Actividad
      </p>
      <div class="detail-row">
        <span class="detail-key">🛍️ Total pedidos</span>
        <span class="detail-val" style="color:var(--rose);font-weight:800;">${c.pedidos}</span>
      </div>
      <div class="detail-row">
        <span class="detail-key">🗓️ Último pedido</span>
        <span class="detail-val">${formatDate(c.ultimoPedido) || 'Sin pedidos'}</span>
      </div>
    </div>

    
    ${c.notas ? `
    <div style="margin-top:18px;">
      <p style="font-size:0.72rem;font-weight:700;letter-spacing:.08em;
        text-transform:uppercase;color:var(--text-light);margin-bottom:8px;">
        Notas / Preferencias
      </p>
      <div style="background:var(--rose-light);border-radius:var(--radius-sm);
        padding:12px;font-size:0.84rem;color:var(--text-mid);line-height:1.6;">
        ${esc(c.notas)}
      </div>
    </div>` : ''}

    <!-- Acciones rápidas -->
    <div style="display:flex;gap:8px;margin-top:20px;flex-wrap:wrap;">
      <button class="btn btn-primary" style="flex:1;" onclick="closePanel(); openModal(${c.id})">
        <svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        Editar
      </button>
      <button class="btn btn-secondary" style="flex:1;" onclick="callCliente('${esc(c.telefono)}')">
        <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 12 19.79 19.79 0 01.25 3.41 2 2 0 012.22 1.25h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 8.86a16 16 0 006.29 6.29l1.45-1.45a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
        Llamar
      </button>
    </div>
  `;

  document.getElementById('panel-overlay').style.display = 'block';
  document.getElementById('detail-panel').classList.add('open');
}

function closePanel() {
  document.getElementById('detail-panel').classList.remove('open');
  document.getElementById('panel-overlay').style.display = 'none';
}

function callCliente(tel) {
  if (tel) window.location.href = `tel:${tel}`;
}

function exportCSV() {
  const headers = ['ID','Nombre','Apellido','Teléfono','Email','Dirección','Tipo','Pedidos','Último pedido','Cumpleaños','Notas'];
  const rows = getFiltered().map(c => [
    c.id, c.nombre, c.apellido, c.telefono, c.email || '',
    c.direccion || '', c.tipo, c.pedidos,
    c.ultimoPedido || '', c.cumple || '', (c.notas || '').replace(/"/g, '""')
  ].map(v => `"${v}"`).join(','));

  const csv  = [headers.join(','), ...rows].join('\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), {
    href: url, download: 'clientes_alesli.csv'
  });
  a.click();
  URL.revokeObjectURL(url);
  showToast('Exportación descargada', 'success');
}

/* ══════════════════════════════════════════
   LOGOUT
   ══════════════════════════════════════════ */
function logout() {
  if (confirm('¿Deseas cerrar sesión?')) {
    window.location.href = '../../api/logout.php';
  }
}

/* ══════════════════════════════════════════
   TOAST
   ══════════════════════════════════════════ */
function showToast(msg, type = 'success') {
  const container = document.getElementById('toast-container');
  const icons = {
    success: '<svg viewBox="0 0 24 24" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg>',
    error:   '<svg viewBox="0 0 24 24" width="16" height="16"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    warning: '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
  };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = (icons[type] || '') + msg;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

/* ══════════════════════════════════════════
   UTILIDADES
   ══════════════════════════════════════════ */
function initials(nombre = '', apellido = '') {
  return `${nombre[0] || ''}${apellido[0] || ''}`.toUpperCase();
}

function capitalize(str = '') {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function esc(str = '') {
  return String(str)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

function formatDate(dateStr) {
  if (!dateStr) return null;
  try {
    const [y, m, d] = dateStr.split('-');
    return `${d}/${m}/${y}`;
  } catch { return dateStr; }
}

function formatBirthday(dateStr) {
  if (!dateStr) return '—';
  try {
    const [, m, d] = dateStr.split('-');
    const mesActual = new Date().getMonth() + 1;
    const cumpleHoy = parseInt(m, 10) === mesActual;
    return `<span style="${cumpleHoy ? 'color:var(--rose);font-weight:700;' : ''}">${d}/${m} ${cumpleHoy ? '🎂' : ''}</span>`;
  } catch { return '—'; }
}