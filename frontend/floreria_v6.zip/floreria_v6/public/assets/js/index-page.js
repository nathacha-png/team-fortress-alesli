(function(){
          try {
            const s = JSON.parse(localStorage.getItem('alesli_cliente'));
            if (s && s.nombre) {
              document.getElementById('hero-descripcion').innerHTML =
                'Bienvenida de nuevo, <strong>' + s.nombre + '</strong>. Diseñamos arreglos únicos para cada momento especial. Frescura, elegancia y entrega a domicilio el mismo día.';
            }
          } catch(e){}
        })();

window.addEventListener('scroll', () => {
        document.querySelector('.nav-bar').classList.toggle('scrolled', window.scrollY > 40);
    });

document.addEventListener('DOMContentLoaded', async () => {
        const grid = document.querySelector('.product-grid');
        if (!grid) return;
        try {
            const productos = await fetch('../api/productos.php').then(r => r.json());
            const activos = Array.isArray(productos) ? productos.filter(p => p.estado === 'activo').slice(0, 4) : [];
            if (!activos.length) return;
            grid.innerHTML = activos.map(p => `
                <div class="product-card">
                    <div class="product-image">
                        <img src="../uploads/${p.foto||''}" alt="${p.nombre}" onerror="this.src='assets/img/flores1.jpeg'" style="width:100%;height:100%;object-fit:cover;">
                    </div>
                    <div class="product-info">
                        <h3>${p.nombre}</h3>
                        <p class="price">${parseFloat(p.precio).toFixed(2)}bs</p>
                        <p class="product-desc">${p.descripcion||''}</p>
                        <div class="product-action">
                            <button class="btn-info" onclick="verDetalle(${p.id})">Ver detalles</button>
                            <button class="btn-cart" onclick="agregarAlCarrito(${p.id})">🛒 Añadir</button>
                        </div>
                    </div>
                </div>`).join('');
        } catch {}
    });

    function verDetalle(id) { window.location.href = 'catalogo.php'; }

    async function actualizarFAB() {
        const sesion = typeof AuthModal !== 'undefined' ? AuthModal.getSession() : null;
        if (!sesion) return;
        try {
            const res = await fetch('../api/carrito.php?id_usuario=' + sesion.id);
            const items = await res.json();
            const count = Array.isArray(items) ? items.reduce((s,i) => s + i.cantidad, 0) : 0;
            const badge = document.getElementById('fab-badge');
            if (badge) { badge.textContent = count; badge.style.display = count > 0 ? 'flex' : 'none'; }
        } catch {}
    }
    document.addEventListener('DOMContentLoaded', () => setTimeout(actualizarFAB, 800));

    async function agregarAlCarrito(idProducto) {
        const sesion = AuthModal.getSession();
        if (!sesion) { AuthModal.open('login'); return; }
        try {
            const res = await fetch('../api/carrito.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id_usuario: sesion.id, id_producto: idProducto, cantidad: 1 }),
            });
            const json = await res.json();
            if (!res.ok) throw new Error(json.error || 'Error');
            const t = document.createElement('div');
            t.textContent = '🛒 Agregado al carrito';
            Object.assign(t.style, {position:'fixed',bottom:'1.5rem',right:'1.5rem',background:'#10b981',color:'#fff',padding:'.7rem 1.2rem',borderRadius:'.6rem',fontFamily:'Poppins,sans-serif',fontSize:'.88rem',zIndex:'8000',boxShadow:'0 4px 14px rgba(0,0,0,.15)'});
            document.body.appendChild(t);
            setTimeout(() => t.remove(), 3000);
        } catch(e) { alert('❌ ' + e.message); }
    }

document.addEventListener('DOMContentLoaded', () => {
        const targets = document.querySelectorAll('.product-card, .feature-card, .testi-card, .faq-item, .explore h2, .about h2, .testimonials h2, .media-card');
        targets.forEach(el => el.classList.add('fade-up'));
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); }});
        }, { threshold: 0.12 });
        document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
    });
