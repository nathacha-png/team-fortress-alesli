

function updateLiveDate(elementId = 'live-date') {
  const el = document.getElementById(elementId);
  if (!el) return;
  const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  el.textContent = new Date().toLocaleDateString('es-BO', opts);
}

function showGlobalToast(msg, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = 'position:fixed;bottom:1rem;right:1rem;z-index:9999;display:flex;flex-direction:column;gap:.5rem;';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.style.cssText = `background:${type==='error'?'#ef4444':type==='warning'?'#f59e0b':'#10b981'};color:
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}

function initSidebar() {
  const btn     = document.getElementById('menu-btn');
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  if (!btn || !sidebar) return;

  btn.addEventListener('click', () => {
    const open = sidebar.classList.toggle('open');
    if (overlay) overlay.style.display = open ? 'block' : 'none';
  });
  if (overlay) {
    overlay.addEventListener('click', () => {
      sidebar.classList.remove('open');
      overlay.style.display = 'none';
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  updateLiveDate();
  setInterval(() => updateLiveDate(), 60000);
  initSidebar();
});

window.showGlobalToast = showGlobalToast;