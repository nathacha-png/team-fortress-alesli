
(function () {
  'use strict';

  
  function currentPage() {
    const p = location.pathname.split('/').pop() || 'index.php';
    return p;
  }

  
  function injectStyles() {
    if (document.getElementById('nav-perfil-styles')) return;
    const css = `
    /* ─── Nav user wrapper ─── */
    .nav-user-wrapper { position: relative; display: inline-flex; align-items: center; gap: .5rem; }

    .btn-user-name {
      display: inline-flex; align-items: center; gap: .55rem;
      background: linear-gradient(135deg, #fdf0f5, #fff);
      border: 1.5px solid rgba(194,77,119,.22);
      border-radius: 50px; padding: .45rem 1rem .45rem .5rem;
      cursor: pointer; font-family: 'Jost', sans-serif;
      font-size: .84rem; font-weight: 600; color: #8c2f51;
      transition: all .22s; white-space: nowrap;
    }
    .btn-user-name:hover {
      background: linear-gradient(135deg,#fce8f0,#fff5f9);
      border-color: #c24d77;
      box-shadow: 0 2px 12px rgba(194,77,119,.18);
    }
    .user-avatar {
      width: 30px; height: 30px; border-radius: 50%;
      background: linear-gradient(135deg,#c24d77,#8c2f51);
      color: #fff; font-size: .75rem; font-weight: 700;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0; letter-spacing: .03em;
    }
    .user-chevron {
      font-size: .6rem; opacity: .6;
      transition: transform .22s;
    }
    .nav-user-wrapper.user-dropdown-open .user-chevron { transform: rotate(180deg); }

    /* ─── Dropdown ─── */
    .user-dropdown {
      position: absolute; top: calc(100% + 10px); right: 0;
      background: #fff; border-radius: 18px;
      box-shadow: 0 20px 60px rgba(140,47,81,.18), 0 0 0 1px rgba(194,77,119,.10);
      min-width: 260px; z-index: 10000;
      opacity: 0; transform: translateY(-8px) scale(.97);
      pointer-events: none;
      transition: opacity .22s ease, transform .22s cubic-bezier(.34,1.56,.64,1);
    }
    .user-dropdown.open {
      opacity: 1; transform: translateY(0) scale(1);
      pointer-events: auto;
    }
    .dropdown-header {
      background: linear-gradient(135deg,#c24d77,#8c2f51);
      border-radius: 16px 16px 0 0; padding: 1.2rem 1.2rem 1rem;
      text-align: center;
    }
    .dropdown-avatar-big {
      width: 52px; height: 52px; border-radius: 50%;
      background: rgba(255,255,255,.22);
      border: 2px solid rgba(255,255,255,.4);
      color: #fff; font-size: 1.2rem; font-weight: 700;
      display: flex; align-items: center; justify-content: center;
      margin: 0 auto .6rem;
    }
    .dropdown-username { color: #fff; font-weight: 700; font-size: .92rem; font-family: 'Jost',sans-serif; }
    .dropdown-email { color: rgba(255,255,255,.7); font-size: .74rem; font-family: 'Jost',sans-serif; margin-top:.2rem; }
    .dropdown-items { padding: .5rem; }
    .dropdown-item {
      display: flex; align-items: center; gap: .8rem;
      padding: .65rem .8rem; border-radius: 12px;
      text-decoration: none; color: #3a1a2a;
      font-family: 'Jost',sans-serif; cursor: pointer;
      border: none; background: transparent; width: 100%;
      transition: background .18s; text-align: left;
    }
    .dropdown-item:hover { background: #fdf0f5; }
    .dropdown-item.logout:hover { background: #fff5f5; }
    .di-icon { font-size: 1.1rem; width: 28px; text-align: center; flex-shrink:0; }
    .di-text { display: flex; flex-direction: column; gap: .05rem; }
    .di-title { font-weight: 600; font-size: .84rem; color: #3a1a2a; }
    .di-sub { font-size: .70rem; color: #a07080; }
    .dropdown-divider { height: 1px; background: #fce8f0; margin: .3rem .8rem; }

    /* ─── Modal perfil ─── */
    #perfil-overlay {
      display: none; position: fixed; inset: 0; z-index: 9998;
      background: rgba(26,8,20,.55); backdrop-filter: blur(8px);
      align-items: center; justify-content: center;
      animation: pfFadeIn .22s ease;
    }
    #perfil-overlay.open { display: flex; }
    @keyframes pfFadeIn { from{opacity:0} to{opacity:1} }
    @keyframes pfSlideUp { from{transform:translateY(24px);opacity:0} to{transform:translateY(0);opacity:1} }

    #perfil-modal {
      background: #fff; border-radius: 24px; width: min(480px,94vw);
      max-height: 90vh; overflow-y: auto;
      box-shadow: 0 32px 80px rgba(140,47,81,.28);
      animation: pfSlideUp .3s cubic-bezier(.34,1.56,.64,1);
      position: relative;
    }
    .perfil-header {
      background: linear-gradient(135deg,#c24d77,#8c2f51);
      padding: 2rem 2rem 1.6rem; text-align: center; border-radius: 22px 22px 0 0;
      position: relative;
    }
    .perfil-header::after {
      content:''; position:absolute; bottom:-1px; left:0; right:0;
      height:26px; background:#fff; border-radius: 26px 26px 0 0;
    }
    .perfil-close {
      position: absolute; top: .85rem; right: 1rem;
      background: rgba(255,255,255,.18); border: none; border-radius: 50%;
      width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;
      cursor: pointer; color: #fff; font-size: 1rem; z-index: 2;
      transition: background .18s;
    }
    .perfil-close:hover { background: rgba(255,255,255,.32); }
    .perfil-avatar {
      width: 72px; height: 72px; border-radius: 50%;
      background: rgba(255,255,255,.22); border: 3px solid rgba(255,255,255,.45);
      color: #fff; font-size: 1.6rem; font-weight: 700;
      display: flex; align-items: center; justify-content: center;
      margin: 0 auto 1rem; letter-spacing: .04em;
    }
    .perfil-name {
      color: #fff; font-family:'Cormorant Garamond',Georgia,serif;
      font-size: 1.5rem; font-weight: 600;
    }
    .perfil-email { color: rgba(255,255,255,.7); font-size: .82rem; margin-top:.25rem; font-family:'Jost',sans-serif; }
    .perfil-badge-row { display: flex; gap: .5rem; justify-content: center; margin-top: .7rem; flex-wrap: wrap; }
    .perfil-badge {
      background: rgba(255,255,255,.18); border: 1px solid rgba(255,255,255,.3);
      color: #fff; font-size: .7rem; padding: .22rem .7rem; border-radius: 99px;
      font-family: 'Jost',sans-serif; font-weight: 600;
    }
    .perfil-body { padding: 28px 28px 24px; }
    .perfil-section-title {
      font-family: 'Jost',sans-serif; font-size: .7rem; font-weight: 700;
      text-transform: uppercase; letter-spacing: .12em; color: #c24d77;
      margin: 0 0 .85rem;
    }
    .perfil-info-grid {
      display: grid; grid-template-columns: 1fr 1fr; gap: .7rem; margin-bottom: 1.4rem;
    }
    .perfil-info-card {
      background: #fdf5f8; border-radius: 12px; padding: .8rem 1rem;
      border: 1px solid #f5dde8; transition: box-shadow .18s;
    }
    .perfil-info-card:hover { box-shadow: 0 4px 16px rgba(194,77,119,.1); }
    .perfil-info-card.wide { grid-column: span 2; }
    .pic-label { font-size: .68rem; font-weight: 700; color: #c4a0af; text-transform: uppercase; letter-spacing: .08em; margin-bottom: .2rem; font-family:'Jost',sans-serif; }
    .pic-value { font-size: .88rem; font-weight: 600; color: #2a1020; font-family:'Jost',sans-serif; word-break: break-all; }
    .perfil-actions { display: flex; flex-direction: column; gap: .5rem; margin-bottom: 1.2rem; }
    .perfil-action-btn {
      display: flex; align-items: center; gap: .9rem;
      padding: .8rem 1rem; border-radius: 14px;
      background: #fff; border: 1.5px solid #f0d8e4;
      text-decoration: none; color: #2a1020;
      transition: all .18s; cursor: pointer;
    }
    .perfil-action-btn:hover {
      background: #fdf0f5; border-color: #c24d77;
      box-shadow: 0 4px 14px rgba(194,77,119,.12);
      transform: translateX(2px);
    }
    .perfil-action-icon { font-size: 1.3rem; width: 36px; text-align: center; flex-shrink:0; }
    .perfil-action-text .pat-title { font-weight: 600; color: #2a1020; font-size: .88rem; font-family:'Jost',sans-serif; }
    .perfil-action-text .pat-sub   { font-size: .70rem; color: #a07080; font-family:'Jost',sans-serif; }
    .perfil-logout-btn {
      width: 100%; padding: .75rem; border-radius: 12px;
      border: 1.5px solid #fcc; background: transparent;
      color: #c0394a; font-family:'Jost',sans-serif; font-weight: 600;
      font-size: .88rem; cursor: pointer; transition: all .18s;
    }
    .perfil-logout-btn:hover { background: rgba(229,62,62,.08); border-color: rgba(229,62,62,.35); }

    @media (max-width: 500px) {
      .perfil-info-grid { grid-template-columns: 1fr; }
      .perfil-info-card.wide { grid-column: span 1; }
    }
    `;
    const s = document.createElement('style');
    s.id = 'nav-perfil-styles';
    s.textContent = css;
    document.head.appendChild(s);
  }

  
  function injectPerfilModal() {
    if (document.getElementById('perfil-overlay')) return;
    const html = `
    <div id="perfil-overlay">
      <div id="perfil-modal" role="dialog" aria-modal="true" aria-label="Mi perfil">
        <div class="perfil-header">
          <button class="perfil-close" onclick="NavPerfil.closeModal()" aria-label="Cerrar">✕</button>
          <div class="perfil-avatar" id="np-avatar">?</div>
          <div class="perfil-name" id="np-name">—</div>
          <div class="perfil-email" id="np-email">—</div>
          <div class="perfil-badge-row">
            <span class="perfil-badge">✦ Cliente Alesli</span>
            <span class="perfil-badge" id="np-since"></span>
          </div>
        </div>
        <div class="perfil-body">
          <div class="perfil-section-title">Mi información</div>
          <div class="perfil-info-grid">
            <div class="perfil-info-card">
              <div class="pic-label">Nombre</div>
              <div class="pic-value" id="np-firstname">—</div>
            </div>
            <div class="perfil-info-card">
              <div class="pic-label">Apellido</div>
              <div class="pic-value" id="np-lastname">—</div>
            </div>
            <div class="perfil-info-card wide">
              <div class="pic-label">Correo electrónico</div>
              <div class="pic-value" id="np-email2">—</div>
            </div>
            <div class="perfil-info-card wide">
              <div class="pic-label">Teléfono</div>
              <div class="pic-value" id="np-telefono">No registrado</div>
            </div>
          </div>

          <div class="perfil-section-title">Acciones rápidas</div>
          <div class="perfil-actions">
            <a href="carrito.php" class="perfil-action-btn">
              <div class="perfil-action-icon">🛒</div>
              <div class="perfil-action-text">
                <div class="pat-title">Mi carrito</div>
                <div class="pat-sub">Ver productos seleccionados</div>
              </div>
            </a>
            <a href="catalogo.php" class="perfil-action-btn">
              <div class="perfil-action-icon">🌺</div>
              <div class="perfil-action-text">
                <div class="pat-title">Ver catálogo</div>
                <div class="pat-sub">Explorar todos los arreglos</div>
              </div>
            </a>
            <a href="personalizar.php" class="perfil-action-btn">
              <div class="perfil-action-icon">✨</div>
              <div class="perfil-action-text">
                <div class="pat-title">Personalizar arreglo</div>
                <div class="pat-sub">Crea tu ramo ideal</div>
              </div>
            </a>
          </div>

          <button class="perfil-logout-btn" onclick="NavPerfil.logout()">Cerrar sesión 🚪</button>
        </div>
      </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
    document.getElementById('perfil-overlay').addEventListener('click', function(e) {
      if (e.target === this) NavPerfil.closeModal();
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') NavPerfil.closeModal(); });
  }

  
  function buildNav() {
    const s = (typeof AuthModal !== 'undefined') ? AuthModal.getSession() : null;
    
    const actionDivs = document.querySelectorAll('#nav-action, .action');
    if (!actionDivs.length) return;

    actionDivs.forEach(actionDiv => {
      
      if (actionDiv.dataset.navBuilt === '1') return;
      actionDiv.dataset.navBuilt = '1';

      if (!s) {
        actionDiv.innerHTML = '<button class="btn-login" onclick="AuthModal.open()">Entrar</button>';
        return;
      }

      const initials  = ((s.nombre||'?')[0] + (s.apellido||'')[0]).toUpperCase();
      const firstName = s.nombre || 'Mi cuenta';
      const page      = currentPage();
      const carritoLink = page === 'carrito.php' ? '#' : 'carrito.php';

      actionDiv.innerHTML = `
        <div class="nav-user-wrapper" data-nav-user>
          <button class="btn-user-name" onclick="NavPerfil.toggleDropdown(this.closest('[data-nav-user]'))">
            <div class="user-avatar">${initials}</div>
            ${firstName}
            <span class="user-chevron">▼</span>
          </button>
          <div class="user-dropdown">
            <div class="dropdown-header">
              <div class="dropdown-avatar-big">${initials}</div>
              <div class="dropdown-username">${(s.nombre||'')} ${(s.apellido||'')}</div>
              <div class="dropdown-email">${s.correo||''}</div>
            </div>
            <div class="dropdown-items">
              <button class="dropdown-item" onclick="NavPerfil.openModal(); NavPerfil.closeDropdowns();">
                <div class="di-icon">👤</div>
                <div class="di-text">
                  <span class="di-title">Mi perfil</span>
                  <span class="di-sub">Ver y editar mis datos</span>
                </div>
              </button>
              <a class="dropdown-item" href="${carritoLink}">
                <div class="di-icon">🛒</div>
                <div class="di-text">
                  <span class="di-title">Mi carrito</span>
                  <span class="di-sub">Ver mis productos</span>
                </div>
              </a>
              <a class="dropdown-item" href="catalogo.php">
                <div class="di-icon">🌺</div>
                <div class="di-text">
                  <span class="di-title">Catálogo</span>
                  <span class="di-sub">Explorar arreglos</span>
                </div>
              </a>
              <a class="dropdown-item" href="personalizar.php">
                <div class="di-icon">✨</div>
                <div class="di-text">
                  <span class="di-title">Personalizar</span>
                  <span class="di-sub">Diseña tu ramo</span>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <button class="dropdown-item logout" onclick="NavPerfil.logout()">
                <div class="di-icon">🚪</div>
                <div class="di-text">
                  <span class="di-title">Cerrar sesión</span>
                  <span class="di-sub">Hasta pronto 🌸</span>
                </div>
              </button>
            </div>
          </div>
        </div>`;
    });

    
    document.addEventListener('click', e => {
      document.querySelectorAll('[data-nav-user]').forEach(wrap => {
        if (!wrap.contains(e.target)) {
          wrap.classList.remove('user-dropdown-open');
          const dd = wrap.querySelector('.user-dropdown');
          if (dd) dd.classList.remove('open');
        }
      });
    }, true);
  }

  window.NavPerfil = {
    toggleDropdown(wrap) {
      if (!wrap) return;
      const dd = wrap.querySelector('.user-dropdown');
      if (!dd) return;
      const isOpen = dd.classList.contains('open');
      
      this.closeDropdowns();
      if (!isOpen) {
        dd.classList.add('open');
        wrap.classList.add('user-dropdown-open');
      }
    },
    closeDropdowns() {
      document.querySelectorAll('[data-nav-user]').forEach(wrap => {
        wrap.classList.remove('user-dropdown-open');
        const dd = wrap.querySelector('.user-dropdown');
        if (dd) dd.classList.remove('open');
      });
    },
    openModal() {
      const s = (typeof AuthModal !== 'undefined') ? AuthModal.getSession() : null;
      if (!s) return;
      const ov = document.getElementById('perfil-overlay');
      if (!ov) return;
      const initials = ((s.nombre||'?')[0] + (s.apellido||'')[0]).toUpperCase();
      document.getElementById('np-avatar').textContent    = initials;
      document.getElementById('np-name').textContent      = (s.nombre||'') + ' ' + (s.apellido||'');
      document.getElementById('np-email').textContent     = s.correo || '—';
      document.getElementById('np-email2').textContent    = s.correo || '—';
      document.getElementById('np-firstname').textContent = s.nombre  || '—';
      document.getElementById('np-lastname').textContent  = s.apellido || '—';
      document.getElementById('np-telefono').textContent  = s.telefono || 'No registrado';
      document.getElementById('np-since').textContent     = '📅 ' + new Date().getFullYear();
      ov.classList.add('open');
      ov.style.display = 'flex';
    },
    closeModal() {
      const ov = document.getElementById('perfil-overlay');
      if (ov) { ov.style.display = 'none'; ov.classList.remove('open'); }
    },
    logout() {
      localStorage.removeItem('alesli_cliente');
      sessionStorage.removeItem('usuario');
      location.reload();
    },
  };

  function init() {
    injectStyles();
    injectPerfilModal();
    
    setTimeout(buildNav, 50);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
