

function updateDate() {
  const el = document.getElementById('live-date');
  if (!el) return;
  const now = new Date();
  const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  el.textContent = now.toLocaleDateString('es-BO', opts);
}

function initMobileMenu() {
  const btn     = document.getElementById('menu-btn');
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebar-overlay');
  if (!btn || !sidebar) return;

  btn.addEventListener('click', () => {
    const isOpen = sidebar.classList.toggle('open');
    overlay.style.display = isOpen ? 'block' : 'none';
  });
}

function initTableSearch() {
  const input = document.getElementById('table-search');
  const table = document.getElementById('pedidos-table');
  if (!input || !table) return;

  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    table.querySelectorAll('tbody tr').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
}

function initFilterButtons() {
  const btns  = document.querySelectorAll('.filter-btn');
  const table = document.getElementById('pedidos-table');
  if (!btns.length || !table) return;

  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      
      btns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.dataset.filter;
      table.querySelectorAll('tbody tr').forEach(row => {
        if (filter === 'todos') {
          row.style.display = '';
        } else {
          const badge = row.querySelector('.badge');
          row.style.display = (badge && badge.classList.contains(filter)) ? '' : 'none';
        }
      });
    });
  });
}

const STATUS_CYCLE = ['pendiente', 'preparando', 'listo', 'entregado'];
const STATUS_LABEL = {
  pendiente:  'Pendiente',
  preparando: 'Preparando',
  listo:      'Listo',
  entregado:  'Entregado',
};

function changeStatus(btn, orderId) {
  const row   = btn.closest('tr');
  const badge = row.querySelector('.badge');
  if (!badge) return;

  
  const current = STATUS_CYCLE.find(s => badge.classList.contains(s)) || 'pendiente';
  const nextIdx = (STATUS_CYCLE.indexOf(current) + 1) % STATUS_CYCLE.length;
  const next    = STATUS_CYCLE[nextIdx];

  
  badge.classList.remove(...STATUS_CYCLE);
  badge.classList.add(next);
  badge.textContent = STATUS_LABEL[next];

  console.log(`Pedido #${orderId} → ${next}`);
}

function logout() {
  if (confirm('¿Cerrar sesión?')) {
    API.clearSession();
    API.logout();
  }
}

function initDashboard(data) {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('stat-pedidos-hoy', data.pedidos_hoy   ?? '—');
  set('stat-pendientes',  data.pendientes    ?? '—');
  set('stat-entregas',    data.entregas_hoy  ?? '—');
  set('stat-ventas',      data.ventas_hoy != null ? 'Bs. ' + Number(data.ventas_hoy).toLocaleString('es-BO', {minimumFractionDigits:2}) : '—');

  
  const tbody = document.getElementById('pedidos-tbody') || document.querySelector('#pedidos-table tbody');
  if (tbody && Array.isArray(data.pedidos_recientes)) {
    if (data.pedidos_recientes.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:24px;color:var(--text-light);">Sin pedidos hoy</td></tr>';
    } else {
      tbody.innerHTML = data.pedidos_recientes.map(p => `
        <tr data-status="${p.estado}">
          <td style="font-weight:600; color:var(--rose);">
          <td>${p.cliente}</td>
          <td>${p.producto}</td>
          <td>Bs. ${Number(p.total).toFixed(2)}</td>
          <td><span class="badge ${p.estado}">${capitalize(p.estado)}</span></td>
          <td>${p.fecha}</td>
          <td style="display:flex; gap:4px;">
            <button class="btn-icon" onclick="changeDashStatus('${p.id}')" title="Cambiar estado">
              <svg viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 014-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 01-4 4H3"/></svg>
            </button>
          </td>
        </tr>
      `).join('');
    }
  }

  
  if (Array.isArray(data.stock_flores)) {
    renderStockDashboard(data.stock_flores);
  }
}

function capitalize(s) {
  if (!s) return '';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function renderStockDashboard(items) {
  const container = document.querySelector('.stock-items-list');
  if (!container || !items.length) return;
  const maxStock = Math.max(...items.map(p => p.stock || 0), 50);
  container.innerHTML = items.slice(0, 6).map(p => {
    const pct  = Math.min(100, Math.round((p.stock / maxStock) * 100));
    const cls  = p.stock === 0 ? 'critical' : p.stock <= 10 ? 'low' : 'ok';
    const color = cls === 'critical' ? '#be3a6e' : cls === 'low' ? '#b45309' : '#1a7f5a';
    return `
      <div class="stock-item">
        <div class="stock-dot ${cls}"></div>
        <span class="stock-name">${p.nombre}</span>
        <span class="stock-qty" style="color:${color};">${p.stock} u.</span>
        <div class="stock-bar-wrap"><div class="stock-bar ${cls}" style="width:${pct}%;"></div></div>
      </div>`;
  }).join('');
}

const DASH_CYCLE = ['pendiente','preparando','listo','entregado'];
function changeDashStatus(id) {
  const row = document.querySelector(`tr[data-status]`);
  
  const rows = document.querySelectorAll('#pedidos-table tbody tr, #pedidos-tbody tr');
  for (const r of rows) {
    const idCell = r.querySelector('td:first-child');
    if (idCell && idCell.textContent.replace('#','').trim() === String(id)) {
      const badge = r.querySelector('.badge');
      if (!badge) return;
      const curr = DASH_CYCLE.find(s => badge.classList.contains(s)) || 'pendiente';
      const next = DASH_CYCLE[Math.min(DASH_CYCLE.indexOf(curr) + 1, DASH_CYCLE.length - 1)];
      if (curr === next) return;
      fetch('../../api/pedidos.php', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, estado: next })
      }).then(r => r.json()).then(data => {
        if (data.success) {
          badge.className = `badge ${next}`;
          badge.textContent = capitalize(next);
          r.dataset.status = next;
        }
      }).catch(() => {});
      break;
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  updateDate();
  initMobileMenu();
  initTableSearch();
  initFilterButtons();
});

window.changeStatus = changeStatus;
window.logout       = logout;