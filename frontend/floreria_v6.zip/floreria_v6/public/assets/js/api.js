

(function (global) {
  'use strict';

  
  const BASE = (function () {
    const path = window.location.pathname;
    
    
    const match = path.match(/^(\/.*?)\/public\
    if (match) return match[1] + '/api';
    
    const parts = path.split('/').filter(Boolean);
    if (parts.length >= 3) return '../../api';
    if (parts.length >= 2) return '../api';
    return '/api';
  })();

  
  const Loader = {
    _count: 0,
    _el: null,

    _create() {
      if (this._el) return;
      const el = document.createElement('div');
      el.id = 'api-loader';
      el.innerHTML = `
        <div class="api-loader-inner">
          <span class="api-loader-petal">🌸</span>
          <span class="api-loader-text">Cargando…</span>
        </div>`;
      el.style.cssText = `
        position:fixed; inset:0; z-index:99999;
        display:flex; align-items:center; justify-content:center;
        background:rgba(253,246,248,0.82); backdrop-filter:blur(4px);
        transition:opacity .25s;`;
      el.querySelector('.api-loader-inner').style.cssText = `
        display:flex; flex-direction:column; align-items:center; gap:.6rem;`;
      el.querySelector('.api-loader-petal').style.cssText = `
        font-size:2rem; animation:api-spin 1.2s linear infinite;`;
      el.querySelector('.api-loader-text').style.cssText = `
        font-size:.85rem; color:#be3a6e; font-weight:600; letter-spacing:.03em;`;
      
      if (!document.getElementById('api-loader-style')) {
        const s = document.createElement('style');
        s.id = 'api-loader-style';
        s.textContent = `@keyframes api-spin{to{transform:rotate(360deg)}}`;
        document.head.appendChild(s);
      }
      document.body.appendChild(el);
      this._el = el;
    },

    show() {
      this._count++;
      if (this._count === 1) {
        this._create();
        this._el.style.opacity = '1';
        this._el.style.display = 'flex';
      }
    },

    hide() {
      this._count = Math.max(0, this._count - 1);
      if (this._count === 0 && this._el) {
        this._el.style.opacity = '0';
        setTimeout(() => { if (this._el) this._el.style.display = 'none'; }, 250);
      }
    },
  };

  
  function toast(msg, type = 'error') {
    let box = document.getElementById('api-toast-box');
    if (!box) {
      box = document.createElement('div');
      box.id = 'api-toast-box';
      box.style.cssText = `position:fixed;bottom:1.25rem;right:1.25rem;z-index:99998;
        display:flex;flex-direction:column;gap:.5rem;`;
      document.body.appendChild(box);
    }
    const t = document.createElement('div');
    const bg = type === 'success' ? '#10b981' : type === 'warning' ? '#f59e0b' : '#ef4444';
    t.style.cssText = `background:${bg};color:
      font-size:.84rem;box-shadow:0 4px 14px rgba(0,0,0,.18);
      animation:api-fadein .2s ease;`;
    if (!document.getElementById('api-toast-style')) {
      const s = document.createElement('style');
      s.id = 'api-toast-style';
      s.textContent = `@keyframes api-fadein{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}`;
      document.head.appendChild(s);
    }
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(() => t.remove(), 3800);
  }

  
  async function request(path, options = {}) {
    const url = path.startsWith('http') ? path : `${BASE}/${path}`;
    Loader.show();
    try {
      const res = await fetch(url, {
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
        credentials: 'include',
        ...options,
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.mensaje || body.error || `HTTP ${res.status}`);
      }
      return await res.json();
    } catch (err) {
      throw err;
    } finally {
      Loader.hide();
    }
  }

  
  const API = {
    Loader,
    toast,

    
    get: (endpoint) => request(endpoint),

    
    post: (endpoint, body) => request(endpoint, {
      method: 'POST',
      body: JSON.stringify(body),
    }),

    

    
    dashboard: () => request('dashboard.php'),

    
    pedidos: () => request('pedidos.php'),

    
    ventas: () => request('ventas.php'),

    
    entregas: () => request('entregas.php'),

    
    clientes: () => request('clientes.php'),

    
    productos: () => request('productos.php'),

    

    
    login: (correo, contrasena) =>
      request('login.php', {
        method: 'POST',
        body: JSON.stringify({ correo, contrasena }),
      }),

    
    logout: () => {
      window.location.href = `${BASE}/logout.php`;
    },

    

    
    getUsuario() {
      try {
        return JSON.parse(sessionStorage.getItem('usuario')) || null;
      } catch {
        return null;
      }
    },

    
    setUsuario(u) {
      sessionStorage.setItem('usuario', JSON.stringify(u));
    },

    
    clearSession() {
      sessionStorage.removeItem('usuario');
      sessionStorage.removeItem('empleado_id');
    },

    
    requireAuth(redirectTo = 'login.php') {
      const u = this.getUsuario();
      if (!u) {
        window.location.replace(redirectTo);
        return null;
      }
      return u;
    },

    
    injectUserInfo() {
      const u = this.getUsuario();
      if (!u) return;
      document.querySelectorAll('[data-usuario-nombre]')
        .forEach(el => { el.textContent = `${u.nombre} ${u.apellido || ''}`.trim(); });
      document.querySelectorAll('[data-usuario-rol]')
        .forEach(el => { el.textContent = u.rol || ''; });
      document.querySelectorAll('[data-usuario-correo]')
        .forEach(el => { el.textContent = u.correo || ''; });
      
      document.querySelectorAll('[data-usuario-iniciales]').forEach(el => {
        const iniciales = [u.nombre, u.apellido]
          .filter(Boolean).map(s => s[0].toUpperCase()).join('').slice(0, 2);
        el.textContent = iniciales || '?';
      });
    },

    
    cargar(fetcher, onReady, globalKey = null) {
      const domReady = new Promise(res => {
        if (document.readyState !== 'loading') res();
        else document.addEventListener('DOMContentLoaded', res, { once: true });
      });

      Promise.all([fetcher(), domReady])
        .then(([data]) => {
          if (globalKey) window[globalKey] = data;
          onReady(data);
        })
        .catch(err => {
          console.error('[API]', err);
          toast('Error al conectar con el servidor. Verifica tu conexión.', 'error');
          if (globalKey) window[globalKey] = [];
          onReady([]);
        });
    },
  };

  
  global.API = API;

})(window);
