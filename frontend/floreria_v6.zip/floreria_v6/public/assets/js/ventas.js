
let currentPeriodo = 'hoy';
let searchTerm     = '';

function updateDate() {
  const el = document.getElementById('live-date');
  if (!el) return;
  el.textContent = new Date().toLocaleDateString('es-BO', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
  });
}

const metodoLabel = {
  efectivo:      '💵 Efectivo',
  qr:            '📱 QR',
  transferencia: '🏦 Transferencia',
  tarjeta:       '💳 Tarjeta',
};

function setFilter(btn) {
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentPeriodo = btn.dataset.periodo;
  renderVentas();
}

function filterVentas() {
  searchTerm = document.getElementById('search-input')?.value.toLowerCase() || '';
  renderVentas();
}

function getFiltered() {
  return (window.VENTAS || []).filter(v => {
    const hay = `${v.cliente} ${v.producto} ${v.id}`.toLowerCase();
    return !searchTerm || hay.includes(searchTerm);
  });
}

function renderVentas() {
  const tbody = document.getElementById('table-body');
  const info  = document.getElementById('pagination-info');
  if (!tbody) return;

  const data  = getFiltered();
  const all   = window.VENTAS || [];
  const total = data.reduce((s, v) => s + parseFloat(v.monto), 0);
  const hoy   = all.reduce((s, v) => s + parseFloat(v.monto), 0);

  document.getElementById('stat-transacciones').textContent = all.length;
  
  const elVentasHoy = document.getElementById('stat-ventas-hoy');
  if (elVentasHoy) elVentasHoy.textContent = 'Bs. ' + hoy.toLocaleString('es-BO', {minimumFractionDigits:2, maximumFractionDigits:2});
  const elTicket = document.getElementById('stat-ticket-prom');
  if (elTicket && all.length) elTicket.textContent = 'Bs. ' + (hoy / all.length).toFixed(2);

  if (info) info.textContent = `Mostrando ${data.length} de ${all.length} ventas`;

  if (data.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:32px; color:var(--text-light); font-size:.84rem;">No hay ventas que coincidan.</td></tr>`;
    return;
  }

  tbody.innerHTML = data.map((v, i) => `
    <tr>
      <td><span class="order-id">${v.id}</span></td>
      <td>
        <div class="client-cell">
          <div class="client-avatar">${initials(v.cliente)}</div>
          <div class="client-name">${v.cliente}</div>
        </div>
      </td>
      <td>${v.producto}</td>
      <td><strong>Bs. ${parseFloat(v.monto).toFixed(2)}</strong></td>
      <td><span class="metodo-cell">${metodoLabel[v.metodo] || v.metodo}</span></td>
      <td class="hora-cell">${v.hora}</td>
      <td><span class="badge listo">Completado</span></td>
      <td>
        <div class="actions-cell">
          <button class="btn-icon" title="Ver recibo" onclick="verRecibo('${v.id}')">
            <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          </button>
          <button class="btn-icon" title="Eliminar" onclick="eliminarVenta('${v.id}')">
            <svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>
          </button>
        </div>
      </td>
    </tr>
  `).join('') + `
    <tr class="total-row">
      <td colspan="3" style="text-align:right; font-size:.8rem; color:var(--text-light); font-weight:600;">TOTAL DEL PERÍODO</td>
      <td><strong style="font-size:1rem;">Bs. ${total.toLocaleString('es-BO',{minimumFractionDigits:2})}</strong></td>
      <td colspan="4"></td>
    </tr>
  `;
}

function initials(name) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function calcularVuelto() {
  const monto    = parseFloat(document.getElementById('caja-monto')?.value) || 0;
  const recibido = parseFloat(document.getElementById('caja-recibido')?.value) || 0;
  const vuelto   = recibido - monto;
  const el       = document.getElementById('vuelto-valor');
  if (el) {
    el.textContent = `Bs. ${Math.max(0, vuelto).toFixed(2)}`;
    el.style.color = vuelto < 0 ? '#ef4444' : 'var(--rose)';
  }
}

function toggleVuelto() {
  const metodo = document.getElementById('caja-metodo')?.value;
  const box    = document.getElementById('vuelto-box');
  if (!box) return;
  box.classList.toggle('visible', metodo === 'efectivo');
}

function limpiarCaja() {
  ['caja-cliente','caja-producto','caja-monto','caja-recibido','caja-notas'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.getElementById('caja-metodo').value = 'efectivo';
  toggleVuelto();
  const el = document.getElementById('vuelto-valor');
  if (el) el.textContent = 'Bs. 0.00';
}

function registrarVenta() {
  const cliente  = document.getElementById('caja-cliente')?.value.trim();
  const producto = document.getElementById('caja-producto')?.value.trim();
  const monto    = parseFloat(document.getElementById('caja-monto')?.value);
  const metodo   = document.getElementById('caja-metodo')?.value;
  const notas    = document.getElementById('caja-notas')?.value.trim();

  if (!cliente || !producto || isNaN(monto) || monto <= 0) {
    alert('Por favor completa cliente, producto y monto.');
    return;
  }

  const newId = 'V' + String(((window.VENTAS||[]).length + 1)).padStart(3, '0');
  const ahora = new Date();
  const hora  = ahora.toTimeString().slice(0, 5);

  
  const usuario = (typeof API !== 'undefined') ? API.getUsuario() : null;
  fetch('../../api/ventas.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      cliente, producto, monto, metodo,
      id_empleado: usuario?.id ?? null,
    })
  })
  .then(r => r.json())
  .then(data => {
    const idReal = data.id || newId;
    window.VENTAS.unshift({ id: idReal, cliente, producto, monto, metodo, hora, estado: 'completado' });
    limpiarCaja();
    renderVentas();
    mostrarToast(`Venta ${idReal} registrada — Bs. ${monto.toFixed(2)}`);
  })
  .catch(() => {
    
    window.VENTAS.unshift({ id: newId, cliente, producto, monto, metodo, hora, estado: 'completado' });
    limpiarCaja();
    renderVentas();
    mostrarToast(`Venta guardada localmente (sin conexión)`);
  });
}

function mostrarToast(msg) {
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg> ${msg}`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

function verRecibo(id) {
  const v = window.VENTAS.find(x => x.id === id);
  if (!v) return;
  alert(`Recibo ${v.id}\nCliente: ${v.cliente}\nProducto: ${v.producto}\nMonto: Bs. ${v.monto.toFixed(2)}\nMétodo: ${metodoLabel[v.metodo]}\nHora: ${v.hora}`);
}

function eliminarVenta(id) {
  if (!confirm('¿Eliminar esta venta del registro?')) return;
  window.VENTAS = window.VENTAS.filter(x => x.id !== id);
  renderVentas();
}

function exportarReporte() {
  const data = getFiltered();
  const filas = data.map(v =>
    [v.id, v.cliente, v.producto, v.monto, v.metodo, v.hora].join(',')
  );
  const csv  = ['ID,Cliente,Producto,Monto,Método,Hora\n', ...filas].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `ventas-floreria-alesli-${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function toggleSidebar() {
  document.querySelector('.sidebar')?.classList.toggle('open');
  const overlay = document.getElementById('sidebar-overlay');
  if (overlay) overlay.style.display = 'block';
}

function logout() {
  if (confirm('¿Cerrar sesión?')) { API.clearSession(); API.logout(); }
}

document.addEventListener('DOMContentLoaded', () => {
  updateDate();
  setInterval(updateDate, 60000);
  
  if (window.VENTAS) renderVentas();

  
  document.getElementById('caja-metodo')?.addEventListener('change', toggleVuelto);
  toggleVuelto();
});