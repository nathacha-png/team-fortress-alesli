

(function () {
  'use strict';

  const SESSION_KEY = 'alesli_cliente';

  function getSession() {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const s = JSON.parse(raw);
      if (s.expires && Date.now() > s.expires) { localStorage.removeItem(SESSION_KEY); return null; }
      return s;
    } catch { return null; }
  }

  function setSession(usuario) {
    const s = { ...usuario, expires: Date.now() + 8 * 60 * 60 * 1000 };
    localStorage.setItem(SESSION_KEY, JSON.stringify(s));
  }

  function clearSession() {
    localStorage.removeItem(SESSION_KEY);
  }

  const eyeOpen = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
  const eyeClosed = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;

  const googleIcon = `<svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>`;

  const fbIcon = `<svg width="18" height="18" viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>`;

  function passwordStrength(pass) {
    let score = 0;
    if (pass.length >= 8) score++;
    if (/[A-Z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;
    return score;
  }

  function injectStyles() {
    const css = `
    #auth-overlay {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 9999;
      background: rgba(26,8,20,0.60);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      align-items: center;
      justify-content: center;
      animation: authFadeIn .22s ease;
    }
    @keyframes authFadeIn { from { opacity:0 } to { opacity:1 } }
    @keyframes authSlideUp { from { transform:translateY(24px); opacity:0 } to { transform:translateY(0); opacity:1 } }
    @keyframes authTabIn { from { opacity:0; transform:translateX(10px) } to { opacity:1; transform:translateX(0) } }

    #auth-modal {
      background: #fff;
      border-radius: 24px;
      padding: 0;
      width: min(460px, 94vw);
      max-height: 92vh;
      overflow-y: auto;
      box-shadow: 0 32px 80px rgba(140,47,81,0.28), 0 0 0 1px rgba(194,77,119,0.10);
      position: relative;
      animation: authSlideUp .3s cubic-bezier(0.34,1.56,0.64,1);
    }

    .auth-header {
      background: linear-gradient(135deg, #c24d77 0%, #8c2f51 100%);
      padding: 2rem 2rem 1.8rem;
      text-align: center;
      position: relative;
    }
    .auth-header::after {
      content: '';
      position: absolute;
      bottom: -1px; left: 0; right: 0;
      height: 28px;
      background: #fff;
      border-radius: 28px 28px 0 0;
    }
    .auth-flower {
      font-size: 2.2rem;
      display: block;
      margin-bottom: .3rem;
    }
    .auth-header h2 {
      font-family: 'Cormorant Garamond', Georgia, serif;
      font-size: 1.7rem;
      color: #fff;
      margin: 0;
      font-weight: 600;
      letter-spacing: .02em;
    }
    .auth-header p {
      color: rgba(255,255,255,0.78);
      font-size: .82rem;
      margin: .3rem 0 0;
      font-family: 'Jost', sans-serif;
    }
    .auth-close {
      position: absolute;
      top: .9rem; right: 1rem;
      background: rgba(255,255,255,0.18);
      border: none;
      border-radius: 50%;
      width: 32px; height: 32px;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      color: #fff;
      font-size: 1rem;
      transition: background .18s;
      z-index: 2;
    }
    .auth-close:hover { background: rgba(255,255,255,0.32); }
    .auth-tabs {
      display: flex;
      margin: 1.4rem 1.8rem .8rem;
      background: #f7edf1;
      border-radius: 12px;
      padding: 4px;
      gap: 4px;
    }
    .auth-tab {
      flex: 1;
      padding: .55rem .8rem;
      border-radius: 9px;
      border: none;
      background: transparent;
      color: #a06070;
      font-family: 'Jost', sans-serif;
      font-weight: 600;
      font-size: .88rem;
      cursor: pointer;
      transition: all .22s;
    }
    .auth-tab.active {
      background: #fff;
      color: #8c2f51;
      box-shadow: 0 2px 10px rgba(140,47,81,0.13);
    }
    .auth-body { padding: 0 1.8rem 1.8rem; }
    .auth-panel { animation: authTabIn .22s ease; }
    .social-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: .6rem;
      margin-bottom: 1rem;
    }
    .btn-social {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: .5rem;
      padding: .65rem .8rem;
      border-radius: 10px;
      border: 1.5px solid #ead4dc;
      background: #fff;
      font-family: 'Jost', sans-serif;
      font-size: .82rem;
      font-weight: 600;
      color: #4a2535;
      cursor: pointer;
      transition: border-color .18s, box-shadow .18s, background .18s;
    }
    .btn-social:hover {
      border-color: #c24d77;
      box-shadow: 0 2px 10px rgba(194,77,119,0.12);
      background: #fdf5f8;
    }
    .auth-divider {
      display: flex;
      align-items: center;
      gap: .7rem;
      margin: .9rem 0;
      color: #c4a0af;
      font-size: .78rem;
      font-family: 'Jost', sans-serif;
    }
    .auth-divider::before, .auth-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: #ead4dc;
    }
    .field-group { margin-bottom: .75rem; }
    .field-label {
      display: block;
      font-family: 'Jost', sans-serif;
      font-size: .74rem;
      font-weight: 600;
      color: #8c5060;
      text-transform: uppercase;
      letter-spacing: .07em;
      margin-bottom: .32rem;
    }
    .field-input {
      width: 100%;
      padding: .75rem 1rem;
      border: 1.5px solid #ead4dc;
      border-radius: 10px;
      font-family: 'Jost', sans-serif;
      font-size: .92rem;
      color: #1a1018;
      background: #fff;
      box-sizing: border-box;
      transition: border-color .18s, box-shadow .18s;
      outline: none;
    }
    .field-input:focus {
      border-color: #c24d77;
      box-shadow: 0 0 0 3px rgba(194,77,119,0.12);
    }
    .field-input.has-eye { padding-right: 3rem; }
    .field-wrapper { position: relative; }
    .eye-toggle {
      position: absolute;
      right: .9rem;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      color: #c4a0af;
      display: flex;
      align-items: center;
      transition: color .18s;
      padding: 2px;
    }
    .eye-toggle:hover { color: #c24d77; }
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: .6rem; }
    .strength-bar { display: flex; gap: 4px; margin-top: .35rem; }
    .strength-seg {
      height: 3px; flex: 1; border-radius: 99px;
      background: #ead4dc; transition: background .3s;
    }
    .strength-label {
      font-size: .72rem; font-family: 'Jost', sans-serif;
      color: #c4a0af; margin-top: .2rem;
    }
    .auth-error {
      background: #fff1f3;
      border: 1px solid #fcc;
      border-radius: 8px;
      color: #c0394a;
      font-family: 'Jost', sans-serif;
      font-size: .82rem;
      padding: .55rem .8rem;
      margin-bottom: .75rem;
      display: none;
    }
    .btn-auth-primary {
      width: 100%;
      padding: .9rem;
      background: linear-gradient(135deg, #c24d77 0%, #9e3660 100%);
      color: #fff;
      border: none;
      border-radius: 12px;
      font-family: 'Jost', sans-serif;
      font-weight: 700;
      font-size: 1rem;
      cursor: pointer;
      margin-top: .4rem;
      transition: transform .18s, box-shadow .18s, opacity .18s;
      box-shadow: 0 4px 18px rgba(194,77,119,0.35);
      letter-spacing: .02em;
    }
    .btn-auth-primary:hover {
      transform: translateY(-1px);
      box-shadow: 0 8px 24px rgba(194,77,119,0.42);
    }
    .btn-auth-primary:active { transform: translateY(0); opacity: .9; }
    .btn-auth-primary:disabled { opacity: .65; cursor: not-allowed; transform: none; }
    .auth-footer-note {
      text-align: center;
      font-family: 'Jost', sans-serif;
      font-size: .78rem;
      color: #c4a0af;
      margin-top: .85rem;
    }
    .auth-footer-note a { color: #c24d77; text-decoration: none; font-weight: 600; }
    `;
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
  }

  function injectModal() {
    const html = `
    <div id="auth-overlay">
      <div id="auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-title">
        <div class="auth-header">
          <button class="auth-close" onclick="AuthModal.close()" aria-label="Cerrar">✕</button>
          <span class="auth-flower">🌸</span>
          <h2 id="auth-title">Florería Alesli</h2>
          <p id="auth-subtitle">Bienvenida a tu espacio floral</p>
        </div>

        <div class="auth-tabs">
          <button id="tab-login" class="auth-tab active" onclick="AuthModal.showTab('login')">Iniciar sesión</button>
          <button id="tab-register" class="auth-tab" onclick="AuthModal.showTab('register')">Crear cuenta</button>
        </div>

        <div class="auth-body">

          <!-- PANEL LOGIN -->
          <div id="panel-login" class="auth-panel">
            <div class="social-row">
              <button class="btn-social" onclick="AuthModal.socialLogin('google')">${googleIcon} Google</button>
              <button class="btn-social" onclick="AuthModal.socialLogin('facebook')">${fbIcon} Facebook</button>
            </div>
            <div class="auth-divider">o continúa con correo</div>

            <div class="field-group">
              <label class="field-label" for="login-correo">Correo electrónico</label>
              <input id="login-correo" type="email" class="field-input" placeholder="tu@correo.com" autocomplete="email">
            </div>

            <div class="field-group">
              <label class="field-label" for="login-pass">Contraseña</label>
              <div class="field-wrapper">
                <input id="login-pass" type="password" class="field-input has-eye" placeholder="••••••••" autocomplete="current-password">
                <button type="button" class="eye-toggle" id="eye-login" onclick="AuthModal.toggleEye('login-pass','eye-login')" aria-label="Mostrar contraseña">${eyeOpen}</button>
              </div>
            </div>

            <div id="login-error" class="auth-error"></div>
            <button id="btn-login" class="btn-auth-primary" onclick="AuthModal.doLogin()">Entrar 🌺</button>
            <p class="auth-footer-note">¿Olvidaste tu contraseña? <a href="#">Recuperar acceso</a></p>
          </div>

          
          <div id="panel-register" class="auth-panel" style="display:none;">
            <div class="social-row">
              <button class="btn-social" onclick="AuthModal.socialLogin('google')">${googleIcon} Google</button>
              <button class="btn-social" onclick="AuthModal.socialLogin('facebook')">${fbIcon} Facebook</button>
            </div>
            <div class="auth-divider">o regístrate con correo</div>

            <div class="field-group">
              <div class="grid-2">
                <div>
                  <label class="field-label" for="reg-nombre">Nombre *</label>
                  <input id="reg-nombre" type="text" class="field-input" placeholder="Ana" autocomplete="given-name">
                </div>
                <div>
                  <label class="field-label" for="reg-apellido">Apellido *</label>
                  <input id="reg-apellido" type="text" class="field-input" placeholder="García" autocomplete="family-name">
                </div>
              </div>
            </div>

            <div class="field-group">
              <label class="field-label" for="reg-correo">Correo electrónico *</label>
              <input id="reg-correo" type="email" class="field-input" placeholder="tu@correo.com" autocomplete="email">
            </div>

            <div class="field-group">
              <label class="field-label" for="reg-telefono">Teléfono (opcional)</label>
              <input id="reg-telefono" type="tel" class="field-input" placeholder="+591 7xxxxxxx" autocomplete="tel">
            </div>

            <div class="field-group">
              <label class="field-label" for="reg-pass">Contraseña *</label>
              <div class="field-wrapper">
                <input id="reg-pass" type="password" class="field-input has-eye" placeholder="mín. 6 caracteres" autocomplete="new-password" oninput="AuthModal.updateStrength(this.value)">
                <button type="button" class="eye-toggle" id="eye-reg" onclick="AuthModal.toggleEye('reg-pass','eye-reg')" aria-label="Mostrar contraseña">${eyeOpen}</button>
              </div>
              <div class="strength-bar">
                <div class="strength-seg" id="str-1"></div>
                <div class="strength-seg" id="str-2"></div>
                <div class="strength-seg" id="str-3"></div>
                <div class="strength-seg" id="str-4"></div>
              </div>
              <div class="strength-label" id="str-label"></div>
            </div>

            <div class="field-group">
              <label class="field-label" for="reg-confirmar">Repetir contraseña *</label>
              <div class="field-wrapper">
                <input id="reg-confirmar" type="password" class="field-input has-eye" placeholder="••••••••" autocomplete="new-password">
                <button type="button" class="eye-toggle" id="eye-confirm" onclick="AuthModal.toggleEye('reg-confirmar','eye-confirm')" aria-label="Mostrar contraseña">${eyeOpen}</button>
              </div>
            </div>

            <div id="reg-error" class="auth-error"></div>
            <button id="btn-register" class="btn-auth-primary" onclick="AuthModal.doRegister()">Crear mi cuenta 🌸</button>
            <p class="auth-footer-note">Al registrarte aceptas nuestros <a href="#">Términos de uso</a></p>
          </div>

        </div>
      </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
  }

  function updateNavButton() {
    const s = getSession();
    document.querySelectorAll('.btn-login').forEach(btn => {
      if (s) {
        btn.textContent = s.nombre;
        btn.style.cursor = 'default';
        btn.onclick = null;
        if (!document.getElementById('btn-salir')) {
          const out = document.createElement('button');
          out.id = 'btn-salir';
          out.textContent = 'Salir';
          out.style.cssText = 'background:transparent;color:#c24d77;border:1.5px solid #c24d77;padding:8px 18px;border-radius:20px;cursor:pointer;font-size:.85rem;margin-left:.5rem;font-family:Jost,sans-serif;';
          out.onclick = () => { clearSession(); location.reload(); };
          btn.insertAdjacentElement('afterend', out);
        }
      } else {
        btn.textContent = 'Entrar';
        btn.onclick = () => window.AuthModal.open();
      }
    });
  }

  function apiBase() {
    const match = location.pathname.match(/^(\/.*?)\/public\//);
    if (match) return match[1] + '/api';
    const parts = location.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) return '/' + parts[0] + '/api';
    return '/api';
  }

  window.AuthModal = {
    open(tab = 'login') {
      const ov = document.getElementById('auth-overlay');
      if (ov) { ov.style.display = 'flex'; this.showTab(tab); }
    },
    close() {
      const ov = document.getElementById('auth-overlay');
      if (ov) ov.style.display = 'none';
    },
    showTab(tab) {
      const isLogin = tab === 'login';
      document.getElementById('panel-login').style.display    = isLogin ? '' : 'none';
      document.getElementById('panel-register').style.display = isLogin ? 'none' : '';
      document.getElementById('tab-login').className    = 'auth-tab' + (isLogin ? ' active' : '');
      document.getElementById('tab-register').className = 'auth-tab' + (!isLogin ? ' active' : '');
      document.getElementById('auth-subtitle').textContent = isLogin
        ? 'Bienvenida de nuevo 🌺'
        : 'Únete a nuestra comunidad floral 🌸';
    },
    toggleEye(inputId, btnId) {
      const input = document.getElementById(inputId);
      const btn   = document.getElementById(btnId);
      if (!input || !btn) return;
      const isHidden = input.type === 'password';
      input.type = isHidden ? 'text' : 'password';
      btn.innerHTML = isHidden ? eyeClosed : eyeOpen;
      btn.style.color = isHidden ? '#c24d77' : '#c4a0af';
    },
    updateStrength(val) {
      const score = val.length === 0 ? 0 : Math.max(1, passwordStrength(val));
      const colors = ['#ead4dc','#ef4444','#f59e0b','#10b981','#059669'];
      for (let i = 1; i <= 4; i++) {
        document.getElementById('str-' + i).style.background = i <= score ? colors[score] : '#ead4dc';
      }
      const label = document.getElementById('str-label');
      const labels = ['','Muy débil','Débil','Buena','Excelente'];
      const lColors = ['','#ef4444','#f59e0b','#10b981','#059669'];
      label.textContent = val.length ? labels[score] : '';
      label.style.color = lColors[score] || '#c4a0af';
    },
    socialLogin(provider) {
      const names = { google: 'Google', facebook: 'Facebook' };
      const errEl = document.getElementById(
        document.getElementById('panel-login').style.display !== 'none' ? 'login-error' : 'reg-error'
      );
      errEl.style.cssText = 'display:block;background:#f0fdf4;border-color:#86efac;color:#166534;';
      errEl.textContent = 'ℹ️ La integración con ' + names[provider] + ' estará disponible próximamente.';
      setTimeout(() => { errEl.style.display = 'none'; errEl.style.cssText = ''; }, 3500);
    },
    async doLogin() {
      const correo     = document.getElementById('login-correo').value.trim();
      const contrasena = document.getElementById('login-pass').value;
      const errEl      = document.getElementById('login-error');
      const btn        = document.getElementById('btn-login');
      errEl.style.display = 'none';
      if (!correo || !contrasena) { errEl.textContent = '⚠️ Completa todos los campos'; errEl.style.display = ''; return; }
      btn.disabled = true; btn.textContent = 'Entrando…';
      try {
        const res  = await fetch(apiBase() + '/login.php', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ correo, contrasena }),
        });
        const json = await res.json();
        if (!json.success) throw new Error(json.mensaje || 'Error al iniciar sesión');
        setSession(json.usuario);
        sessionStorage.setItem('usuario', JSON.stringify(json.usuario));
        if (json.usuario.rol === 'admin' || json.usuario.rol === 'empleado') {
          errEl.style.cssText = 'display:block;background:#f0fdf4;border-color:#86efac;color:#166534;';
          errEl.textContent = '✅ Bienvenido ' + json.usuario.nombre + ', redirigiendo…';
          setTimeout(() => { window.location.href = json.redirect; }, 900);
          return;
        }
        this.close(); updateNavButton();
      } catch(e) { errEl.textContent = '❌ ' + e.message; errEl.style.display = ''; }
      finally { btn.disabled = false; btn.textContent = 'Entrar 🌺'; }
    },
    async doRegister() {
      const nombre     = document.getElementById('reg-nombre').value.trim();
      const apellido   = document.getElementById('reg-apellido').value.trim();
      const correo     = document.getElementById('reg-correo').value.trim();
      const telefono   = document.getElementById('reg-telefono').value.trim();
      const contrasena = document.getElementById('reg-pass').value;
      const confirmar  = document.getElementById('reg-confirmar').value;
      const errEl      = document.getElementById('reg-error');
      const btn        = document.getElementById('btn-register');
      errEl.style.display = 'none';
      if (!nombre || !apellido || !correo || !contrasena) { errEl.textContent = '⚠️ Completa los campos obligatorios (*)'; errEl.style.display = ''; return; }
      if (contrasena !== confirmar) { errEl.textContent = '❌ Las contraseñas no coinciden'; errEl.style.display = ''; return; }
      btn.disabled = true; btn.textContent = 'Creando cuenta…';
      try {
        const res  = await fetch(apiBase() + '/register.php', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ nombre, apellido, correo, telefono, contrasena, confirmar }),
        });
        const json = await res.json();
        if (!json.success) throw new Error(json.mensaje || 'Error al registrarse');
        setSession(json.usuario);
        this.close(); updateNavButton();
      } catch(e) { errEl.textContent = '❌ ' + e.message; errEl.style.display = ''; }
      finally { btn.disabled = false; btn.textContent = 'Crear mi cuenta 🌸'; }
    },
    getSession,
  };

  document.addEventListener('DOMContentLoaded', () => {
    injectStyles();
    injectModal();
    updateNavButton();
    document.getElementById('auth-overlay').addEventListener('click', function(e) {
      if (e.target === this) window.AuthModal.close();
    });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') window.AuthModal.close(); });
  });

})();
