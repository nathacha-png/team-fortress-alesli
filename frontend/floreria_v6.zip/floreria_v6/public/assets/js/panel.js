

document.getElementById('toggle').onclick = function () {
    document.getElementById('nav').classList.toggle('active');
    document.getElementById('container').classList.toggle('active');
};

function navegar(seccion) {

    
    if (seccion === 'logout') {
        if (confirm('¿Seguro que deseas cerrar sesión?')) {
            API.clearSession();
            API.logout();
        }
        return;
    }

    
    document.querySelectorAll('.vista').forEach(function (vista) {
        vista.classList.remove('activa');
    });

    
    document.getElementById('vista-' + seccion).classList.add('activa');

    
    document.querySelectorAll('.nav li[data-seccion]').forEach(function (li) {
        
        li.classList.toggle('active', li.dataset.seccion === seccion);
    });
}

document.querySelectorAll('.nav li[data-seccion]').forEach(function (li) {
    li.addEventListener('click', function (e) {
        e.preventDefault();                  
        navegar(this.dataset.seccion);       
    });
});

navegar('dashboard');

