/* ── Estado del carrito ── */
    let carritoItems = [];  // [{id_item, id_producto, nombre, precio, cantidad, foto, descripcion}]
    const ENVIO = 30;
    const API_BASE = '../api';

    /* ── Toast helper ── */
    function toastCarrito(msg, tipo='ok') {
        const box = document.getElementById('carrito-toast');
        const t   = document.createElement('div');
        t.className = 'toast-msg' + (tipo==='err'?' err':'');
        t.textContent = msg;
        box.appendChild(t);
        setTimeout(() => t.remove(), 3500);
    }

    /* ── Render items ── */
    function renderItems() {
        const container = document.getElementById('carrito-items');
        if (!carritoItems.length) {
            document.getElementById('carrito-contenido').style.display = 'none';
            document.getElementById('carrito-vacio').style.display = '';
            document.getElementById('extras-section').style.display = 'none';
            return;
        }
        document.getElementById('carrito-contenido').style.display = '';
        document.getElementById('carrito-vacio').style.display = 'none';
        document.getElementById('extras-section').style.display = '';

        container.innerHTML = carritoItems.map(item => `
            <article class="cart-item" id="item-${item.id_item}">
                <img src="${item.foto ? '../uploads/' + item.foto : 'assets/img/imagen-ini.jpeg'}" 
                     alt="${item.nombre}" onerror="this.src='assets/img/imagen-ini.jpeg'">
                <div class="item-info">
                    <div class="item-name">${item.nombre}</div>
                    <div class="item-desc">${item.descripcion || ''}</div>
                    <div class="qty-control">
                        <button onclick="cambiarCantidad(${item.id_item}, ${item.id_producto}, -1)">−</button>
                        <span id="qty-${item.id_item}">${item.cantidad}</span>
                        <button onclick="cambiarCantidad(${item.id_item}, ${item.id_producto}, 1)">+</button>
                    </div>
                </div>
                <div class="item-price">
                    <div class="price" id="price-${item.id_item}">
                        ${(item.precio * item.cantidad).toFixed(2)}bs
                    </div>
                    <button class="remove-btn" onclick="eliminarItem(${item.id_item}, ${item.id_producto})">Eliminar</button>
                </div>
            </article>
        `).join('');

        actualizarResumen();
    }

    /* ── Resumen ── */
    function actualizarResumen() {
        const subtotal = carritoItems.reduce((s, i) => s + i.precio * i.cantidad, 0);
        const total    = subtotal + ENVIO;
        const count    = carritoItems.reduce((s, i) => s + i.cantidad, 0);
        document.getElementById('resumen-items-label').textContent = `${count} artículo${count!==1?'s':''}`;
        document.getElementById('resumen-subtotal').textContent = `Bs. ${subtotal.toFixed(2)}`;
        document.getElementById('resumen-total').textContent    = `Bs. ${total.toFixed(2)}`;
    }

    /* ── Cargar carrito desde BD ── */
    async function cargarCarrito(idUsuario) {
        document.getElementById('carrito-loading').style.display = '';
        try {
            const res  = await fetch(`${API_BASE}/carrito.php?id_usuario=${idUsuario}`);
            const json = await res.json();
            carritoItems = Array.isArray(json) ? json : [];
        } catch {
            carritoItems = [];
            toastCarrito('Error al cargar el carrito', 'err');
        } finally {
            document.getElementById('carrito-loading').style.display = 'none';
        }
        renderItems();
        cargarExtras();
    }

    /* ── Cambiar cantidad ── */
    async function cambiarCantidad(idItem, idProducto, delta) {
        const item = carritoItems.find(i => i.id_item === idItem);
        if (!item) return;
        const nuevaCantidad = item.cantidad + delta;
        if (nuevaCantidad < 1) { eliminarItem(idItem, idProducto); return; }

        try {
            const _sesion = AuthModal.getSession();
            const res = await fetch(`${API_BASE}/carrito.php`, {
                method: 'PATCH',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ id_item: idItem, id_usuario: _sesion ? _sesion.id : 0, cantidad: nuevaCantidad }),
            });
            if (!res.ok) throw new Error();
            item.cantidad = nuevaCantidad;
            document.getElementById(`qty-${idItem}`).textContent = nuevaCantidad;
            document.getElementById(`price-${idItem}`).textContent = `${(item.precio * nuevaCantidad).toFixed(2)}bs`;
            actualizarResumen();
        } catch { toastCarrito('Error al actualizar cantidad', 'err'); }
    }

    /* ── Eliminar item ── */
    async function eliminarItem(idItem, idProducto) {
        const sesion = AuthModal.getSession();
        if (!sesion) return;
        try {
            const res = await fetch(`${API_BASE}/carrito.php?id_item=${idItem}&id_usuario=${sesion.id}`, {
                method: 'DELETE',
            });
            if (!res.ok) throw new Error();
            carritoItems = carritoItems.filter(i => i.id_item !== idItem);
            renderItems();
            toastCarrito('Producto eliminado del carrito');
        } catch { toastCarrito('Error al eliminar', 'err'); }
    }

    /* ── Cargar extras (productos activos para sugerir) ── */
    async function cargarExtras() {
        try {
            const productos = await fetch(`${API_BASE}/productos.php`).then(r => r.json());
            const extras = productos.filter(p => p.estado === 'activo').slice(0, 3);
            document.getElementById('extras-grid').innerHTML = extras.map(p => `
                <div class="extra-card">
                    <img src="${p.foto ? '../uploads/' + p.foto : 'assets/img/imagen-ini.jpeg'}"
                         alt="${p.nombre}" onerror="this.src='assets/img/imagen-ini.jpeg'">
                    <div class="extra-info">
                        <div class="extra-name">${p.nombre}</div>
                        <div class="extra-price">${parseFloat(p.precio).toFixed(2)}bs</div>
                    </div>
                    <button class="add-extra" onclick="agregarExtra(${p.id})">+</button>
                </div>
            `).join('');
        } catch { /* silencioso */ }
    }

    /* ── Agregar extra al carrito ── */
    async function agregarExtra(idProducto) {
        const sesion = AuthModal.getSession();
        if (!sesion) { AuthModal.open('login'); return; }
        try {
            const res = await fetch(`${API_BASE}/carrito.php`, {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ id_usuario: sesion.id, id_producto: idProducto, cantidad: 1 }),
            });
            const json = await res.json();
            if (!res.ok) throw new Error(json.error || 'Error');
            toastCarrito('Producto agregado 🌸');
            await cargarCarrito(sesion.id);
        } catch(e) { toastCarrito(e.message, 'err'); }
    }

    /* ── Promo code (placeholder) ── */
    function aplicarPromo() {
        const code = document.getElementById('promo-code').value.trim().toUpperCase();
        if (!code) return;
        toastCarrito('Código no válido', 'err');
    }

    /* ── Finalizar compra ── */
    function finalizarCompra() {
        if (!carritoItems.length) { toastCarrito('Tu carrito está vacío', 'err'); return; }
        toastCarrito('Redirigiendo a pago… (próximamente) 🛍️');
    }

    /* ── Iniciar ── */
    document.addEventListener('DOMContentLoaded', () => {
        const sesion = AuthModal.getSession();
        if (!sesion) {
            document.getElementById('login-gate').style.display = '';
        } else {
            // Personalizar saludo
            const subtitle = document.getElementById('carrito-subtitle');
            if (subtitle) subtitle.textContent = `Hola ${sesion.nombre}, aquí están tus productos 🌸`;
            cargarCarrito(sesion.id);
        }
    });
