

const STORAGE_KEY = 'alesli_empleado_config';

const DEFAULTS = {
  nombre:          'María',
  apellido:        'Antonieta',
  apodo:           'María',
  nacimiento:      '',
  bio:             '',
  email:           '',
  email2:          '',
  telefono:        '',
  telEmergencia:   '',
  relEmergencia:   '',
  calle:           '',
  barrio:          '',
  ciudad:          'La Paz',
  horaEntrada:     '08:00',
  horaSalida:      '17:00',
  diasTrabajo:     ['lun','mar','mie','jue','vie'],
  idioma:          'es',
  timezone:        'America/La_Paz',
  fechaFmt:        'dd/mm/yyyy',
  moneda:          'BOB',
  notifPedidos:    true,
  notifEntregas:   true,
  notifStock:      false,
  notifMensajes:   true,
  sidebarCompact:  false,
  reduceMotion:    false,
  largeText:       false,
  density:         'cómoda',
  theme:           'default',
  avatarUrl:       '',
  
  cargo:           'Empleado',
  area:            'Atención al cliente',
  ingreso:         '2024-01-15',
  idEmpleado:      '#EMP-001',
};

function loadConfig() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULTS, ...JSON.parse(raw) } : { ...DEFAULTS };
  } catch { return { ...DEFAULTS }; }
}

function saveToStorage(cfg) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
}

function updateDate() {
  const el = document.getElementById('live-date');
  if (!el) return;
  const now  = new Date();
  const opts = { weekday:'long', year:'numeric', month:'long', day:'numeric' };
  el.textContent = now.toLocaleDateString('es-BO', opts);
}

function toggleSidebar() {
  document.querySelector('.sidebar')?.classList.toggle('open');
  const overlay = document.getElementById('sidebar-overlay');
  if (overlay) overlay.style.display = overlay.style.display === 'none' ? 'block' : 'none';
}
function closeSidebar() {
  document.querySelector('.sidebar')?.classList.remove('open');
  const overlay = document.getElementById('sidebar-overlay');
  if (overlay) overlay.style.display = 'none';
}
function handleResponsive() {
  const btn = document.getElementById('menu-btn');
  if (!btn) return;
  btn.style.display = window.innerWidth <= 768 ? 'block' : 'none';
}

function populateForm(cfg) {
  
  setVal('cfg-nombre',    cfg.nombre);
  setVal('cfg-apellido',  cfg.apellido);
  setVal('cfg-apodo',     cfg.apodo);
  setVal('cfg-nacimiento',cfg.nacimiento);
  setVal('cfg-bio',       cfg.bio);
  
  setVal('cfg-email',            cfg.email);
  setVal('cfg-email2',           cfg.email2);
  setVal('cfg-telefono',         cfg.telefono);
  setVal('cfg-tel-emergencia',   cfg.telEmergencia);
  setVal('cfg-rel-emergencia',   cfg.relEmergencia);
  setVal('cfg-calle',            cfg.calle);
  setVal('cfg-barrio',           cfg.barrio);
  setVal('cfg-ciudad',           cfg.ciudad);
  
  setVal('cfg-hora-entrada', cfg.horaEntrada);
  setVal('cfg-hora-salida',  cfg.horaSalida);
  setVal('cfg-idioma',       cfg.idioma);
  setVal('cfg-timezone',     cfg.timezone);
  setVal('cfg-fecha-fmt',    cfg.fechaFmt);
  setVal('cfg-moneda',       cfg.moneda);
  setCheck('notif-pedidos',         cfg.notifPedidos);
  setCheck('notif-entregas',        cfg.notifEntregas);
  setCheck('notif-stock',           cfg.notifStock);
  setCheck('notif-mensajes',        cfg.notifMensajes);
  
  document.querySelectorAll('.cfg-day').forEach(btn => {
    btn.classList.toggle('active', cfg.diasTrabajo.includes(btn.dataset.day));
  });
  
  setCheck('pref-sidebar-compact', cfg.sidebarCompact);
  setCheck('pref-reduce-motion',   cfg.reduceMotion);
  setCheck('pref-large-text',      cfg.largeText);
  setVal('cfg-density', cfg.density);
  
  document.querySelectorAll('.cfg-theme-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === cfg.theme);
  });
  
  setText('ro-cargo',   cfg.cargo);
  setText('ro-area',    cfg.area);
  setText('ro-ingreso', formatDate(cfg.ingreso));
  setText('ro-id',      cfg.idEmpleado);
}

function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val ?? '';
}
function setCheck(id, val) {
  const el = document.getElementById(id);
  if (el) el.checked = !!val;
}
function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val ?? '—';
}
function formatDate(str) {
  if (!str) return '—';
  const [y,m,d] = str.split('-');
  return `${d}/${m}/${y}`;
}

function updateHero(cfg) {
  const fullName  = [cfg.nombre, cfg.apellido].filter(Boolean).join(' ') || '—';
  const initials  = [cfg.nombre?.[0], cfg.apellido?.[0]].filter(Boolean).join('').toUpperCase() || '?';
  const display   = cfg.apodo || cfg.nombre || '—';

  setText('cfg-hero-name',  fullName);
  setText('cfg-hero-role',  `${cfg.cargo} · Florería Alesli`);

  const phoneEl = document.getElementById('cfg-hero-phone');
  if (phoneEl) phoneEl.innerHTML = `<svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.07 1.18a2 2 0 012-2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 6.27a16 16 0 006.29 6.29l.44-.44a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>${cfg.telefono || '—'}`;

  const emailEl = document.getElementById('cfg-hero-email');
  if (emailEl) emailEl.innerHTML = `<svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>${cfg.email || '—'}`;

  
  const avatarEl = document.getElementById('cfg-avatar-display');
  if (avatarEl) {
    if (cfg.avatarUrl) {
      avatarEl.style.backgroundImage = `url(${cfg.avatarUrl})`;
      avatarEl.style.backgroundSize  = 'cover';
      avatarEl.style.backgroundPosition = 'center';
      avatarEl.textContent = '';
    } else {
      avatarEl.style.backgroundImage = '';
      avatarEl.textContent = initials;
    }
  }

  
  syncSidebarUser(cfg, initials, display);
}

function syncSidebarUser(cfg, initials, display) {
  const avatarEl = document.getElementById('user-avatar');
  const nameEl   = document.getElementById('user-name');
  const roleEl   = document.getElementById('user-role');

  if (avatarEl) {
    if (cfg.avatarUrl) {
      avatarEl.style.backgroundImage = `url(${cfg.avatarUrl})`;
      avatarEl.style.backgroundSize  = 'cover';
      avatarEl.style.backgroundPosition = 'center';
      avatarEl.textContent = '';
    } else {
      avatarEl.style.backgroundImage = '';
      avatarEl.textContent = initials;
    }
  }
  if (nameEl) nameEl.textContent = display;
  if (roleEl) roleEl.textContent = cfg.cargo;
}

function collectForm(existing) {
  const cfg = { ...existing };
  cfg.nombre        = getVal('cfg-nombre');
  cfg.apellido      = getVal('cfg-apellido');
  cfg.apodo         = getVal('cfg-apodo');
  cfg.nacimiento    = getVal('cfg-nacimiento');
  cfg.bio           = getVal('cfg-bio');
  cfg.email         = getVal('cfg-email');
  cfg.email2        = getVal('cfg-email2');
  cfg.telefono      = getVal('cfg-telefono');
  cfg.telEmergencia = getVal('cfg-tel-emergencia');
  cfg.relEmergencia = getVal('cfg-rel-emergencia');
  cfg.calle         = getVal('cfg-calle');
  cfg.barrio        = getVal('cfg-barrio');
  cfg.ciudad        = getVal('cfg-ciudad');
  cfg.horaEntrada   = getVal('cfg-hora-entrada');
  cfg.horaSalida    = getVal('cfg-hora-salida');
  cfg.idioma        = getVal('cfg-idioma');
  cfg.timezone      = getVal('cfg-timezone');
  cfg.fechaFmt      = getVal('cfg-fecha-fmt');
  cfg.moneda        = getVal('cfg-moneda');
  cfg.notifPedidos  = getCheck('notif-pedidos');
  cfg.notifEntregas = getCheck('notif-entregas');
  cfg.notifStock    = getCheck('notif-stock');
  cfg.notifMensajes = getCheck('notif-mensajes');
  cfg.sidebarCompact= getCheck('pref-sidebar-compact');
  cfg.reduceMotion  = getCheck('pref-reduce-motion');
  cfg.largeText     = getCheck('pref-large-text');
  cfg.density       = getVal('cfg-density');
  
  cfg.diasTrabajo = Array.from(document.querySelectorAll('.cfg-day.active')).map(b => b.dataset.day);
  
  const themeBtn = document.querySelector('.cfg-theme-btn.active');
  cfg.theme = themeBtn ? themeBtn.dataset.theme : 'default';
  return cfg;
}

function getVal(id)   { return document.getElementById(id)?.value?.trim() ?? ''; }
function getCheck(id) { return document.getElementById(id)?.checked ?? false; }

function saveConfig() {
  const existing = loadConfig();
  const cfg = collectForm(existing);
  saveToStorage(cfg);
  updateHero(cfg);
  applyTheme(cfg.theme);
  showToast('✅ Configuración guardada correctamente');
}

function resetChanges() {
  const cfg = loadConfig();
  populateForm(cfg);
  updateHero(cfg);
  showToast('↩️ Cambios descartados');
}

function handleAvatarUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const cfg = loadConfig();
    cfg.avatarUrl = e.target.result;
    saveToStorage(cfg);
    updateHero(cfg);
    showToast('📷 Foto de perfil actualizada');
  };
  reader.readAsDataURL(file);
}

function switchTab(btn) {
  document.querySelectorAll('.cfg-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.cfg-tab-panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  const panel = document.getElementById('panel-' + btn.dataset.tab);
  if (panel) panel.classList.add('active');
}

document.addEventListener('click', e => {
  if (e.target.matches('.cfg-day')) {
    e.target.classList.toggle('active');
  }
});

const THEMES = {
  default:  { '--accent':'#c45e7e', '--accent-dark':'#a8436a', '--accent-light':'#fdeef3' },
  lavender: { '--accent':'#9b7fd4', '--accent-dark':'#7c5ab8', '--accent-light':'#f3eeff' },
  sage:     { '--accent':'#6aaa6a', '--accent-dark':'#4d8c4d', '--accent-light':'#edf7ed' },
  peach:    { '--accent':'#e8835c', '--accent-dark':'#cc6040', '--accent-light':'#fff0ea' },
  sky:      { '--accent':'#4da6d6', '--accent-dark':'#2a7fb8', '--accent-light':'#e8f4fb' },
  dark:     { '--accent':'#9b7fd4', '--accent-dark':'#7c5ab8', '--accent-light':'#2a2a3a' },
};

function applyTheme(name) {
  const theme = THEMES[name] || THEMES.default;
  const root  = document.documentElement;
  Object.entries(theme).forEach(([k, v]) => root.style.setProperty(k, v));
  
  document.body.classList.toggle('theme-dark', name === 'dark');
}

function setTheme(btn) {
  document.querySelectorAll('.cfg-theme-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  applyTheme(btn.dataset.theme);
}

function showToast(msg) {
  const toast = document.getElementById('cfg-toast');
  const msgEl = document.getElementById('cfg-toast-msg');
  if (!toast) return;
  if (msgEl) msgEl.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

document.addEventListener('DOMContentLoaded', () => {
  updateDate();
  setInterval(updateDate, 60000);
  handleResponsive();
  window.addEventListener('resize', handleResponsive);

  const cfg = loadConfig();
  populateForm(cfg);
  updateHero(cfg);
  applyTheme(cfg.theme);
});