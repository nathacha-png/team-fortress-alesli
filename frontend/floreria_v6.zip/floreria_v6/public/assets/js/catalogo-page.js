(function(){
      try {
        const s = JSON.parse(localStorage.getItem('alesli_cliente'));
        if (s && s.nombre) {
          document.getElementById('catalogo-saludo').textContent =
            'Hola ' + s.nombre + ', encuentra tu arreglo ideal. Entrega el mismo día en La Paz. 🌺';
        }
      } catch(e){}
    })();

/* ── Estado ── */
  let todosLosProductos = [];
  let categoriaActiva   = 'todos';
  let productoDetalle   = null;
  let qtyDetalle        = 1;

  /* ── Toast ── */
  function toast(msg, tipo='ok') {
    const box = document.getElementById('cat-toast');
    const t   = document.createElement('div');
    t.className = 'cat-toast-msg' + (tipo==='err' ? ' err' : '');
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(() => t.remove(), 3400);
  }

  /* ── Cargar productos ── */
  async function cargarCatalogo() {
    try {
      const res = await fetch('../api/productos.php');
      todosLosProductos = await res.json();
      if (!Array.isArray(todosLosProductos)) todosLosProductos = [];
      construirFiltros();
      renderProductos();
      actualizarFAB();
    } catch {
      document.getElementById('catalogo-grid').innerHTML =
        '<div class="catalogo-empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 9v3m0 3h.01M10.29 3.86 1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></svg><p>No se pudo cargar el catálogo.<br><small>Verifica la conexión con el servidor.</small></p></div>';
    }
  }

  /* ── Construir botones de categoría ── */
  function construirFiltros() {
    const cats = [...new Set(todosLosProductos.map(p => p.categoria).filter(Boolean))].sort();
    const box  = document.getElementById('filtros');
    cats.forEach(cat => {
      const btn = document.createElement('button');
      btn.className   = 'filtro-btn';
      btn.dataset.cat = cat;
      btn.textContent = cat;
      btn.onclick     = () => setCategoria(cat, btn);
      box.appendChild(btn);
    });
  }

  function setCategoria(cat, btn) {
    categoriaActiva = cat;
    document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('activo'));
    btn.classList.add('activo');
    renderProductos();
  }

  /* ── Filtrar por búsqueda ── */
  function filtrarProductos() { renderProductos(); }

  /* ── Render ── */
  function renderProductos() {
    const q    = (document.getElementById('busqueda').value || '').toLowerCase();
    const grid = document.getElementById('catalogo-grid');

    let lista = todosLosProductos.filter(p => p.estado === 'activo' || p.estado === 'agotado');
    if (categoriaActiva !== 'todos') lista = lista.filter(p => p.categoria === categoriaActiva);
    if (q) lista = lista.filter(p =>
      (p.nombre + ' ' + p.descripcion + ' ' + p.categoria).toLowerCase().includes(q)
    );

    if (!lista.length) {
      grid.innerHTML = '<div class="catalogo-empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><p>Sin resultados para esa búsqueda.</p></div>';
      return;
    }

    grid.innerHTML = lista.map(p => {
      const agotado  = p.estado === 'agotado' || p.stock === 0;
      const stockTxt = agotado ? '' : p.stock <= 5
        ? `<span class="stock-badge low">⚠ Solo ${p.stock} disponibles</span><br>`
        : `<span class="stock-badge">✓ En stock</span><br>`;
      const foto = p.foto ? `../uploads/${p.foto}` : 'assets/img/flores1.jpeg';
      return `
        <div class="product-card" id="pc-${p.id}">
          ${agotado ? '<span class="badge-agotado">Agotado</span>' : ''}
          <div class="product-image" style="cursor:pointer" onclick="abrirDetalle(${p.id})">
            <img src="${foto}" alt="${p.nombre}" onerror="this.src='assets/img/flores1.jpeg'" style="width:100%;height:100%;object-fit:cover;">
          </div>
          <div class="product-info">
            <h3>${p.nombre}</h3>
            <p class="price">${parseFloat(p.precio).toFixed(2)} Bs.</p>
            ${stockTxt}
            <p class="product-desc">${(p.descripcion || '').substring(0, 80)}${(p.descripcion||'').length>80?'…':''}</p>
            <div class="product-action">
              <button class="btn-info" onclick="abrirDetalle(${p.id})">Ver detalles</button>
              <button class="btn-cart" onclick="agregarAlCarrito(${p.id})" ${agotado?'disabled style="opacity:.5;cursor:not-allowed"':''}>🛒 Añadir</button>
            </div>
          </div>
        </div>`;
    }).join('');
  }

  /* ── Detalle ── */
  function abrirDetalle(id) {
    productoDetalle = todosLosProductos.find(p => p.id === id);
    if (!productoDetalle) return;
    qtyDetalle = 1;
    const p    = productoDetalle;
    const foto = p.foto ? `../uploads/${p.foto}` : 'assets/img/flores1.jpeg';
    const agotado = p.estado === 'agotado' || p.stock === 0;

    document.getElementById('det-img').src      = foto;
    document.getElementById('det-img').onerror  = function(){ this.src='assets/img/flores1.jpeg'; };
    document.getElementById('det-cat').textContent    = p.categoria || 'Producto';
    document.getElementById('det-nombre').textContent = p.nombre;
    document.getElementById('det-precio').textContent = parseFloat(p.precio).toFixed(2) + ' Bs.';
    document.getElementById('det-desc').textContent   = p.descripcion || 'Sin descripción.';
    document.getElementById('det-qty').textContent    = 1;

    const stockEl = document.getElementById('det-stock');
    if (agotado) {
      stockEl.textContent = '✗ Producto agotado';
      stockEl.className   = 'detalle-stock low';
    } else if (p.stock <= 5) {
      stockEl.textContent = `⚠ Solo ${p.stock} unidades disponibles`;
      stockEl.className   = 'detalle-stock low';
    } else {
      stockEl.textContent = `✓ ${p.stock} unidades disponibles`;
      stockEl.className   = 'detalle-stock';
    }

    const addBtn = document.getElementById('det-add');
    addBtn.disabled  = agotado;
    addBtn.textContent = agotado ? 'Sin stock' : '🛒 Añadir al carrito';

    document.getElementById('detalle-overlay').classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function cerrarDetalle() {
    document.getElementById('detalle-overlay').classList.remove('open');
    document.body.style.overflow = '';
  }

  function cambiarQty(delta) {
    if (!productoDetalle) return;
    const max = productoDetalle.stock || 99;
    qtyDetalle = Math.max(1, Math.min(max, qtyDetalle + delta));
    document.getElementById('det-qty').textContent = qtyDetalle;
  }

  async function agregarDesdeDetalle() {
    if (!productoDetalle) return;
    await agregarAlCarrito(productoDetalle.id, qtyDetalle);
    cerrarDetalle();
  }

  /* ── Agregar al carrito ── */
  async function agregarAlCarrito(idProducto, cantidad = 1) {
    const sesion = AuthModal.getSession();
    if (!sesion) { AuthModal.open('login'); return; }
    try {
      const res = await fetch('../api/carrito.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id_usuario: sesion.id, id_producto: idProducto, cantidad }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Error');
      toast('🛒 Agregado al carrito');
      actualizarFAB();
    } catch(e) {
      toast(e.message, 'err');
    }
  }

  /* ── FAB: mostrar cantidad en carrito ── */
  async function actualizarFAB() {
    const sesion = AuthModal.getSession();
    if (!sesion) return;
    try {
      const res   = await fetch(`../api/carrito.php?id_usuario=${sesion.id}`);
      const items = await res.json();
      const count = Array.isArray(items) ? items.reduce((s, i) => s + i.cantidad, 0) : 0;
      const badge = document.getElementById('fab-badge');
      badge.textContent = count;
      badge.classList.toggle('visible', count > 0);
    } catch { /* silencioso */ }
  }

  /* ── Init ── */
  cargarCatalogo();
