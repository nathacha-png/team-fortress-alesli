(function(){
              try {
                const s = JSON.parse(localStorage.getItem('alesli_cliente'));
                if (s && s.nombre) {
                  document.getElementById('personalizar-saludo').textContent =
                    s.nombre + ', sube una foto de tu inspiración y te ayudamos a crear el arreglo ideal. ✨';
                }
              } catch(e){}
            })();

/* ─────────────────────────────────────────────────────
       personalizar.js — integrado y mejorado
       ───────────────────────────────────────────────────── */

    // Referencias DOM
    const mediaContainer = document.getElementById('media-container');
    const btnStart       = document.getElementById('btn-start-camera');
    const btnSnap        = document.getElementById('btn-snap');
    const fileInput      = document.getElementById('file-input');
    const placeholder    = document.getElementById('placeholder');
    const resultadoVacio = document.getElementById('resultado-vacio');
    const resultadoActiv = document.getElementById('resultado-activo');

    let stream      = null;
    let videoEl     = null;
    let imagenB64   = null;

    // ── Cámara ───────────────────────────────────────────
    btnStart.addEventListener('click', async () => {
        try {
            limpiarMedia();
            stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: 'environment' }, audio: false
            });

            videoEl = document.createElement('video');
            videoEl.srcObject = stream;
            videoEl.autoplay  = true;
            videoEl.playsInline = true;
            mediaContainer.appendChild(videoEl);
            mediaContainer.classList.add('grabando');

            btnStart.style.display = 'none';
            btnSnap.style.display  = 'flex';
        } catch (err) {
            showToast('⚠️ No se pudo acceder a la cámara');
        }
    });

    btnSnap.addEventListener('click', () => {
        if (!videoEl) return;
        const canvas = document.createElement('canvas');
        canvas.width  = videoEl.videoWidth;
        canvas.height = videoEl.videoHeight;
        canvas.getContext('2d').drawImage(videoEl, 0, 0);
        imagenB64 = canvas.toDataURL('image/jpeg');
        mostrarImagen(imagenB64);
        detenerCamara();
    });

    // ── Subir archivo ────────────────────────────────────
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (stream) detenerCamara();

        const reader = new FileReader();
        reader.onload = ev => {
            imagenB64 = ev.target.result;
            mostrarImagen(imagenB64);
        };
        reader.readAsDataURL(file);
    });

    // ── Helpers de cámara ────────────────────────────────
    function detenerCamara() {
        if (stream) stream.getTracks().forEach(t => t.stop());
        mediaContainer.classList.remove('grabando');
        btnSnap.style.display  = 'none';
        btnStart.style.display = 'flex';
        stream = null; videoEl = null;
    }

    function limpiarMedia() {
        mediaContainer.innerHTML = '';
        const dot = document.createElement('div');
        dot.className = 'rec-dot';
        mediaContainer.appendChild(dot);
    }

    // ── Mostrar imagen + analizar ────────────────────────
    function mostrarImagen(src) {
        limpiarMedia();
        const img = document.createElement('img');
        img.src = src;
        img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
        mediaContainer.appendChild(img);
        analizarImagen(src);
    }

    // ── Análisis de colores ──────────────────────────────
    function analizarImagen(src) {
        resultadoVacio.style.display = 'none';

        // Extraer paleta con canvas
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const tam = 80;
            canvas.width = canvas.height = tam;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, tam, tam);
            const data = ctx.getImageData(0, 0, tam, tam).data;

            // Muestrear colores cada 8 píxeles
            const mapa = {};
            for (let i = 0; i < data.length; i += 4 * 8) {
                const r = Math.round(data[i]   / 32) * 32;
                const g = Math.round(data[i+1] / 32) * 32;
                const b = Math.round(data[i+2] / 32) * 32;
                if (data[i+3] < 10) continue; // skip transparent
                const key = `${r},${g},${b}`;
                mapa[key] = (mapa[key] || 0) + 1;
            }

            // Top 6 colores
            const top6 = Object.entries(mapa)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 6)
                .map(([k]) => {
                    const [r,g,b] = k.split(',').map(Number);
                    return rgbToHex(r, g, b);
                });

            mostrarResultado(top6);
        };
        img.src = src;
    }

    function rgbToHex(r, g, b) {
        return '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('');
    }

    // ── Catálogo de sugerencias por tono ─────────────────
    const catalogoSugerencias = [
        { emoji: '🌹', nombre: 'Ramo Pasión',      desc: 'Rosas rojas y terciopelo',     tonos: ['rojo','rosa','fucsia'] },
        { emoji: '🌸', nombre: 'Ramo Primavera',   desc: 'Flores rosadas y follaje',     tonos: ['rosa','lila','blanco'] },
        { emoji: '🌺', nombre: 'Ramo Tropical',    desc: 'Hibiscos y heliconias',         tonos: ['naranja','amarillo','rojo'] },
        { emoji: '💐', nombre: 'Ramo Romantico',   desc: 'Mix de rosas y lilas',          tonos: ['rosa','morado','lila'] },
        { emoji: '🌼', nombre: 'Ramo Soleado',     desc: 'Girasoles y margaritas',        tonos: ['amarillo','naranja','blanco'] },
        { emoji: '🌷', nombre: 'Ramo Elegante',    desc: 'Tulipanes y eucalipto',         tonos: ['morado','violeta','blanco'] },
        { emoji: '🤍', nombre: 'Ramo Minimalista', desc: 'Flores blancas y verde',        tonos: ['blanco','gris','verde'] },
        { emoji: '🌿', nombre: 'Ramo Natural',     desc: 'Follaje silvestre y flores',    tonos: ['verde','marrón','blanco'] },
    ];

    function hexToTono(hex) {
        const r = parseInt(hex.slice(1,3),16);
        const g = parseInt(hex.slice(3,5),16);
        const b = parseInt(hex.slice(5,7),16);
        const max = Math.max(r,g,b), min = Math.min(r,g,b);
        const lum = (max+min)/2;
        if (lum > 220 && max-min < 30) return 'blanco';
        if (lum < 50)  return 'negro';
        if (max-min < 25) return 'gris';
        if (r > g+40 && r > b+40) return b > 100 ? 'fucsia' : 'rojo';
        if (r > 180 && g > 100 && b < 80) return 'naranja';
        if (r > 180 && g > 180 && b < 100) return 'amarillo';
        if (g > r+30 && g > b) return 'verde';
        if (b > r+30 && b > g+30) return 'azul';
        if (r > 150 && b > 150 && g < 120) return 'morado';
        if (b > 120 && r > 120 && g < 100) return 'lila';
        if (r > 160 && b > 100 && g < 120) return 'rosa';
        return 'otro';
    }

    function mostrarResultado(colores) {
        // Paleta
        const pEl = document.getElementById('paleta-colores');
        pEl.innerHTML = '';
        colores.forEach((hex, i) => {
            const chip = document.createElement('div');
            chip.className = 'color-chip';
            chip.style.background = hex;
            chip.title = hex;
            chip.onclick = () => chip.classList.toggle('seleccionado');
            pEl.appendChild(chip);
        });

        // Detectar tonos dominantes
        const tonos = colores.map(hexToTono);
        
        // Sugerir por coincidencia de tonos
        const scored = catalogoSugerencias.map(s => ({
            ...s,
            score: s.tonos.filter(t => tonos.includes(t)).length
        })).sort((a,b) => b.score - a.score).slice(0, 4);

        // Si ninguna coincide bien, mostrar las primeras 4 por defecto
        const sugs = scored.some(s => s.score > 0) ? scored : catalogoSugerencias.slice(0, 4);

        const sgEl = document.getElementById('sugerencias-grid');
        sgEl.innerHTML = '';
        sugs.forEach((s, i) => {
            const div = document.createElement('div');
            div.className = 'sugerencia-item' + (i === 0 ? ' activa' : '');
            div.innerHTML = `
                <span class="sug-emoji">${s.emoji}</span>
                <div class="sug-info">
                    <div class="sug-nombre">${s.nombre}</div>
                    <div class="sug-desc">${s.desc}</div>
                </div>
            `;
            div.onclick = () => {
                document.querySelectorAll('.sugerencia-item').forEach(el => el.classList.remove('activa'));
                div.classList.add('activa');
            };
            sgEl.appendChild(div);
        });

        // Mostrar panel
        resultadoActiv.style.display = 'flex';
        showToast('✨ Sugerencias listas para ti');
    }

    // ── Enviar pedido por WhatsApp ────────────────────────
    function enviarPedido() {
        const activa = document.querySelector('.sugerencia-item.activa .sug-nombre');
        const nota   = document.getElementById('nota-pedido').value.trim();
        const nombre = activa ? activa.textContent : 'arreglo personalizado';

        let msg = `🌸 *Hola Florería Alesli!*\n\nMe gustaría solicitar un *${nombre}*`;
        if (nota) msg += `\n\n📝 *Nota:* ${nota}`;
        msg += '\n\n¿Me pueden dar más información? ¡Gracias! 💐';

        const tel = '59170000000'; // reemplazar con número real
        const url = `https://wa.me/${tel}?text=${encodeURIComponent(msg)}`;
        window.open(url, '_blank');
    }

    // ── Toast ─────────────────────────────────────────────
    function showToast(msg) {
        const t = document.getElementById('toast');
        t.textContent = msg;
        t.classList.add('show');
        setTimeout(() => t.classList.remove('show'), 3000);
    }

    // ── Navbar scroll ─────────────────────────────────────
    window.addEventListener('scroll', () => {
        document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 40);
    });

/* ─── Datos de configuración ─── */
    const RAMOS = [
        { id:'primavera', emoji:'🌸', nombre:'Ramo Primavera',  desc:'Rosas, tulipanes y follaje',  base:60, floraForma:'rose',      env:'round'   },
        { id:'tropical',  emoji:'🌺', nombre:'Ramo Tropical',   desc:'Hibiscos y heliconias',         base:75, floraForma:'tropical',  env:'cascade' },
        { id:'romantico', emoji:'💐', nombre:'Ramo Romántico',  desc:'Mix de rosas y lilas',          base:70, floraForma:'mixed',     env:'heart'   },
        { id:'soleado',   emoji:'🌻', nombre:'Ramo Soleado',    desc:'Girasoles y margaritas',        base:55, floraForma:'daisy',     env:'round'   },
        { id:'elegante',  emoji:'🌷', nombre:'Ramo Elegante',   desc:'Tulipanes y eucalipto',         base:85, floraForma:'tulip',     env:'tall'    },
        { id:'silvestre', emoji:'🌿', nombre:'Ramo Silvestre',  desc:'Follaje y flores silvestres',   base:50, floraForma:'wild',      env:'natural' },
    ];

    const COLORES = [
        { id:'rosa',      nombre:'Rosa',      hex:'#e8729a', hex2:'#f7a8c3', hoja:'#6aad6a' },
        { id:'rojo',      nombre:'Rojo',      hex:'#d43f3f', hex2:'#e87272', hoja:'#4a8c4a' },
        { id:'lila',      nombre:'Lila',      hex:'#a46fc7', hex2:'#c9a3e0', hoja:'#7aad7a' },
        { id:'amarillo',  nombre:'Amarillo',  hex:'#e8c135', hex2:'#f7de7a', hoja:'#5a9a5a' },
        { id:'naranja',   nombre:'Naranja',   hex:'#e8823a', hex2:'#f5b57a', hoja:'#5a9a5a' },
        { id:'blanco',    nombre:'Blanco',    hex:'#f5f0f0', hex2:'#ffffff', hoja:'#7aad7a' },
        { id:'fucsia',    nombre:'Fucsia',    hex:'#d6367d', hex2:'#f070ae', hoja:'#5a9a5a' },
        { id:'azul',      nombre:'Azul',      hex:'#5b8de8', hex2:'#92b8f5', hoja:'#4a7a9a' },
    ];

    const ESTILOS = [
        { id:'clasico',   label:'🎀 Clásico',     mult:1.0  },
        { id:'moderno',   label:'✦ Moderno',      mult:1.1  },
        { id:'rustico',   label:'🌿 Rústico',     mult:0.95 },
        { id:'lujo',      label:'👑 Lujo',         mult:1.4  },
        { id:'mini',      label:'🌱 Mini',         mult:0.7  },
        { id:'gigante',   label:'🎊 Gigante',      mult:1.6  },
    ];

    /* ─── Estado ─── */
    let estado = {
        ramo:     RAMOS[0],
        color:    COLORES[0],
        estilo:   ESTILOS[0],
        cantidad: 12,
    };

    /* ─── Precio ─── */
    function calcularPrecio() {
        return Math.round(estado.ramo.base * estado.estilo.mult + estado.cantidad * 1.5);
    }

    /* ─── Render controles ─── */
    function initControles() {
        // Ramos
        const sr = document.getElementById('ramos-selector');
        sr.innerHTML = '';
        RAMOS.forEach(r => {
            const btn = document.createElement('button');
            btn.className = 'ramo-btn' + (r.id === estado.ramo.id ? ' activo' : '');
            btn.innerHTML = `
                <span class="ramo-emoji">${r.emoji}</span>
                <div class="ramo-info">
                    <div class="ramo-nombre">${r.nombre}</div>
                    <div class="ramo-desc">${r.desc}</div>
                </div>
                <span class="ramo-precio">Bs.${r.base}+</span>
            `;
            btn.onclick = () => { estado.ramo = r; actualizarTodo(); };
            sr.appendChild(btn);
        });

        // Colores
        const cg = document.getElementById('colores-grid');
        cg.innerHTML = '';
        COLORES.forEach(c => {
            const wrap = document.createElement('div');
            wrap.className = 'color-opcion' + (c.id === estado.color.id ? ' activo' : '');
            wrap.innerHTML = `
                <div class="color-circulo" style="background:linear-gradient(135deg,${c.hex},${c.hex2});"></div>
                <span class="color-nombre">${c.nombre}</span>
            `;
            wrap.onclick = () => { estado.color = c; actualizarTodo(); };
            cg.appendChild(wrap);
        });

        // Estilos
        const eg = document.getElementById('estilos-grid');
        eg.innerHTML = '';
        ESTILOS.forEach(e => {
            const btn = document.createElement('button');
            btn.className = 'estilo-btn' + (e.id === estado.estilo.id ? ' activo' : '');
            btn.textContent = e.label;
            btn.onclick = () => { estado.estilo = e; actualizarTodo(); };
            eg.appendChild(btn);
        });

        // Cantidad
        document.getElementById('cant-menos').onclick = () => {
            if (estado.cantidad > 3) { estado.cantidad -= 3; actualizarTodo(); }
        };
        document.getElementById('cant-mas').onclick = () => {
            if (estado.cantidad < 60) { estado.cantidad += 3; actualizarTodo(); }
        };
    }

    /* ─── Actualizar todo ─── */
    function actualizarTodo() {
        // Marcar activos en controles
        document.querySelectorAll('.ramo-btn').forEach((b, i) => {
            b.classList.toggle('activo', RAMOS[i].id === estado.ramo.id);
        });
        document.querySelectorAll('.color-opcion').forEach((b, i) => {
            b.classList.toggle('activo', COLORES[i].id === estado.color.id);
        });
        document.querySelectorAll('.estilo-btn').forEach((b, i) => {
            b.classList.toggle('activo', ESTILOS[i].id === estado.estilo.id);
        });

        // Cantidad y precio
        document.getElementById('cant-num').textContent  = estado.cantidad;
        document.getElementById('precio-est').textContent = `Bs. ${calcularPrecio()}`;

        // Chips
        document.getElementById('chip-ramo').textContent     = `${estado.ramo.emoji} ${estado.ramo.nombre}`;
        document.getElementById('chip-color').textContent    = `🎨 Color: ${estado.color.nombre}`;
        document.getElementById('chip-estilo').textContent   = `✨ Estilo: ${estado.estilo.label.split(' ')[1]}`;
        document.getElementById('chip-cantidad').textContent = `🌸 ${estado.cantidad} flores`;
        document.getElementById('preview-nombre').textContent =
            `${estado.ramo.nombre} · ${estado.color.nombre} · ${estado.estilo.label.split(' ')[1]}`;

        // SVG
        renderSVG();
    }

    /* ─── Render SVG del ramo ─── */
    function renderSVG() {
        const svg    = document.getElementById('bouquet-svg');
        const c      = estado.color;
        const forma  = estado.ramo.floraForma;
        const env    = estado.ramo.env;
        const cnt    = Math.min(estado.cantidad, 30);
        const esLujo = estado.estilo.id === 'lujo';
        const esMini = estado.estilo.id === 'mini';
        const esGig  = estado.estilo.id === 'gigante';

        // Escala general
        const scale  = esMini ? 0.78 : esGig ? 1.08 : 1;
        const cx = 170, cy = 195;

        let out = '';

        // Fondo decorativo suave
        out += `<defs>
            <radialGradient id="bgGrad" cx="50%" cy="55%" r="50%">
                <stop offset="0%" stop-color="${c.hex}22"/>
                <stop offset="100%" stop-color="${c.hex}05"/>
            </radialGradient>
            <radialGradient id="petalGrad" cx="40%" cy="35%" r="65%">
                <stop offset="0%" stop-color="${c.hex2}"/>
                <stop offset="100%" stop-color="${c.hex}"/>
            </radialGradient>
            <radialGradient id="petalGrad2" cx="40%" cy="35%" r="65%">
                <stop offset="0%" stop-color="${c.hex}cc"/>
                <stop offset="100%" stop-color="${c.hex}88"/>
            </radialGradient>
            ${esLujo ? `<filter id="glow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>` : ''}
        </defs>
        <ellipse cx="170" cy="200" rx="130" ry="120" fill="url(#bgGrad)"/>`;

        // Tallos / envoltura según env
        const talloColor = '#8B6B4A';
        if (env === 'cascade') {
            out += `<path d="M145,310 Q130,350 120,390" stroke="${talloColor}" stroke-width="5" fill="none" stroke-linecap="round"/>`;
            out += `<path d="M170,320 Q170,355 170,390" stroke="${talloColor}" stroke-width="5" fill="none" stroke-linecap="round"/>`;
            out += `<path d="M195,310 Q210,350 220,390" stroke="${talloColor}" stroke-width="5" fill="none" stroke-linecap="round"/>`;
        } else if (env === 'heart') {
            out += `<path d="M140,290 Q135,340 170,390 Q205,340 200,290" stroke="${talloColor}" stroke-width="5" fill="none" stroke-linecap="round"/>`;
        } else {
            // round / tall / natural — tallos agrupados
            const numT = Math.min(cnt, 9);
            for (let i = 0; i < numT; i++) {
                const ox = (i - numT/2) * 14;
                const curv = (Math.random() - .5) * 20;
                out += `<path d="M${170+ox},300 Q${170+ox+curv},345 ${170+ox},390" stroke="${talloColor}" stroke-width="3.5" fill="none" stroke-linecap="round" opacity=".9"/>`;
            }
        }

        // Hojas
        const hc = c.hoja;
        if (env !== 'mini') {
            out += `<ellipse cx="130" cy="270" rx="22" ry="10" fill="${hc}" opacity=".85" transform="rotate(-35,130,270)"/>`;
            out += `<ellipse cx="210" cy="265" rx="22" ry="10" fill="${hc}" opacity=".85" transform="rotate(35,210,265)"/>`;
            if (env === 'tall' || esGig) {
                out += `<ellipse cx="115" cy="230" rx="18" ry="8" fill="${hc}" opacity=".75" transform="rotate(-50,115,230)"/>`;
                out += `<ellipse cx="225" cy="225" rx="18" ry="8" fill="${hc}" opacity=".75" transform="rotate(50,225,225)"/>`;
            }
        }

        // Envoltura / kraft paper
        out += `<path d="M130,295 L120,390 L220,390 L210,295 Z" fill="#D4A96A" opacity=".35" rx="4"/>`;
        out += `<path d="M135,295 L125,390" stroke="#c49555" stroke-width="1" opacity=".4"/>`;
        out += `<path d="M205,295 L215,390" stroke="#c49555" stroke-width="1" opacity=".4"/>`;
        // Cinta
        const ribColor = esLujo ? '#FFD700' : c.hex;
        out += `<ellipse cx="170" cy="298" rx="44" ry="8" fill="${ribColor}" opacity="${esLujo?'.9':'.7'}"/>`;
        if (esLujo) {
            out += `<ellipse cx="170" cy="298" rx="44" ry="8" fill="none" stroke="#FFF8DC" stroke-width="1" opacity=".5"/>`;
            // destellos
            out += `<circle cx="148" cy="298" r="2" fill="#fffbe0" opacity=".9"/>`;
            out += `<circle cx="170" cy="298" r="2.5" fill="#fffbe0" opacity=".9"/>`;
            out += `<circle cx="192" cy="298" r="2" fill="#fffbe0" opacity=".9"/>`;
        }

        // Flores — distribución en función de forma
        const posiciones = generarPosiciones(cnt, env, cx, cy, scale);
        posiciones.forEach((pos, idx) => {
            out += dibujarFlor(forma, pos.x, pos.y, pos.r, idx, c, esLujo);
        });

        // Decoraciones especiales por estilo
        if (esLujo) {
            // perlas
            for (let i = 0; i < 6; i++) {
                const ang  = (i / 6) * Math.PI * 2;
                const px   = cx + Math.cos(ang) * 70 * scale;
                const py   = cy + Math.sin(ang) * 55 * scale - 10;
                out += `<circle cx="${px}" cy="${py}" r="4" fill="white" opacity=".85" filter="url(#glow)"/>`;
            }
        }
        if (env === 'heart') {
            out += `<text x="170" y="180" text-anchor="middle" font-size="18" opacity=".15">❤</text>`;
        }

        svg.innerHTML = out;

        // Animación pop
        svg.classList.remove('bouquet-animando');
        void svg.offsetWidth;
        svg.classList.add('bouquet-animando');
        svg.addEventListener('animationend', () => svg.classList.remove('bouquet-animando'), { once: true });
    }

    /* ─── Generar posiciones de flores ─── */
    function generarPosiciones(n, env, cx, cy, scale) {
        const pos = [];
        const seed = n * 7;
        function rnd(s) { return ((Math.sin(s) * 43758.5453) % 1 + 1) % 1; }

        if (env === 'cascade') {
            // Forma en cascada — más flores arriba, cae hacia abajo
            for (let i = 0; i < n; i++) {
                const t    = i / Math.max(n - 1, 1);
                const row  = Math.floor(i / 4);
                const col  = i % 4;
                const x    = cx + (col - 1.5) * 38 * scale + rnd(seed+i*3) * 10 - 5;
                const y    = (cy - 60) + row * 32 * scale + rnd(seed+i*7) * 10;
                const r    = (14 + rnd(seed+i*11) * 8) * scale;
                pos.push({ x, y, r });
            }
        } else if (env === 'tall') {
            // Columna alta
            for (let i = 0; i < n; i++) {
                const t   = i / Math.max(n-1,1);
                const x   = cx + (rnd(seed+i*5)-.5) * 80 * scale;
                const y   = (cy + 40) - t * 120 * scale;
                const r   = (12 + rnd(seed+i*9) * 10) * scale;
                pos.push({ x, y, r });
            }
        } else if (env === 'heart') {
            // Forma de corazón aproximada
            for (let i = 0; i < n; i++) {
                const t   = (i / Math.max(n-1,1)) * Math.PI * 2;
                const hx  = 16 * Math.pow(Math.sin(t), 3);
                const hy  = -(13*Math.cos(t) - 5*Math.cos(2*t) - 2*Math.cos(3*t) - Math.cos(4*t));
                const x   = cx + hx * 5 * scale + (rnd(seed+i*3)-.5)*10;
                const y   = cy + hy * 4 * scale - 10 + (rnd(seed+i*7)-.5)*10;
                const r   = (12 + rnd(seed+i*11)*8) * scale;
                pos.push({ x, y, r });
            }
        } else {
            // round / natural — espiral desde el centro
            for (let i = 0; i < n; i++) {
                const ang  = i * 2.399963; // ángulo dorado
                const rad  = (i === 0 ? 0 : 20 + i * 8) * scale * .7;
                const x    = cx + Math.cos(ang) * rad + (rnd(seed+i*5)-.5)*8;
                const y    = (cy - 20) + Math.sin(ang) * rad * .85 + (rnd(seed+i*9)-.5)*8;
                const r    = (14 + rnd(seed+i*13)*9) * scale;
                pos.push({ x, y, r });
            }
        }
        return pos;
    }

    /* ─── Dibujar flor según forma ─── */
    function dibujarFlor(forma, x, y, r, idx, c, esLujo) {
        const id = `fl${idx}`;
        const fill = idx % 3 === 0 ? `url(#petalGrad)` : idx % 3 === 1 ? `url(#petalGrad2)` : c.hex;
        const glw  = esLujo ? `filter="url(#glow)"` : '';

        if (forma === 'rose') {
            // Rosa — espiral de pétalos
            let out = '';
            const nPet = 5 + Math.floor(r/5);
            for (let p = 0; p < nPet; p++) {
                const ang = (p / nPet) * Math.PI * 2;
                const pr  = r * .65;
                const px  = x + Math.cos(ang) * pr * .7;
                const py  = y + Math.sin(ang) * pr * .55;
                out += `<ellipse cx="${px}" cy="${py}" rx="${r*.55}" ry="${r*.38}" fill="${fill}" ${glw}
                    transform="rotate(${(ang*180/Math.PI)+80},${px},${py})" opacity=".92"/>`;
            }
            out += `<circle cx="${x}" cy="${y}" r="${r*.28}" fill="${c.hex2}" opacity=".9"/>`;
            return out;

        } else if (forma === 'daisy') {
            // Margarita — pétalos ovalados
            let out = '';
            const nPet = 8;
            for (let p = 0; p < nPet; p++) {
                const ang = (p / nPet) * Math.PI * 2;
                const px  = x + Math.cos(ang) * r * .58;
                const py  = y + Math.sin(ang) * r * .58;
                out += `<ellipse cx="${px}" cy="${py}" rx="${r*.42}" ry="${r*.2}" fill="${fill}" ${glw}
                    transform="rotate(${ang*180/Math.PI},${px},${py})" opacity=".9"/>`;
            }
            out += `<circle cx="${x}" cy="${y}" r="${r*.3}" fill="#f7c948" opacity=".95"/>`;
            return out;

        } else if (forma === 'tulip') {
            // Tulipán — forma de copa
            return `<path d="M${x},${y-r*.8} Q${x+r*.6},${y-r*.3} ${x+r*.45},${y+r*.35}
                Q${x},${y+r*.5} Q${x-r*.45},${y+r*.35} ${x-r*.6},${y-r*.3} Z"
                fill="${fill}" ${glw} opacity=".93"/>
                <path d="M${x},${y-r*.8} Q${x+r*.15},${y} ${x},${y+r*.45}"
                stroke="${c.hex}" stroke-width="1" fill="none" opacity=".5"/>`;

        } else if (forma === 'tropical') {
            // Hibisco — 5 pétalos anchos
            let out = '';
            for (let p = 0; p < 5; p++) {
                const ang = (p/5)*Math.PI*2 - Math.PI/2;
                const px  = x + Math.cos(ang)*r*.5;
                const py  = y + Math.sin(ang)*r*.5;
                out += `<ellipse cx="${px}" cy="${py}" rx="${r*.65}" ry="${r*.28}" fill="${fill}" ${glw}
                    transform="rotate(${ang*180/Math.PI},${px},${py})" opacity=".9"/>`;
            }
            out += `<circle cx="${x}" cy="${y}" r="${r*.22}" fill="#ffec99" opacity=".95"/>`;
            return out;

        } else if (forma === 'wild') {
            // Flor silvestre — pequeña, 4 pétalos irregulares
            let out = '';
            for (let p = 0; p < 4; p++) {
                const ang  = (p/4)*Math.PI*2 + .3;
                const pr   = r * (.5 + Math.random()*.2);
                const px   = x + Math.cos(ang)*pr*.6;
                const py   = y + Math.sin(ang)*pr*.6;
                out += `<ellipse cx="${px}" cy="${py}" rx="${r*.45}" ry="${r*.22}" fill="${fill}" ${glw}
                    transform="rotate(${ang*180/Math.PI+45},${px},${py})" opacity=".88"/>`;
            }
            out += `<circle cx="${x}" cy="${y}" r="${r*.2}" fill="${c.hex2}" opacity=".9"/>`;
            return out;

        } else {
            // mixed — alterna entre rose y daisy
            return idx % 2 === 0 ? dibujarFlor('rose', x, y, r, idx, c, esLujo) : dibujarFlor('daisy', x, y, r, idx, c, esLujo);
        }
    }

    /* ─── Pedir por WhatsApp ─── */
    function pedirDisenoWhatsapp() {
        const precio = calcularPrecio();
        let msg = `🌸 *Hola Florería Alesli!*\n\n`;
        msg += `Me gustaría pedir un *${estado.ramo.nombre}* con las siguientes características:\n\n`;
        msg += `🎨 Color: *${estado.color.nombre}*\n`;
        msg += `✨ Estilo: *${estado.estilo.label.split(' ')[1]}*\n`;
        msg += `🌸 Cantidad: *${estado.cantidad} flores*\n`;
        msg += `💵 Precio estimado: *Bs. ${precio}*\n\n`;
        msg += `¿Pueden confirmarme disponibilidad y precio? ¡Gracias! 💐`;
        const tel = '59170000000';
        window.open(`https://wa.me/${tel}?text=${encodeURIComponent(msg)}`, '_blank');
    }

    /* ─── Agregar al carrito ─── */
    async function agregarDisenoCarrito() {
        const sesion = typeof AuthModal !== 'undefined' ? AuthModal.getSession() : null;
        if (!sesion) {
            if (typeof AuthModal !== 'undefined') AuthModal.open('login');
            else showToast('⚠️ Inicia sesión para agregar al carrito');
            return;
        }
        // Busca producto más cercano en el catálogo
        try {
            const res  = await fetch('../api/productos.php');
            const prods = await res.json();
            if (!Array.isArray(prods) || !prods.length) throw new Error('Sin productos');
            // Buscar por nombre de ramo o primer activo
            const match = prods.find(p =>
                p.nombre.toLowerCase().includes(estado.ramo.id) && p.estado === 'activo'
            ) || prods.find(p => p.estado === 'activo');
            if (!match) throw new Error('Sin stock');
            await fetch('../api/carrito.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id_usuario: sesion.id, id_producto: match.id, cantidad: 1 }),
            });
            showToast(`🛒 ${estado.ramo.nombre} añadido al carrito`);
        } catch(e) {
            showToast('❌ No se pudo agregar: ' + e.message, 'err');
        }
    }

    /* ─── Init ─── */
    initControles();
    actualizarTodo();
