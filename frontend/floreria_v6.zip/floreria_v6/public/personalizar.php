<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personalizar tu ramo — Florería Alesli</title>
    <link rel="stylesheet" href="assets/css/fonts-cliente.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/personalizar-page.css">
</head>
<body>

    <!-- NAV igual al resto del proyecto -->
    <header class="nav-bar" id="navbar">
        <div class="logo"><a href="index.php" style="text-decoration:none;color:inherit;">Floreria <span>alesli</span></a></div>
        <nav>
            <a href="index.php">Inicio</a>
            <a href="catalogo.php">Catálogo</a>
            <a href="personalizar.php" class="active">Personalizar</a>
            <a href="nosotros.php">Nosotros</a>
            <a href="nosotros.php#contacto">Contacto</a>
        </nav>
        <div class="action" id="nav-action">
            <button class="btn-login" onclick="AuthModal.open()">Entrar</button>
        </div>
    </header>

    <main class="personalizar-hero">

        <div class="personalizar-header">
            <span class="seccion-tag">✦ Experiencia única</span>
            <h1>Diseña tu ramo <span>perfecto</span></h1>
            <p id="personalizar-saludo">Toma una foto de flores que te inspiren o súbela desde tu galería. Analizamos los colores y te sugerimos el arreglo ideal de nuestra colección.</p>
        </div>

        <div class="personalizar-grid">

            <!-- Columna izquierda: cámara -->
            <div class="camara-card">
                <h2>📷 Tu inspiración</h2>

                <div class="media-box" id="media-container">
                    <div class="rec-dot"></div>
                    <div class="media-placeholder" id="placeholder">
                        <span class="icon-big">🌸</span>
                        <span>Activa la cámara o sube una foto</span>
                    </div>
                </div>

                <div class="botones-camara">
                    <button class="btn-cam btn-cam-primary" id="btn-start-camera">
                        📷 Abrir cámara
                    </button>
                    <button class="btn-cam btn-cam-snap" id="btn-snap">
                        ⬤ Capturar
                    </button>
                    <label for="file-input" class="btn-cam btn-cam-secondary" style="cursor:pointer;">
                        🖼️ Subir foto
                    </label>
                    <input type="file" id="file-input" accept="image/*">
                </div>

                <p style="font-size:.8rem;color:var(--soft);line-height:1.5;">
                    💡 <strong>Tip:</strong> Fotografía flores de colores que te gusten — rosas, tulipanes, lilas — y encontraremos arreglos similares en nuestro catálogo.
                </p>
            </div>

            <!-- Columna derecha: resultados -->
            <div class="resultado-card" id="resultado-card">
                <h2>🌺 Tu arreglo ideal</h2>

                <!-- Estado vacío -->
                <div class="resultado-vacio" id="resultado-vacio">
                    <span>🔍</span>
                    <p>Sube o toma una foto para ver sugerencias personalizadas de arreglos florales.</p>
                </div>

                <!-- Resultado activo (se muestra tras analizar) -->
                <div class="resultado-activo" id="resultado-activo">

                    <div>
                        <div class="paleta-label">Colores detectados</div>
                        <div class="paleta-colores" id="paleta-colores"></div>
                    </div>

                    <div>
                        <div class="paleta-label" style="margin-bottom:.6rem;">Arreglos sugeridos</div>
                        <div class="sugerencias-grid" id="sugerencias-grid"></div>
                    </div>

                    <div>
                        <div class="paleta-label" style="margin-bottom:.5rem;">Nota para el floristero</div>
                        <textarea class="nota-textarea" id="nota-pedido"
                            placeholder="Ej: Quiero algo parecido pero con girasoles, para un cumpleaños..."></textarea>
                    </div>

                    <button class="btn-pedido" id="btn-pedido" onclick="enviarPedido()">
                        🌸 Solicitar este arreglo por WhatsApp
                    </button>

                </div>
            </div>

        </div>

        <!-- Tira informativa -->
        <div class="info-strip">
            <div class="info-item">
                <div class="ico">🎨</div>
                <h3>Colores a tu gusto</h3>
                <p>Analizamos tu foto y encontramos la paleta perfecta para tu arreglo.</p>
            </div>
            <div class="info-item">
                <div class="ico">💐</div>
                <h3>Arreglo único</h3>
                <p>Nuestras floristas crean tu ramo a mano con flores frescas del día.</p>
            </div>
            <div class="info-item">
                <div class="ico">🚚</div>
                <h3>Entrega el mismo día</h3>
                <p>Pedidos antes de las 14:00 se entregan hoy en toda La Paz.</p>
            </div>
        </div>

        <!-- ══════════════════════════════════════════════
             SECCIÓN: DISEÑADOR INTERACTIVO DE RAMOS
             ══════════════════════════════════════════════ -->
        <div class="disenador-section">

            <div class="disenador-header">
                <span class="seccion-tag">🎨 Diseñador en tiempo real</span>
                <h2>Crea tu ramo <span>ideal</span></h2>
                <p>Elige un ramo base, cambia colores y estilo — ve el resultado al instante antes de pedirlo.</p>
            </div>

            <div class="disenador-layout">

                <!-- Panel izquierdo: controles -->
                <div class="disenador-controles">

                    <!-- Paso 1: elegir ramo base -->
                    <div class="paso-bloque">
                        <div class="paso-titulo"><span class="paso-num">1</span> Elige tu ramo base</div>
                        <div class="ramos-selector" id="ramos-selector">
                            <!-- generados por JS -->
                        </div>
                    </div>

                    <!-- Paso 2: color principal -->
                    <div class="paso-bloque">
                        <div class="paso-titulo"><span class="paso-num">2</span> Color principal</div>
                        <div class="colores-grid" id="colores-grid">
                            <!-- generados por JS -->
                        </div>
                    </div>

                    <!-- Paso 3: estilo / decoración -->
                    <div class="paso-bloque">
                        <div class="paso-titulo"><span class="paso-num">3</span> Estilo del arreglo</div>
                        <div class="estilos-grid" id="estilos-grid">
                            <!-- generados por JS -->
                        </div>
                    </div>

                    <!-- Paso 4: cantidad de flores -->
                    <div class="paso-bloque">
                        <div class="paso-titulo"><span class="paso-num">4</span> Cantidad de flores</div>
                        <div class="cantidad-control">
                            <button class="cant-btn" id="cant-menos">−</button>
                            <div class="cant-display">
                                <span id="cant-num">12</span>
                                <span class="cant-label">flores</span>
                            </div>
                            <button class="cant-btn" id="cant-mas">+</button>
                        </div>
                        <div class="precio-estimado">Precio estimado: <strong id="precio-est">Bs. 85</strong></div>
                    </div>

                </div>

                <!-- Panel derecho: preview -->
                <div class="disenador-preview">
                    <div class="preview-marco">
                        <div class="preview-etiqueta">Vista previa en tiempo real</div>
                        <svg id="bouquet-svg" viewBox="0 0 340 400" xmlns="http://www.w3.org/2000/svg">
                            <!-- renderizado por JS -->
                        </svg>
                        <div class="preview-nombre" id="preview-nombre">Ramo Primavera · Rosa · Clásico</div>
                    </div>

                    <div class="preview-detalles" id="preview-detalles">
                        <div class="det-chip" id="chip-ramo">💐 Ramo Primavera</div>
                        <div class="det-chip" id="chip-color">🎨 Color: Rosa</div>
                        <div class="det-chip" id="chip-estilo">✨ Estilo: Clásico</div>
                        <div class="det-chip" id="chip-cantidad">🌸 12 flores</div>
                    </div>

                    <div style="display:flex;gap:.8rem;flex-wrap:wrap;">
                        <button class="btn-pedir-disenador" id="btn-pedir-disenador" onclick="pedirDisenoWhatsapp()">
                            🌸 Pedir este diseño por WhatsApp
                        </button>
                        <button class="btn-agregar-carrito" id="btn-agregar-carrito" onclick="agregarDisenoCarrito()">
                            🛒 Añadir al carrito
                        </button>
                    </div>
                </div>

            </div>
        </div>

    </main>

    <!-- Toast de notificación -->
    <div class="alesli-toast" id="toast"></div>

    <!-- FAB carrito igual al resto -->
    <a href="carrito.php" class="boton-emergencia" id="fab-carrito" style="position:relative;">
        🛒
        <span id="fab-badge" style="position:absolute;top:-6px;right:-6px;background:#ef4444;color:#fff;border-radius:50%;width:20px;height:20px;font-size:11px;display:none;align-items:center;justify-content:center;font-weight:700;font-family:var(--ff-body);">0</span>
    </a>

    <script src="assets/js/efecto-petalos.js"></script>
    <script src="assets/js/cliente-auth.js"></script>
    <script src="assets/js/nav-perfil.js"></script>

    <!-- ══════════════════════════════════════════════
         DISEÑADOR INTERACTIVO — JavaScript
         ══════════════════════════════════════════════ -->

    <script src="assets/js/personalizar-page.js"></script>
</body>
</html>
