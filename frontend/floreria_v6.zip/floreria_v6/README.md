# 🌸 FLORERIA UNIFICADA

Proyecto unificado que integra la vista de cliente, panel de administrador y panel de empleado.

## Estructura

```
FLORERIA_UNIFICADA/
├── public/                   ← Frontend (navegador)
│   ├── index.html            ← Inicio (vista cliente)
│   ├── carrito.html          ← Carrito de compras
│   ├── nosotros.html         ← Página nosotros
│   ├── assets/
│   │   ├── css/
│   │   │   ├── estilo.css          ← Estilos cliente
│   │   │   ├── carrito.css         ← Estilos carrito
│   │   │   ├── estilo-panel.css    ← Estilos panel admin
│   │   │   └── styles-empleado.css ← Estilos panel empleado
│   │   ├── js/
│   │   │   ├── efecto-petalos.js
│   │   │   ├── panel.js
│   │   │   ├── main.js
│   │   │   ├── dashboard.js
│   │   │   ├── pedidos.js
│   │   │   ├── catalogo.js
│   │   │   ├── clientes.js
│   │   │   ├── ventas.js
│   │   │   ├── entregas.js
│   │   │   └── configuracion.js
│   │   ├── img/              ← Imágenes del sitio
│   │   └── icon/             ← Iconos
│   │
│   ├── admin/
│   │   └── index.html        ← Panel administrador
│   │
│   └── empleado/
│       ├── login.html
│       ├── dashboard.html
│       ├── pedidos.html
│       ├── catalogo.html
│       ├── clientes.html
│       ├── ventas.html
│       ├── entregas.html
│       └── configuracion.html
│
├── api/                      ← Backend PHP
│   ├── conexion.php          ← Conexión a base de datos
│   ├── carrito.php
│   ├── panel-admin.php
│   ├── floreriainicio.php
│   └── productos/
│       └── create.php
│
├── uploads/                  ← Imágenes subidas por usuarios
└── README.md
```

## Accesos
| Vista | URL |
|---|---|
| Cliente | `/public/index.html` |
| Admin | `/public/admin/index.html` |
| Empleado | `/public/empleado/login.html` |

## Servidor local (XAMPP / Laragon)
Coloca la carpeta en `htdocs/` y accede por `http://localhost/FLORERIA_UNIFICADA/public/`
