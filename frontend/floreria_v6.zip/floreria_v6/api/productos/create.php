<?php

require_once '../conexion.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

$nombre      = trim($_POST['nombre']      ?? '');
$estado      = trim($_POST['estado']      ?? 'activo');
$descripcion = trim($_POST['descripcion'] ?? '');
$precio      = floatval($_POST['precio']  ?? 0);
$stock       = intval($_POST['stock']     ?? 0);
$categoria   = trim($_POST['categoria']   ?? 'General');

if (!$nombre || $precio <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Nombre y precio son obligatorios']);
    exit;
}

$nombre_foto_db = null;
if (!empty($_FILES['foto']['tmp_name'])) {
    $foto_archivo   = $_FILES['foto'];
    $extension      = strtolower(pathinfo($foto_archivo['name'], PATHINFO_EXTENSION));
    $permitidas     = ['jpg','jpeg','png','webp','gif'];
    if (!in_array($extension, $permitidas)) {
        http_response_code(400);
        echo json_encode(['error' => 'Tipo de imagen no permitido']);
        exit;
    }
    $nombre_foto_db = time() . '_' . uniqid() . '.' . $extension;
    $ruta_destino   = __DIR__ . '/../../uploads/' . $nombre_foto_db;
    if (!move_uploaded_file($foto_archivo['tmp_name'], $ruta_destino)) {
        http_response_code(500);
        echo json_encode(['error' => 'No se pudo guardar la imagen']);
        exit;
    }
}

try {
    $sql  = "INSERT INTO catalogo (nombre, estado, descripcion, precio, stock, categoria, foto)
             VALUES (:nombre, :estado, :descripcion, :precio, :stock, :categoria, :foto)";
    $stmt = $conexion->prepare($sql);
    $stmt->bindParam(':nombre',      $nombre);
    $stmt->bindParam(':estado',      $estado);
    $stmt->bindParam(':descripcion', $descripcion);
    $stmt->bindParam(':precio',      $precio);
    $stmt->bindParam(':stock',       $stock);
    $stmt->bindParam(':categoria',   $categoria);
    $stmt->bindParam(':foto',        $nombre_foto_db);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'id' => $conexion->lastInsertId()]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Error al guardar en la base de datos']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
