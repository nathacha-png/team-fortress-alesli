<?php

require_once __DIR__ . '/cors.php';

session_unset();
session_destroy();

header('Location: ../public/empleado/login.php');
exit;
