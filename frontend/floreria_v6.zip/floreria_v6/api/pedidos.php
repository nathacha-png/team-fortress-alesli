<?php
require_once __DIR__ . '/cors.php';
header('Content-Type: application/json');
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos       = json_decode(file_get_contents('php://input'), true);
    $id_usuario  = intval($datos['id_usuario']  ?? 0);
    $producto    = trim($datos['producto']       ?? '');
    $id_producto = intval($datos['id_producto']  ?? 0) ?: null;
    $telefono    = trim($datos['telefono']       ?? '');
    $direccion   = trim($datos['direccion']      ?? '');
    $notas       = trim($datos['notas']          ?? '');
    $prioridad   = in_array($datos['prioridad'] ?? '', ['baja','media','alta']) ? $datos['prioridad'] : 'media';
    $fecha_entrega = trim($datos['fecha_entrega'] ?? '') ?: null;

    
    $total = 0;
    if ($id_producto) {
        try {
            $ps = $conexion->prepare("SELECT precio FROM catalogo WHERE id_producto = :id");
            $ps->execute([':id' => $id_producto]);
            $row = $ps->fetch();
            if ($row) $total = floatval($row['precio']);
        } catch (PDOException $e) {}
    }
    if (!$total && isset($datos['total'])) $total = floatval($datos['total']);

    if (!$id_usuario || !$producto) {
        http_response_code(400);
        echo json_encode(['error' => 'id_usuario y producto son requeridos']);
        exit;
    }

    try {
        $stmt = $conexion->prepare("
            INSERT INTO pedidos (id_usuario, producto, id_producto, telefono, direccion, notas, prioridad, total, estado, fecha_pedido, fecha_entrega)
            VALUES (:id_usuario, :producto, :id_producto, :telefono, :direccion, :notas, :prioridad, :total, 'pendiente', NOW(), :fecha_entrega)
        ");
        $stmt->execute([
            ':id_usuario'   => $id_usuario,
            ':producto'     => $producto,
            ':id_producto'  => $id_producto,
            ':telefono'     => $telefono ?: null,
            ':direccion'    => $direccion ?: null,
            ':notas'        => $notas ?: null,
            ':prioridad'    => $prioridad,
            ':total'        => $total,
            ':fecha_entrega'=> $fecha_entrega,
        ]);
        $newId = $conexion->lastInsertId();
        http_response_code(201);
        echo json_encode(['success' => true, 'id' => $newId]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'PATCH') {
    $datos  = json_decode(file_get_contents('php://input'), true);
    $id     = intval($datos['id']     ?? 0);
    $estado = trim($datos['estado']   ?? '');
    $estados_validos = ['pendiente','preparando','listo','entregado','cancelado'];

    if (!$id || !in_array($estado, $estados_validos)) {
        http_response_code(400);
        echo json_encode(['error' => 'id y estado válido son requeridos']);
        exit;
    }
    try {
        $stmt = $conexion->prepare(
            "UPDATE pedidos SET estado = :estado WHERE id_pedido = :id"
        );
        $stmt->execute([':estado' => $estado, ':id' => $id]);
        echo json_encode(['success' => true, 'id' => $id, 'estado' => $estado]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

try {
    $stmt = $conexion->query("
        SELECT
            p.id_pedido                          AS id,
            CONCAT(u.nombre, ' ', u.apellido)   AS name,
            COALESCE(p.telefono, u.telefono, '') AS phone,
            p.producto                           AS product,
            CONCAT('Bs. ', FORMAT(p.total, 2))  AS price,
            COALESCE(DATE_FORMAT(p.fecha_entrega,'%d/%m/%Y'), '—') AS delivery,
            p.prioridad                          AS priority,
            p.estado                             AS status
        FROM pedidos p
        JOIN usuarios u ON p.id_usuario = u.id_usuario
        ORDER BY p.fecha_pedido DESC
    ");
    echo json_encode($stmt->fetchAll());
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
