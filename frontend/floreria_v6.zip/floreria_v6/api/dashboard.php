<?php
require_once __DIR__ . '/cors.php';
header('Content-Type: application/json');

require_once 'conexion.php';

try {
    $stats = [];

    
    $stats['pedidos_hoy'] = $conexion
        ->query("SELECT COUNT(*) FROM pedidos WHERE DATE(fecha_pedido) = CURDATE()")
        ->fetchColumn();

    
    $stats['pendientes'] = $conexion
        ->query("SELECT COUNT(*) FROM pedidos WHERE estado IN ('pendiente','preparando','listo')")
        ->fetchColumn();

    
    $stats['ventas_hoy'] = $conexion
        ->query("SELECT COALESCE(SUM(monto),0) FROM ventas WHERE fecha = CURDATE() AND estado='completado'")
        ->fetchColumn();

    
    $stats['clientes'] = $conexion
        ->query("SELECT COUNT(*) FROM usuarios WHERE estado='activo'")
        ->fetchColumn();

    
    $stats['entregas_hoy'] = $conexion
        ->query("SELECT COUNT(*) FROM entregas WHERE fecha = CURDATE()")
        ->fetchColumn();

    
    $recientes = $conexion->query("
        SELECT
            p.id_pedido                         AS id,
            CONCAT(u.nombre,' ',u.apellido)     AS cliente,
            p.producto,
            p.total,
            p.estado,
            DATE_FORMAT(p.fecha_pedido,'%d/%m/%Y %H:%i') AS fecha
        FROM pedidos p
        JOIN usuarios u ON p.id_usuario = u.id_usuario
        ORDER BY p.fecha_pedido DESC
        LIMIT 10
    ");
    $stats['pedidos_recientes'] = $recientes->fetchAll();

    
    $stock = $conexion->query("
        SELECT nombre, COALESCE(stock,0) AS stock
        FROM catalogo
        WHERE estado != 'desactivo'
        ORDER BY stock ASC
        LIMIT 6
    ");
    $stats['stock_flores'] = $stock->fetchAll();

    echo json_encode($stats);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
