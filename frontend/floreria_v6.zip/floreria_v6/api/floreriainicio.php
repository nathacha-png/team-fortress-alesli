<?php

header('Location: ../public/catalogo.php');
exit;
